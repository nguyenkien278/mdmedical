<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
class IT_Tour {

	/**
	 * The tour (post) ID.
	 *
	 * @var int
	 */
	public $id = 0;

	/**
	 * $post Stores post data.
	 *
	 * @var $post WP_Post
	 */
	public $post = null;


	public $total_ticket;

	/**
	 * Constructor gets the post object and sets the ID for the loaded tour.
	 *
	 * @param int|IT_Tour|object $tour ID, post object, or tour object
	 */
	public function __construct( $tour ) {
		if ( is_numeric( $tour ) ) {
			$this->id   = absint( $tour );
			$this->post = get_post( $this->id );
		} elseif ( $tour instanceof IT_Tour ) {
			$this->id   = absint( $tour->id );
			$this->post = $tour->post;
		} elseif ( isset( $tour->ID ) ) {
			$this->id   = absint( $tour->ID );
			$this->post = $tour;
		}
	}

	/**
	 * __isset function.
	 *
	 * @param mixed $key
	 * @return bool
	 */
	public function __isset( $key ) {
		return metadata_exists( 'post', $this->id, 'intravel_' . $key );
	}

	/**
	 * __get function.
	 *
	 * @param string $key
	 * @return mixed
	 */
	public function __get( $key ) {
		$value = get_post_meta( $this->id, 'intravel_' . $key, true );

		if ( false !== $value ) {
			$this->$key = $value;
		}

		return $value;
	}

	/**
	 * Get the tour's post data.
	 *
	 * @return object
	 */
	public function get_post_data() {
		return $this->post;
	}

	/**
	 * Return the tour ID
	 * @return int tour (post) ID
	 */
	public function get_id() {

		return $this->id;
	}

	/**
	 * Returns the gallery attachment ids.
	 *
	 * @return array
	 */
	public function get_gallery_attachment_ids() {
		$gallery = get_post_meta($this->post->ID, 'intravel_gallery' , true);
        $gallery = $gallery ? json_decode($gallery, true) : array();

		return apply_filters( 'intravel_tour_gallery', $gallery, $this );
	}

	/**
	 * Get Featured Image of Post.
	 *
	 * @return string
	 */
	function get_featured_image($image_size = 'large'){
		$featured_image = '';
		if ($this->post && has_post_thumbnail( $this->post->ID )) {
			$featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( $this->post->ID ), $image_size );
			$featured_image = $featured_image[ 0 ];
		}

		return apply_filters( 'intravel_tour_featured_image', $featured_image, $this );
	}

	function get_marker_icon(){
		$type = $this->get_type();
		$marker_icon = '';
		if($type){
			$marker_icon = get_term_meta($type->term_id, 'intravel_marker_icon', true);
		}

		return $marker_icon;
	}

	function get_map_data(){
		$return = array(
			'lat' => '',
			'lng'=> '',
			'zoom' => '',
			'marker_icon' => ''
		);

		$map_data = get_post_meta( $this->id, 'intravel_map', true );
		if($map_data){
			$return = array_merge($return, json_decode($map_data, true));
		}

		$return['marker_icon'] = $this->get_marker_icon();

		return $return;
	}

	/**
	 * Wrapper for get_permalink.
	 *
	 * @return string
	 */
	public function get_permalink() {
		return get_permalink( $this->id );
	}


	/**
	 * Return the tour type.
	 *
	 * @return string
	 */
	public function get_types() {
		$terms = wp_get_post_terms( $this->post->ID, 'tour_type');
		return $terms;
	}
	
	/**
	 * Return the tour type.
	 *
	 * @return string
	 */
	public function get_type($field = false) {
		$terms = wp_get_post_terms( $this->post->ID, 'tour_type');
		if($terms && !is_wp_error($terms)){
            $term = $terms[0];
			if($field){
				if(isset($term->$field)) {
					return $term->$field;
				}
			}else{
                return $term;
            }
        }
		return false;
	}

	public function get_feature_list(){
		$all_feature_list = get_terms( array(
			'taxonomy' => 'tour_feature',
			'hide_empty' => false,
		) );
		$include_feature_lists = wp_get_post_terms( $this->id , 'tour_feature',  array('fields'=>'ids'));
		$feature_lists = array();
		foreach ($all_feature_list as $feature_list){
			if(in_array($feature_list->term_id, $include_feature_lists)){
				$feature_lists[$feature_list->name] = true;
			}
			else{
				$feature_lists[$feature_list->name] = false;
			}
		}

		return $feature_lists;
	}

	public function get_schedules(){
		$schedules = get_post_meta($this->post->ID, 'intravel_schedules', true);
		if($schedules) {
			$schedules = json_decode($schedules);
		}

		return $schedules;
	}

	/**
	 * Returns whether or not the tour post exists.
	 *
	 * @return bool
	 */
	public function exists() {
		return empty( $this->post ) ? false : true;
	}

	/**
	 * Get the title of the post.
	 *
	 * @return string
	 */
	public function get_title() {
		return apply_filters( 'intravel_tour_title', $this->post ? $this->post->post_title : '', $this );
	}

	/**
	 * Returns whether or not the tour is featured.
	 *
	 * @return bool
	 */
	public function is_featured() {

		$featured = $this->featured;
		return ( $featured && $featured == 'yes') ? true : false;
	}

	/**
	 * Returns whether or not the tour is visible in the catalog.
	 *
	 * @return bool
	 */
	public function is_visible() {
		if ( ! $this->post ) {
			$visible = false;

		// Published/private
		} elseif ( $this->post->post_status !== 'publish' && ! current_user_can( 'edit_post', $this->id ) ) {
			$visible = false;
		}

		return apply_filters( 'intravel_tour_is_visible', $visible, $this->id );
	}

	/**
	 * Returns whether or not the tour is on sale.
	 *
	 * @return bool
	 */
	public function is_on_sale() {
		return apply_filters( 'intravel_tour_is_on_sale', ($this->discount > 0), $this );
	}

	/**
	 * Returns false if the tour cannot be bought.
	 *
	 * @return bool
	 */
	public function is_purchasable() {

		$purchasable = true;

		// Products must exist of course
		if ( ! $this->exists() ) {
			$purchasable = false;

		// Other tours types need a price to be set
		} elseif ( $this->get_price() === '' ) {
			$purchasable = false;

		// Check the tour is published
		} elseif ( $this->post->post_status !== 'publish' && ! current_user_can( 'edit_post', $this->id ) ) {
			$purchasable = false;
		}

		return apply_filters( 'intravel_is_purchasable', $purchasable, $this );
	}

	/**
	 * Set a tours price dynamically.
	 *
	 * @param float $price Price to set.
	 */
	public function set_price( $price ) {
		$this->total_price = $price;
	}

	/**
	 * Adjust a tours price dynamically.
	 *
	 * @param mixed $price
	 */
	public function adjust_price( $price ) {
		$this->price = $this->price + $price;
	}

	/**
	 * Returns the tour's sale price.
	 *
	 * @return string price
	 */
	public function get_sale_price() {
		return apply_filters( 'intravel_get_sale_price', $this->sale_price, $this );
	}

	/**
	 * Returns the tour's regular price.
	 *
	 * @return string price
	 */
	public function get_regular_price($date = null, $quantity = null) {
		return apply_filters( 'intravel_get_regular_price', $this->regular_price, $this );
	}

	/**
	 * Returns the tour's active price.
	 *
	 * @return string price
	 */
	public function _get_price($date = null, $tickets = null, $type = 'adult') {
		$price = 0;

		if(!$date){
			if($type == 'adult'){
				$price = $this->price;
			}else{
				$price = $this->children_price;
			}
		}
		else
		{
			$period = $this->get_period($date);
			if($period){
				if($type == 'adult'){
					$price = $period['price'];
				}else{
					$price = $period['children_price'];
				}
			}
		}

		if($tickets !== null){
			return $price * $tickets;
		}

		return $price;
	}

	/**
	 * Returns the tour's active price.
	 *
	 * @return string price
	 */
	public function get_price($date = null, $adule = null, $children = null) {
		$price = 0;

		if(!$date){
			if($adule && $children){
				$price = ($this->price * $adule) + ($this->children_price * $children);
			}elseif($adule){
				$price = $this->price * $adule;
			}elseif($children){
				$price = $this->children_price * $children;
			}
			else
			{
				$price = $this->price;
			}
		}
		else
		{
			$period = $this->get_period($date);
			if($period){
				if($adule && $children){
					$price = ($period['price'] * $adule) + ($period['children_price'] * $children);
				}elseif($adule){
					$price = $period['price'] * $adule;
				}elseif($children){
					$price = $period['children_price'] * $children;
				}
				else
				{
					$price = $period['price'];
				}
			}
		}

		return $price;
	}

	public function get_price_status($date, $adult, $children, $services = array(), $get_only_status = false, $get_msg_tax = false){
		$adult = (int)$adult;
		$children = (int)$children;
		$date = date('m/d/Y', strtotime($date));
		$return = array('status' => 0, 'msg' => '');
		if(!$date || !$adult){
            if(!$date){
                $return['msg'] = __('Please select tour start.', 'intravel');
            }else{
                $return['msg'] = __('Please select adult.', 'intravel');
            }
			return $return;
		}

		//check adult
		$prices = 0;
		if($adult){
			$tickets_available = $this->get_tickets_available($date, 'adult');
			if($tickets_available === true || $adult <= $tickets_available){
				$price = $this->get_display_price(null, $date);
				if($adult > 1){
					$prices = $this->get_display_price(null, $date, $adult);
				}
				else
				{
					$prices = $price;
				}

				$return['status'] = 1;
				//$return['msg'] = '<div class="msg-adult">'.sprintf(__('Adult: <span>%d x %s = %s</span>', 'intravel'), $adult, it_price($price), it_price($prices)).'</div>';
				$return['msg'] = '<div class="msg-adult">'.sprintf(__('%d x %s = %s', 'intravel'), $adult, it_price($price), it_price($prices)).'</div>';
			}else{
				$return['status'] = 0;
				$return['msg'] = '<div class="msg-adult">'.sprintf(__('Only %d adult ticket is left.', 'intravel'), $tickets_available).'</div>';
			}
		}

		//check children
		$children_prices = 0;
		if($children){
			$tickets_available = $this->get_tickets_available($date, 'children');
			if($tickets_available === true || $children <= $tickets_available){
				$children_price = $this->get_display_price(null, $date, null, 1);
				if($children > 1){
					$children_prices = $this->get_display_price(null, $date, null, $children);
				}
				else
				{
					$children_prices = $children_price;
				}

				$return['status'] = 1;
				//$return['msg'] .= '<div class="msg-children">'.sprintf(__('Children: <span>%d x %s = %s</span>', 'intravel'), $children, it_price($children_price), it_price($children_prices)).'</div>';
				$return['msg'] .= '<div class="msg-children">'.sprintf(__('%d x %s = %s', 'intravel'), $children, it_price($children_price), it_price($children_prices)).'</div>';
			}else{
				$return['status'] = 0;
				$return['msg'] = '<div class="msg-children">'.sprintf(__('Only %d children ticket is left.', 'intravel'), $tickets_available).'</div>';
			}
		}

        $service_price = 0;
        if($return['status'] == 1 && $services){
            $service_message = '';
            $service_price = $this->get_services_price($services, $adult, $children, $service_message);
            if($service_price){
                $return['msg'] .= $service_message;
            }
        }

		if($return['status']){
            $tax = it_get_tax();
			if($get_msg_tax && $tax && it_is_taxable()){
                $_prices = it_price($this->get_display_price($prices + $children_prices + $service_price));
                $return['msg'] = '<div class="msg-total">'.sprintf(__('<label>Total price:</label> <span>%s</span>', 'intravel'), $_prices).'</div>';
                $return['msg'] .= '<div class="msg-tax">'.sprintf(__('<label>Tax %s%%</label> <span>%s</span>', 'intravel'), $tax, it_price($tax * ($prices + $children_prices + $service_price) / 100)).'</div>';
                $_prices = it_price($this->get_price_including_tax($prices + $children_prices + $service_price));
                $return['msg'] .= '<div class="msg-grand-total">'.sprintf(__('<label>Grand price:</label> <span>%s</span>', 'intravel'), $_prices).'</div>';
            }
			else{
                $_prices = it_price($this->get_display_price($prices + $children_prices + $service_price));
                $return['msg'] = '<div class="msg-total">'.sprintf(__('<label>Total price:</label> <span>%s</span>', 'intravel'), $_prices).'</div>';
            }
		}

		if($get_only_status){
			return $return['status'];
		}
		else
		{
			return $return;
		}
	}

	function get_services_price($services, $adult = '', $children = '', &$message){
        $price = 0;
        $services = (array)$services;
        if(!$services){
            return $price;
        }
        foreach ($services as $service){
            if(!$service){
                continue;
            }
            $term = get_term($service, 'tour_service');
            if(!is_wp_error($term)){
                $adult_price = $children_price = 0;
                if($adult){
                    $adult_price = ((int)get_term_meta($service, 'intravel_price', true) * $adult);
                }
                if($children){
                    $children_price = ((int)get_term_meta($service, 'intravel_children_price', true) * $children);
                }
                $name = $term->name;
                if($term->parent){
                    $term = get_term($term->parent, 'tour_service');
                    $name = $term->name. ' ' . $name;
                }
                $message .= '<div class="msg-service">'.$name .': '.it_price($adult_price+$children_price).'</div>';
                $price += $adult_price + $children_price;
            }
        }
        return $price;
    }


	public function get_tax($number = false){
		if($number){
			return (float)'0';
		}

		return (float)it_get_option('taxes');
	}

	/**
	 * Returns the price (including tax). Uses customer tax rates. Can work for a specific $qty for more accurate taxes.
	 *
	 * @param  int $qty
	 * @param  string $price to calculate, left blank to just use get_price()
	 * @return string
	 */
	public function get_price_including_tax($price = null, $date = null, $adult = null, $children = null ) {
		if($price === null){
			$price = $this->get_price($date, $adult, $children);
		}
		$tax = it_get_tax();
		if ( it_is_taxable() && it_get_option( 'prices_include_tax' ) === 'no' ) {
			$price = round($price + (($price * $tax) / 100), it_get_price_decimals());
		}
		else
		{
			$price = round($price, it_get_price_decimals());
		}

		return apply_filters( 'intravel_get_price_including_tax', $price, $adult, $children, $this );
	}

	/**
	 * Returns the price (excluding tax) - ignores tax_class filters since the price may *include* tax and thus needs subtracting.
	 * Uses store base tax rates. Can work for a specific $qty for more accurate taxes.
	 *
	 * @param  int $qty
	 * @param  string $price to calculate, left blank to just use get_price()
	 * @return string
	 */
	public function get_price_excluding_tax($price = null, $date = null, $adult = null, $children = null) {
		if($price === null){
			$price = $this->get_price($date, $adult, $children);
		}

		$tax = it_get_tax();
		if ( it_is_taxable() && 'yes' === it_get_option( 'prices_include_tax' ) ) {
			$price = round($price - (($price * $tax) / 100), it_get_price_decimals());
		} else {
			$price = round($price, it_get_price_decimals());
		}

		return apply_filters( 'intravel_get_price_excluding_tax', $price, $adult, $children, $this );
	}

	/**
	 * Returns the price including or excluding tax, based on the 'intravel_tax_display_tours' setting.
	 *
	 * @param  string  $price to calculate, left blank to just use get_price()
	 * @param  integer $qty   passed on to get_price_including_tax() or get_price_excluding_tax()
	 * @return string
	 */
	public function get_display_price( $price = null, $date = null, $adult = null, $children = null ) {

		if ( $price === null ) {
			$price = $this->get_price($date, $adult, $children);
		}

		if(!it_use_woocommerce_payment()){
			$tax_display_mode = it_get_option( 'tax_display_tours' );
			$price    = $tax_display_mode == 'incl' ? $this->get_price_including_tax( $price, $date, $adult, $children) : $this->get_price_excluding_tax($price, $date, $adult, $children);
		}

		return $price;
	}

	/**
	 * Get the suffix to display after prices > 0.
	 *
	 * @param  string  $price to calculate, left blank to just use get_price()
	 * @param  integer $qty   passed on to get_price_including_tax() or get_price_excluding_tax()
	 * @return string
	 */
	public function get_price_suffix( $price = '', $date = null, $adult = null, $children = null ) {

		if ( $price === '' ) {
			$price = $this->get_price($date, $adult, $children);
		}

		$price_display_suffix  = it_get_option('price_display_suffix' );

		if ( $price_display_suffix ) {

			$price_display_suffix = ' <small class="intravel-price-suffix">' . $price_display_suffix . '</small>';

			$find = array(
				'{price_including_tax}',
				'{price_excluding_tax}'
			);

			$replace = array(
				it_price( $this->get_price_including_tax( $price, $date, $adult, $children ) ),
				it_price( $this->get_price_excluding_tax( $price, $date, $adult, $children ) )
			);

			$price_display_suffix = str_replace( $find, $replace, $price_display_suffix );
		}

		return apply_filters( 'intravel_get_price_suffix', $price_display_suffix, $this );
	}

	/**
	 * Returns the price in html format.
	 *
	 * @param string $price (default: '')
	 * @return string
	 */
	public function get_price_html( $price = '' ) {

		$display_price         = $this->get_display_price();
		$display_regular_price = $this->get_display_price( $this->get_regular_price() );

		if ( $this->get_price() > 0 ) {

			if ( $this->is_on_sale() && $this->get_regular_price() ) {

				$price .= $this->get_price_html_from_to( $display_regular_price, $display_price ) . $this->get_price_suffix();

				$price = apply_filters( 'intravel_sale_price_html', $price, $this );

			} else {

				$price .= wc_price( $display_price ) . $this->get_price_suffix();

				$price = apply_filters( 'intravel_price_html', $price, $this );

			}

		} elseif ( $this->get_price() === '' ) {

			$price = apply_filters( 'intravel_empty_price_html', '', $this );

		} elseif ( $this->get_price() == 0 ) {

			if ( $this->is_on_sale() && $this->get_regular_price() ) {

				$price .= $this->get_price_html_from_to( $display_regular_price, __( 'Free!', 'intravel' ) );

				$price = apply_filters( 'intravel_free_sale_price_html', $price, $this );

			} else {

				$price = '<span class="amount">' . __( 'Free!', 'intravel' ) . '</span>';

				$price = apply_filters( 'intravel_free_price_html', $price, $this );

			}
		}

		return apply_filters( 'intravel_get_price_html', $price, $this );
	}

	/**
	 * Functions for getting parts of a price, in html, used by get_price_html.
	 *
	 * @return string
	 */
	public function get_price_html_from_text() {
		$from = '<span class="from">' . _x( 'From:', 'min_price', 'intravel' ) . ' </span>';

		return apply_filters( 'intravel_get_price_html_from_text', $from, $this );
	}

	/**
	 * Functions for getting parts of a price, in html, used by get_price_html.
	 *
	 * @param  string $from String or float to wrap with 'from' text
	 * @param  mixed $to String or float to wrap with 'to' text
	 * @return string
	 */
	public function get_price_html_from_to( $from, $to ) {
		$price = '<del>' . ( ( is_numeric( $from ) ) ? wc_price( $from ) : $from ) . '</del> <ins>' . ( ( is_numeric( $to ) ) ? wc_price( $to ) : $to ) . '</ins>';

		return apply_filters( 'intravel_get_price_html_from_to', $price, $from, $to, $this );
	}

	/**
	 * Returns the tax class.
	 *
	 * @return string
	 */
	public function get_tax_class() {
		//return apply_filters( 'intravel_tour_tax_class', $this->tax_class, $this );
	}

	/**
	 * Returns the tax status.
	 *
	 * @return string
	 */
	public function get_tax_status() {
		//return $this->tax_status;
	}

	/**
	 * Get the average rating of tour. This is calculated once and stored in postmeta.
	 * @return string
	 */
	public function get_average_rating() {

		// No meta data? Do the calculation
		if ( ! metadata_exists( 'post', $this->id, '_it_average_rating' ) ) {
			$this->sync_average_rating( $this->id );
		}

		return (string) floatval( get_post_meta( $this->id, '_it_average_rating', true ) );
	}

	/**
	 * Sync tour rating. Can be called statically.
	 * @param  int $post_id
	 */
	public static function sync_average_rating( $post_id ) {
		if ( ! metadata_exists( 'post', $post_id, '_it_rating_count' ) ) {
			self::sync_rating_count( $post_id );
		}

		$count = array_sum( (array) get_post_meta( $post_id, '_it_rating_count', true ) );
		if ( $count ) {
			global $wpdb;

			$ratings = $wpdb->get_var( $wpdb->prepare("
				SELECT SUM(meta_value) FROM $wpdb->commentmeta
				LEFT JOIN $wpdb->comments ON $wpdb->commentmeta.comment_id = $wpdb->comments.comment_ID
				WHERE meta_key = 'rating'
				AND comment_post_ID = %d
				AND comment_approved = '1'
				AND meta_value > 0
			", $post_id ) );
			$average = number_format( $ratings / $count, 2, '.', '' );
		} else {
			$average = 0;
		}
		update_post_meta( $post_id, '_it_average_rating', $average );
	}

	/**
	 * Sync tour rating count. Can be called statically.
	 * @param  int $post_id
	 */
	public static function sync_rating_count( $post_id ) {
		global $wpdb;

		$counts     = array();
		$raw_counts = $wpdb->get_results( $wpdb->prepare("
			SELECT meta_value, COUNT( * ) as meta_value_count FROM $wpdb->commentmeta
			LEFT JOIN $wpdb->comments ON $wpdb->commentmeta.comment_id = $wpdb->comments.comment_ID
			WHERE meta_key = 'rating'
			AND comment_post_ID = %d
			AND comment_approved = '1'
			AND meta_value > 0
			GROUP BY meta_value
		", $post_id ) );

		foreach ( $raw_counts as $count ) {
			$counts[ $count->meta_value ] = $count->meta_value_count;
		}

		update_post_meta( $post_id, '_it_rating_count', $counts );
	}

	/**
	 * Get the total amount (COUNT) of ratings.
	 * @param  int $value Optional. Rating value to get the count for. By default returns the count of all rating values.
	 * @return int
	 */
	public function get_rating_count( $value = null ) {
		// No meta data? Do the calculation
		if ( ! metadata_exists( 'post', $this->id, '_it_rating_count' ) ) {
			$this->sync_rating_count( $this->id );
		}

		$counts = get_post_meta( $this->id, '_it_rating_count', true );

		if ( is_null( $value ) ) {
			return array_sum( $counts );
		} else {
			return isset( $counts[ $value ] ) ? $counts[ $value ] : 0;
		}
	}

	/**
	 * Returns the tour rating in html format.
	 *
	 * @param string $rating (default: '')
	 *
	 * @return string
	 */
	public function get_rating_html( $check_can_rating = false, $rating = null ) {
		$rating_html = '';

		if ( ! is_numeric( $rating ) ) {
			$rating = $this->get_average_rating();
		}
        $rating = floor($rating);
        if($check_can_rating && it_can_rating_destination($this->term_id)){
            wp_enqueue_style('barrating-fontawesome-stars');
            wp_enqueue_script('barrating');
            $rating_html .= '<select id="destination-rating" name="rating" autocomplete="off" data-destination="'.esc_attr($this->term_id).'" data-rating="4">
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
        	</select>';
        }
		elseif ( $rating > 0 ) {
			$rating_html  = '<div class="iw-star-rating">';
			$rating_html .= '<span class="rating" style="width:' . ( round( $rating / 5 , 2) * 100 ) . '%"></span>';
			$rating_html .= '</div>';
		}else{
			$rating_html  = '<div class="iw-star-rating">';
			$rating_html .= '<span class="rating"></span>';
			$rating_html .= '</div>';
		}
		return apply_filters( 'intravel_tour_get_rating_html', $rating_html, $rating );
	}

	/**
	 * Get the total amount (COUNT) of reviews.
	 *
	 * @since 2.3.2
	 * @return int The total numver of tour reviews
	 */
	public function get_review_count() {
		global $wpdb;

		// No meta date? Do the calculation
		if ( ! metadata_exists( 'post', $this->id, '_it_review_count' ) ) {
			$count = $wpdb->get_var( $wpdb->prepare("
				SELECT COUNT(*) FROM $wpdb->comments
				WHERE comment_parent = 0
				AND comment_post_ID = %d
				AND comment_approved = '1'
			", $this->id ) );

			update_post_meta( $this->id, '_it_review_count', $count );
		} else {
			$count = get_post_meta( $this->id, '_it_review_count', true );
		}

		return apply_filters( 'intravel_tour_review_count', $count, $this );
	}

	/**
	 * Returns the tour categories.
	 *
	 * @param string $sep (default: ', ')
	 * @param string $before (default: '')
	 * @param string $after (default: '')
	 * @return string
	 */
	public function get_categories( $sep = ', ', $before = '', $after = '' ) {
		return get_the_term_list( $this->id, 'tour_cat', $before, $sep, $after );
	}

	/**
	 * Returns the tour tags.
	 *
	 * @param string $sep (default: ', ')
	 * @param string $before (default: '')
	 * @param string $after (default: '')
	 * @return array
	 */
	public function get_tags( $args = '' ) {
        $tags = wp_get_post_terms( $this->id, 'tour_tag', $args );
        if (is_wp_error( $tags ) || !$tags ) {
            return array();
        }
        return $tags;


	}

    public function get_tag_list($sep = ', ', $before = '', $after = '') {
        $tags = get_the_term_list( $this->id, 'tour_tag', $before, $sep, $after );
        return $tags;
    }

	/**
	 * Get and return related tours.
	 *
	 * Notes:
	 * 	- Results are cached in a transient for faster queries.
	 *  - To make results appear random, we query and extra 10 tours and shuffle them.
	 *  - To ensure we always have enough results, it will check $limit before returning the cached result, if not recalc.
	 *  - This used to rely on transient version to invalidate cache, but to avoid multiple transients we now just expire daily.
	 *  	This means if a related tour is edited and no longer related, it won't be removed for 24 hours. Acceptable trade-off for performance.
	 *  - Saving a tour will flush caches for that tour.
	 *
	 * @param int $limit (default: 5)
	 * @return array Array of post IDs
	 */
	public function get_related( $limit = 5 ) {
		global $wpdb;

		$transient_name = 'wc_related_' . $this->id;
		$related_posts  = get_transient( $transient_name );

		// We want to query related posts if they are not cached, or we don't have enough
		if ( false === $related_posts || sizeof( $related_posts ) < $limit ) {
			// Related tours are found from category and tag
			$tags_array = $this->get_related_terms( 'tour_tag' );
			$cats_array = $this->get_related_terms( 'tour_cat' );

			// Don't bother if none are set
			if ( 1 === sizeof( $cats_array ) && 1 === sizeof( $tags_array )) {
				$related_posts = array();
			} else {
				// Sanitize
				$exclude_ids = array_map( 'absint', array_merge( array( 0, $this->id ), $this->get_upsells() ) );

				// Generate query - but query an extra 10 results to give the appearance of random results
				$query = $this->build_related_query( $cats_array, $tags_array, $exclude_ids, $limit + 10 );

				// Get the posts
				$related_posts = $wpdb->get_col( implode( ' ', $query ) );
			}

			set_transient( $transient_name, $related_posts, DAY_IN_SECONDS );
		}

		// Randomise the results
		shuffle( $related_posts );

		// Limit the returned results
		return array_slice( $related_posts, 0, $limit );
	}

	/**
	 * Gets the main tour image ID.
	 *
	 * @return int
	 */
	public function get_image_id() {

		if ( has_post_thumbnail( $this->id ) ) {
			$image_id = get_post_thumbnail_id( $this->id );
		} elseif ( ( $parent_id = wp_get_post_parent_id( $this->id ) ) && has_post_thumbnail( $parent_id ) ) {
			$image_id = get_post_thumbnail_id( $parent_id );
		} else {
			$image_id = 0;
		}

		return $image_id;
	}

	/**
	 * Returns the main tour image.
	 *
	 * @param string $size (default: 'shop_thumbnail')
	 * @param array $attr
	 * @return string
	 */
	public function get_image( $size = 'tours_thumbnail', $attr = array() ) {
		if ( has_post_thumbnail( $this->id ) ) {
			$image = get_the_post_thumbnail( $this->id, $size, $attr );
		} else {
			$image = wc_placeholder_img( $size );
		}

		return $image;
	}

	public function get_tickets_available($date, $type){
		global $wpdb;

		$purchased_tickets = $wpdb->get_var($wpdb->prepare("SELECT SUM(ticket.meta_value)
			FROM
			$wpdb->posts post
			INNER JOIN $wpdb->postmeta tour_booking ON tour_booking.post_id = post.ID
			AND tour_booking.meta_key = 'intravel_tour' 
			INNER JOIN $wpdb->postmeta status ON status.post_id = post.ID
			AND status.meta_key = 'intravel_status'
			INNER JOIN $wpdb->postmeta start_date ON start_date.post_id = post.ID
			AND start_date.meta_key = 'intravel_start_date'
			INNER JOIN $wpdb->postmeta ticket ON ticket.post_id = post.ID
			AND ticket.meta_key = 'intravel_".$type."_ticket'
		
			WHERE tour_booking.meta_value = %d
			 AND (status.meta_value = 'pending' OR status.meta_value = 'onhold' OR status.meta_value = 'completed')
			 AND start_date.meta_value = %s
			 AND post.post_status = 'publish'
			 AND post.post_type = 'tour_booking'
			 ", $this->id, $date));

		$tickets_available = $this->get_tickets($date, $type);
		//unlimited
		if($tickets_available === true){
			return true;
		}
		else{
			$tickets_available = $tickets_available - $purchased_tickets;
			return $tickets_available < 0 ? 0 : $tickets_available;
		}
	}

	/**
	 * Returns the tour's active price.
	 *
	 * @return string price
	 */
	public function get_tickets($date = null, $type = 'adult') {
		$tickets = 0;
		if(!$date){
			if($type = 'adult'){
				$tickets = $this->tickets;
			}
			else{
				$tickets = $this->children_tickets;
			}
		}else{
			$period = $this->get_period($date);
			if($period){
				if($type = 'adult'){
					$tickets = $period['tickets'];
				}
				else{
					$tickets = $period['children_tickets'];
				}
			}
		}

		return $tickets === '' ? true : abs($tickets);
	}
	
	public function get_period($date = null){
		static $period_value = array();
		if(!$date){
			$date = date('m/d/Y');
		}
		$key_value = md5($this->get_id(). '-'.$date);
		if(!isset($period_value[$key_value])){

            $period_value[$key_value] = false;
			$lday = date('l', strtotime($date));
			if(strtotime($this->start_date) <= strtotime($date)  && (!$this->end_date || strtotime($this->end_date) > strtotime($date)) && in_array($lday, (array)$this->available_days)){
				$period_value[$key_value] = array(
					'tickets' => $this->tickets,
					'children_tickets' => $this->children_tickets,
					'price' => $this->price,
					'children_price' => $this->children_price,
				);
			}

			$periods = $this->periods;
			if($periods && $periods !== 'null') {
				$periods = json_decode($periods, true);
				foreach ($periods as $period){
					if($period['active']){
						if(!$period['price']){
							$period['price'] = $this->price;
						}
						if(!$period['children_price']){
							$period['children_price'] = $this->children_price;
						}
						if(!$period['tickets']){
							$period['tickets'] = $this->tickets;
						}
						if(!$period['children_tickets']){
							$period['children_tickets'] = $this->children_tickets;
						}
						if($period['type'] == 'week'){
							$week = (array)$period['week'];
							$start_date = $period['start_date'];
							$end_date = $period['end_date'];
							if(strtotime($start_date) <= strtotime($date)  && (!$end_date || strtotime($end_date) >= strtotime($date)) && in_array($lday, $week)){
								$period_value[$key_value] = $period;
							}
						}
						elseif($period['type'] == 'exact_date')
						{
							$exact_dates = (array)$period['exact_date'];
							if(in_array($date, $exact_dates))
								$period_value[$key_value] = $period;
						}
					}
				}
			}
		}

		return $period_value[$key_value];
	}

	public function get_booking_days($from_date = null, $to_date = null){
		static $get_booking_days_value = array();

		$key_value = md5($this->get_id().'-'.$from_date.'-'.$to_date);
		if(!isset($get_booking_days_value[$key_value])) {
			$get_booking_days_value[$key_value] = false;

			if (!$from_date) {
				$now = time();
				$month = date("m", $now);
				$year = date("Y", $now);
			} else {
				list($month, $year, $day) = explode('-', $from_date);
			}
			$first = date('m/d/Y', mktime(0, 0, 0, $month, 1, $year));
			if ($to_date) {
				list($month, $year) = explode('-', $to_date);
			}
			$last = date('m/t/Y', mktime(0, 0, 0, $month, 1, $year));

			$days = array();
			$periods = $this->periods;
			if ($this->available_days && $this->start_date) {
				$start_date = $this->start_date;
				$end_date = $this->end_date;
				if (strtotime($start_date) < strtotime($first)) {
					$start_date = $first;
				}

				if (!$end_date || strtotime($end_date) > strtotime($last)) {
					$end_date = $last;
				}

				$firstTime = strtotime($start_date);
				$endTime = strtotime($end_date);

				while ($firstTime <= $endTime) {
					$lday = date('l', $firstTime);
					if (in_array($lday, (array)$this->available_days)) {
						$days[date('m/d/Y', $firstTime)] = array('', sprintf(__("Adult: %s\nChildren: %s", 'intravel'), it_price($this->get_display_price($this->price)), it_price($this->get_display_price($this->get_display_price($this->children_price)))));
					}
					$firstTime = strtotime('+1 day', $firstTime); // increment for loop
				}
			}

			if ($periods && $periods !== 'null') {
				$periods = json_decode($periods, true);
				foreach ($periods as $period) {
					if ($period['active']) {
						if ($period['type'] == 'week') {
							$week = (array)$period['week'];
							$start_date = $period['start_date'];
							$end_date = $period['end_date'];
							if (strtotime($start_date) < strtotime($first)) {
								$start_date = $first;
							}
							if (!$end_date || strtotime($end_date) > strtotime($last)) {
								$end_date = $last;
							}

							$firstTime = strtotime($start_date);
							$endTime = strtotime($end_date);
							while ($firstTime <= $endTime) {
								$lday = date('l', $firstTime);
								if (in_array($lday, $week)) {
									$class = '';
									if ($period['price']) {
										$class .= "special-price";
										if ($period['price'] > $this->get_price()) {
											$class .= " inc-price";
										} else {
											$class .= " sale-price";
										}
									}
									$tooltip = sprintf(__("Adult: %s\nChildren: %s", 'intravel'), it_price($this->get_display_price($period['price'])), it_price($this->get_display_price($period['children_price'])));
									$days[date('m/d/Y', $firstTime)] = array($class, $tooltip);
								}
								$firstTime = strtotime('+1 day', $firstTime); // increment for loop
							}
						} elseif ($period['type'] == 'exact_date') {
							$exact_dates = (array)$period['exact_date'];
							foreach ($exact_dates as $exact_date) {
								if (strtotime($exact_date) >= strtotime($first) && strtotime($exact_date) <= strtotime($last)) {
									$class = '';
									if ($period['price']) {
										$class .= "special-price";
										if ($period['price'] > $this->get_price()) {
											$class .= " inc-price";
										} else {
											$class .= " sale-price";
										}
									}
									$tooltip = sprintf(__("Adult: %s\nChildren: %s", 'intravel'), it_price($this->get_display_price($period['price'])), it_price($this->get_display_price($period['children_price'])));
									$days[$exact_date] = array($class, $tooltip);
								}
							}
						}
					}
				}
			}

			$get_booking_days_value[$key_value] = $days;
		}

		return $get_booking_days_value[$key_value];
	}

	public function get_booking_day(){
		$current_date = date('m/d/Y');
		$booking_days = $this->get_booking_days();
		if(array_key_exists($current_date, $booking_days)){
			return $current_date;
		}
		elseif($booking_days){
			foreach ($booking_days as $day => $value){
				if(strtotime($current_date) < strtotime($day)){
					return $day;
				}
			}
		}

		return '';
	}

    function get_destinations(){
        $terms = get_the_terms( $this->id, 'destination' );

        return $terms;
    }

    function get_tour_tag(){
        $terms = get_the_terms( $this->id, 'tour_tag' );

        return $terms;
    }

    public function get_duration(){
        $duration = get_post_meta($this->post->ID, 'intravel_duration', true);

        return $duration;
    }

	/**
	 * Retrieves related tour terms.
	 *
	 * @param string $term
	 * @return array
	 */
	protected function get_related_terms( $term ) {
		$terms_array = array(0);

		$terms = apply_filters( 'intravel_get_related_' . $term . '_terms', wp_get_post_terms( $this->id, $term ), $this->id );
		foreach ( $terms as $term ) {
			$terms_array[] = $term->term_id;
		}

		return array_map( 'absint', $terms_array );
	}

	/**
	 * Builds the related posts query.
	 *
	 * @param array $cats_array
	 * @param array $tags_array
	 * @param array $exclude_ids
	 * @param int   $limit
	 * @return string
	 */
	protected function build_related_query( $cats_array, $tags_array, $exclude_ids, $limit ) {
		global $wpdb;

		$limit = absint( $limit );

		$query           = array();
		$query['fields'] = "SELECT DISTINCT ID FROM {$wpdb->posts} p";
		$query['join']   = " INNER JOIN {$wpdb->postmeta} pm ON ( pm.post_id = p.ID AND pm.meta_key='_visibility' )";
		$query['join']  .= " INNER JOIN {$wpdb->term_relationships} tr ON (p.ID = tr.object_id)";
		$query['join']  .= " INNER JOIN {$wpdb->term_taxonomy} tt ON (tr.term_taxonomy_id = tt.term_taxonomy_id)";
		$query['join']  .= " INNER JOIN {$wpdb->terms} t ON (t.term_id = tt.term_id)";

		if ( it_get_option('hide_out_of_stock_items' ) === 'yes' ) {
			$query['join'] .= " INNER JOIN {$wpdb->postmeta} pm2 ON ( pm2.post_id = p.ID AND pm2.meta_key='_stock_status' )";
		}

		$query['where']  = " WHERE 1=1";
		$query['where'] .= " AND p.post_status = 'publish'";
		$query['where'] .= " AND p.post_type = 'tour'";
		$query['where'] .= " AND p.ID NOT IN ( " . implode( ',', $exclude_ids ) . " )";
		$query['where'] .= " AND pm.meta_value IN ( 'visible', 'catalog' )";

		if ( it_get_option('hide_out_of_stock_items' ) === 'yes' ) {
			$query['where'] .= " AND pm2.meta_value = 'instock'";
		}

		if ( apply_filters( 'intravel_tour_related_posts_relate_by_category', true, $this->id ) ) {
			$query['where'] .= " AND ( tt.taxonomy = 'tour_cat' AND t.term_id IN ( " . implode( ',', $cats_array ) . " ) )";
			$andor = 'OR';
		} else {
			$andor = 'AND';
		}

		// when query is OR - need to check against excluded ids again
		if ( apply_filters( 'intravel_tour_related_posts_relate_by_tag', true, $this->id ) ) {
			$query['where'] .= " {$andor} ( ( tt.taxonomy = 'tour_tag' AND t.term_id IN ( " . implode( ',', $tags_array ) . " ) )";
			$query['where'] .= " AND p.ID NOT IN ( " . implode( ',', $exclude_ids ) . " ) )";
		}

		$query['limits'] = " LIMIT {$limit} ";
		$query           = apply_filters( 'intravel_tour_related_posts_query', $query, $this->id );

		return $query;
	}

    function get_ancestors($destination){
        $html = array();
        $parents = get_ancestors($destination->term_id, 'destination');
        if($parents){
            foreach ($parents as $destination_id){
                $destination = get_term( $destination_id, 'destination' );
                $html[] = '<a href="'.get_term_link($destination, 'destination').'">'.$destination->name.'</a>';
            }
        }

        if($html){
            return $html[0];
        }

        return '';
    }

    function get_start_time(){
        $start_time = $this->start_time;
        if($start_time){
            $start_time = explode("\r\n", $start_time);
        }

        return $start_time;
    }
}
