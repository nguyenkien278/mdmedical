<?php

/*
 * Inwave_Heading for Visual Composer
 */
if (!class_exists('InTravel_Locations')) {

    class InTravel_Locations extends Inwave_Shortcode{

		protected $name = 'intravel_destinations';

		function init_params() {
            return array(
                'name' => __('Tour Destinations', 'inwavethemes'),
                'description' => __('Destinations of intravel', 'inwavethemes'),
                'base' => $this->name,
                'icon' => 'iw-default',
                'category' => 'Custom',
                'params' => array(
                    array(
                        "type" => "dropdown",
                        "admin_label" => true,
                        "heading" => "Style",
                        "param_name" => "style",
                        "value" => array(
                            "Style 1 - Carousel Slider" => "style1",
                            "Style 2 - Carousel Slider V2" => "style2",
							"Style 3 - List Destinations grid" => "style3",
                        )
                    ),
                    array(
                        "type" => "iwevent_preview_image",
                        "heading" => __("Preview Style", "inwavethemes"),
                        "param_name" => "preview_style1",
                        "value" => get_template_directory_uri() . '/assets/images/shortcodes/preview-destinations-style1.jpg',
                        "dependency" => array('element' => 'style', 'value' => 'style1')
                    ),
                    array(
                        "type" => "iwevent_preview_image",
                        "heading" => __("Preview Style", "inwavethemes"),
                        "param_name" => "preview_style2",
                        "value" => get_template_directory_uri() . '/assets/images/shortcodes/preview-destinations-style2.jpg',
                        "dependency" => array('element' => 'style', 'value' => 'style2')
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Image Width", "inwavethemes"),
                        "description" => __("Image Width in px", "inwavethemes"),
                        "param_name" => "image_width",
                        "value" => '370',
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Image Height", "inwavethemes"),
                        "description" => __("Image Height in px", "inwavethemes"),
                        "param_name" => "image_height",
                        "value" => '285',
                    ),
					array(
						"type" => "textfield",
						"heading" => __("Limit", "inwavethemes"),
						"param_name" => "limit",
						"value" => '8',
					),
					array(
						"type" => "textfield",
						"heading" => __("Offset", "inwavethemes"),
						"param_name" => "offset",
						"value" => '',
					),
					array(
						"type" => "textfield",
						"heading" => __("Parent ID", "inwavethemes"),
						"param_name" => "parent_id",
						"value" => '',
					),
					array(
						"type" => "textfield",
						"heading" => __("Include Location IDs", "inwavethemes"),
						"param_name" => "include_ids",
						"value" => '',
					),
					array(
						"type" => "textfield",
						"heading" => __("Exclude Location IDs", "inwavethemes"),
						"param_name" => "exclude_ids",
						"value" => '',
					),
					array(
						"type" => "dropdown",
						"heading" => __("Hide Empty", 'inwavethemes'),
						"param_name" => "hide_empty",
						"value" => array(
							"No" => "0",
							"Yes" => "1",
						),
					),
					array(
						"type" => "dropdown",
						"heading" => __("Order By", 'inwavethemes'),
						"param_name" => "order_by",
						"value" => array(
							"Ordering" => "",
							"ID" => "id",
							"Name" => "name",
							"Count" => "count",
							"Popular" => "popular",
							"Rating" => "rating",
						),
					),
					array(
						"type" => "dropdown",
						"heading" => __("Order Direction", 'inwavethemes'),
						"param_name" => "order_dir",
						"value" => array(
							"Descending" => "DESC",
							"Ascending" => "ASC",
						),
					),
                    array(
                        "type" => "textfield",
                        "class" => "",
                        "heading" => "Number of description words",
                        "param_name" => "desc_text_limit",
                        "value" => '20',
                        "dependency" => array('element' => 'style', 'value' => array('style1', 'style3'))
                    ),
                    array(
                        "type" => "textfield",
                        "group" => "Carousel Options",
                        "heading" => __("Items Desktop", "inwavethemes"),
                        "param_name" => "item_desktop",
                        "value" => '3',
                        "dependency" => array('element' => 'style', 'value' => 'style1')
                    ),
                    array(
                        "type" => "textfield",
                        "group" => "Carousel Options",
                        "heading" => __("Items Desktop Small", "inwavethemes"),
                        "param_name" => "item_desktop_small",
                        "value" => '2',
                        "dependency" => array('element' => 'style', 'value' => 'style1')
                    ),
                    array(
                        "type" => "dropdown",
                        "group" => "Carousel Options",
                        "heading" => __("Pagination", "inwavethemes"),
                        "param_name" => "pagination_style",
                        "value" => array(
                            'Light' => 'light',
                            'Dot' => 'dot',
                            'Number' => 'number'
                        )
                    ),
                    array(
                        "type" => "dropdown",
                        "group" => "Carousel Options",
                        "heading" => __("AutoPlay Slider", "inwavethemes"),
                        "param_name" => "auto_play",
                        "value" => array(
                            'No' => 'no',
                            'Yes' => 'yes'
                        )
                    ),
                )
            );
        }

        // Shortcode handler function for list Icon
        function init_shortcode($atts, $content = null) {

			if(!class_exists('inTravel')){
				return __('Please active the plugin inTravel', 'inwavethemes');
			}

			$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( $this->name, $atts ) : $atts;

			$output = $style = $class = '';
            extract(shortcode_atts(array(
                'style' => 'style1',
                'image_width' => '',
                'image_height' => '',
				'limit' => '',
				'offset' => '',
				'parent_id' => '',
				'hide_empty' => '',
				'include_ids' => '',
                'exclude_ids' => '',
                'order_by' => '',
                'order' => '',
                'order_dir' => '',
                'desc_text_limit' => '',
                'item_desktop' => '',
                'item_desktop_small' => '',
                'pagination_style' => '',
                'auto_play' => '',
			), $atts));

			$order_by_default = $order_by;
			$order_default = $order;

			$offset = (int)$offset;
			$page = 1;
			if(get_query_var('paged')){
				$page = get_query_var( 'paged' );
				$offset = ( $page-1 ) * $limit;
			}
            if(isset($_GET['order_by'])){
                $order_by = $_GET['order_by'];
            }
            if(isset($_GET['order'])){
                $order = $_GET['order'];
            }
            $keyword = '';
            if(isset($_GET['keyword'])){
                $keyword = $_GET['keyword'];
            }

            $class = ' '.$style.' '.$pagination_style;
			if($order_by == 'popular'){
				$page = ( get_query_var('paged') ) ? get_query_var( 'paged' ) : 1;
				$offset = ( $page-1 ) * $limit;
				$destinations = it_get_popular_destinations(array(
					'number' => ($limit ? $limit : 0),
                    'order' => $order,
                    'search' => $keyword,
					'offset' => $offset,
					'parent' => $parent_id,
					'hide_empty' => $hide_empty,
					'order_dir' => $order_dir,
					'include' => ($include_ids ? explode(',', $include_ids) : array()),
					'exclude' => ($exclude_ids ? explode(',', $exclude_ids) : array()),
				));
			}elseif($order_by == 'rating'){
				$args = array(
					'taxonomy' => 'destination',
					'meta_key' => 'average_rating',
					'orderby' => 'meta_value_num',
					'order' => $order,
					'search' => $keyword,
					'hide_empty' => (int)$hide_empty,
					'include' => ($include_ids ? explode(',', $include_ids) : array()),
					'exclude' => ($exclude_ids ? explode(',', $exclude_ids) : array()),
					'number' => ($limit ? $limit : 0),
					'offset' => ($offset ? $offset : ''),
					'parent' => $parent_id,
				);
				$destinations = get_terms($args);
			}
			else{
				$args = array(
					'taxonomy' => 'destination',
					'orderby' => $order_by,
					'order' => $order,
					'search' => $keyword,
					'hide_empty' => (int)$hide_empty,
					'include' => ($include_ids ? explode(',', $include_ids) : array()),
					'exclude' => ($exclude_ids ? explode(',', $exclude_ids) : array()),
					'number' => ($limit ? $limit : 0),
					'offset' => ($offset ? $offset : ''),
					'parent' => $parent_id,
				);
				$destinations = get_terms($args);
			}

            $data_plugin_options = array(
                "navigation"=>false,
                "autoHeight"=>true,
                "pagination"=>true,
                "autoPlay"=>$auto_play == 'yes' ? true : false,
                "paginationNumbers"=> $pagination_style == 'number' ? true : false,
                "items"=>$style == 'style2' ? '1' : $item_desktop,
                "itemsDesktop"=>array(1199, $style == 'style2' ? '1' : $item_desktop),
                "itemsDesktopSmall"=>array(991, $style == 'style2' ? '1' : $item_desktop_small),
                "itemsTablet"=>array(767, 2),
                "itemsTabletSmall"=>false,
                "itemsMobile"=>array(479, 1),
                "navigationText" => array("back", "next")
            );

			wp_enqueue_style('weather-icons');
			wp_enqueue_style('weather-icons-wind');


            switch ($style) {
                // Carousel style1
                case 'style1':
					wp_enqueue_style('owl-carousel');
					wp_enqueue_style('owl-theme');
					wp_enqueue_style('owl-transitions');
					wp_enqueue_script('owl-carousel');
                    $output .= '<div class="intravel-destinations ' . $class . '">';
                    $output .= '<div class="owl-carousel" data-plugin-options="'.htmlspecialchars(json_encode($data_plugin_options)).'">';
                    foreach ($destinations as $destination){
                        if(!is_object($destination)) $destination = get_term($destination, 'destination');
                        $image = get_term_meta($destination->term_id, 'intravel_image', true);
                        $image_url = '';
                        if(!empty($image)){
                            $image_url = inwave_resize($image, $image_width, $image_height, true);
                        }

                        if(!$image_url){
                            $image_url = it_get_placeholder_image();
                        }

                        $output .= '<div class="destination-item iw-effect-1">';
                        $output .= '<img src="'.esc_url($image_url).'" alt=""/>';
//                        $output .= '<div class="weather">'.$this->get_weather_icon($destination).'</div>';
                        $output .= '<div class="content">';
                        $output .= '<div class="content-top">';
                        $output .= '<h2>'.$destination->name.'</h2>';
                        $output .= '<ul>';
                        if ($this->get_ancestors($destination)) {
                            $output .= '<li class="meta-destination"><i class="fa fa-map-marker"></i> '.$this->get_ancestors($destination).'</li>';
                        }
						$total_tours = $this->get_total_tours($destination);
						$output .= '<li class="meta-tour"><i class="tour-icon"></i> '.sprintf(_n('%d tour', '%d tours', $total_tours, 'inwavethemes'), $total_tours). '</li>';
                        $output .= '</ul>';
                        $output .= '</div>';
                        $output .= '<div class="content-bottom">';
                        $output .= '<div class="description">'.wp_trim_words($destination->description, $desc_text_limit).'</div>';
                        $output .= '<div class="destination-detail-v2"><a href="'.get_term_link($destination->slug, 'destination').'">'.__("Discover", 'inwavethemes').' <i class="icon ion-arrow-right-c"></i></a></div>';
                        $output .= '</div>';
                        $output .= '</div>';
                        $output .= '</div>';
                    }
                    $output .= '</div>';
                    $output .= '</div>';
                    break;

                // Carousel style 2
                case 'style2':
					wp_enqueue_style('owl-carousel');
					wp_enqueue_style('owl-theme');
					wp_enqueue_style('owl-transitions');
					wp_enqueue_script('owl-carousel');
                    $output .= '<div class="intravel-destinations ' . $class . '">';
                    $output .= '<div class="owl-carousel" data-plugin-options="'.htmlspecialchars(json_encode($data_plugin_options)).'">';
                    $output .= '<div class="destination-items">';
                    $output .= '<div class="row">';
                    $i = 0;
                    foreach ($destinations as $destination){
                        if(!is_object($destination)) $destination = get_term($destination, 'destination');
                        $image = get_term_meta($destination->term_id, 'intravel_image', true);
                        $image_url = '';
                        if(!empty($image)){
                            $image_url = inwave_resize($image, $image_width, $image_height, true);
                        }

                        if(!$image_url){
                            $image_url = it_get_placeholder_image();
                        }

                        $destination_class = it_get_detination($destination);
                        $average_rating_destination = $destination_class->get_average_rating();

                        if($i > 0 && count($destinations) > $i && $i % 6 == 0){
                            $output .= '</div>';
                            $output .= '</div>';
                            $output .= '<div class="destination-items">';
                            $output .= '<div class="row">';
                        }
//                        $output .= '<div class="col-md-6 col-sm-6 col-xs-12">';
                        $output .= '<div class="destination-item">';
                        $output .= '<div class="img-wrap"><img src="'.esc_url($image_url).'" alt=""/></div>';
                        $output .= '<div class="content">';
                        $output .= '<h3><a href="'.get_term_link($destination->slug, 'destination').'">'.wp_trim_words($destination->name, 2).'</a></h3>';
                        $destination_class = it_get_detination($destination);
                        $output .= '<div class="destination-rating">';
                        $output .= $destination_class->get_rating_html();
                        $output .= '</div>';
                        $output .= '<div class="all-tours"><a href="'. add_query_arg('destination',$destination->slug, it_get_page_permalink('tours')) .'">'.__("View all tours", 'inwavethemes').'</a></div>';
                        $output .= '</div>';
                        $output .= '<div class="clearfix"></div>';
                        $output .= '</div>';
//                        $output .= '</div>';
                        $i ++;
                    }
                    $output .= '</div>';
                    $output .= '</div>';
                    $output .= '</div>';
                    $output .= '</div>';
                    break;

				case 'style3':
					wp_enqueue_style('select2');
                    $keyword = isset($_REQUEST['keyword']) ? $_REQUEST['keyword'] : '';
                    $output .= '<div class="intravel-destinations-grid ' . $class . '">';
					$output .= '<div class="destinations-grid-filter">';
                    $output .= '<form id="filterForm" name="filterForm" method="get" action="'.esc_url(get_permalink()).'">';
                    $output .= '<div class="destinations-grid-filter-inner">';
                    $output .= '<span class="input-text-wrap">
                    <input class="input-text" type="text" placeholder="'.__("Enter your destination", "inwavethemes").'" name="keyword" value="' . $keyword . '">
                    </span>';
                    $output .= '
								<select class="js-selected" name="order_by">
									<option value="" '.($order_by == '' ? 'selected' : '').'>'.__('Order by', 'intravel').'</option>
									<option value="name" '.($order_by == 'name' ? 'selected' : '').'>'.__('Name', 'intravel').'</option>
									<option value="count" '.($order_by == 'count' ? 'selected' : '').'>'.__('Count', 'intravel').'</option>
									<option value="popular" '.($order_by == 'popular' ? 'selected' : '').'>'.__('Popular', 'intravel').'</option>
									<option value="rating" '.($order_by == 'rating' ? 'selected' : '').'>'.__('Rating', 'intravel').'</option>
								</select>
					';
                    $output .= '
								<select class="js-selected" name="order">
									<option value="DESC" '.($order == 'DESC' ? 'selected' : '').'>'.__('DESC', 'intravel').'</option>
									<option value="ASC" '.($order == 'ASC' ? 'selected' : '').'>'.__('ASC', 'intravel').'</option>
								</select>
					';
                    $output .= '<button class="button-filter theme-bg" type="submit">'.__("Search", "inwavethemes").' <i class="fa fa-paper-plane"></i></button>';
                    $output .= '</div>';
                    $output .= '<div class="clear"></div>';
                    $output .= '</form>';
					$output .= '</div>';
                    $output .= '<div class="row">';
                    foreach ($destinations as $destination){
						$output .= '<div class="col-md-4 col-sm-6 col-xs-12">';
                        if(!is_object($destination)) $destination = get_term($destination, 'destination');
                        $image = get_term_meta($destination->term_id, 'intravel_image', true);
                        $image_url = '';
                        if(!empty($image)){
                            $image_url = inwave_resize($image, $image_width, $image_height, true);
                        }

                        if(!$image_url){
                            $image_url = it_get_placeholder_image();
                            $image_url = inwave_resize($image_url, $image_width, $image_height, true);
                        }

                        $output .= '<div class="destination-item">';
						$output .= '<div class="destination-image">';
                        $output .= '<img src="'.esc_url($image_url).'" alt=""/>';
						$output .= '</div>';
//                        $output .= '<div class="weather">'.$this->get_weather_icon($destination).'</div>';
                        $output .= '<div class="destination-detail">';
						$output .= '<div class="destination-head">';
                        $output .= '<h3 class="title"><a href="'.get_term_link($destination->slug, 'destination').'">'.$destination->name.'</a></h3>';
                        $output .= '<ul class="meta">';
                        if ($this->get_ancestors($destination)) {
                            $output .= '<li class="meta-destination"><i class="fa fa-map-marker"></i> '.$this->get_ancestors($destination).'</li>';
                        }
						$total_tours = $this->get_total_tours($destination);
						$output .= '<li class="meta-tour"><i class="tour-icon"></i> '.sprintf(_n('%d tour', '%d tours', $total_tours, 'inwavethemes'), $total_tours). '</li>';
                        $output .= '</ul>';
						$output .= '</div>';
						$output .= '<div class="destination-content">';
						if ($destination->description){
							$output .= '<div class="description">'.wp_trim_words($destination->description, $desc_text_limit, null).'</div>';
						}
						$destination_class = it_get_detination($destination);
						$output .= '<div class="destination-rating">';
							$output .= $destination_class->get_rating_html();
						$output .= '</div>';
                        $output .= '<div class="destination-to-detail"><a href="'.get_term_link($destination->slug, 'destination').'">'.__("Discover ", 'inwavethemes').'<i class="ion-arrow-right-c"></i></a></div>';
                        $output .= '</div>';
						$output .= '</div>';
                        $output .= '</div>';
						$output .= '</div>';
                    }

                    $output .= '</div>';

					//pagination
					$total_terms = wp_count_terms( 'destination' , array('search' => $keyword, 'hide_empty' => (int)$hide_empty));
                        if ($limit) {
                            $pages = ceil($total_terms/$limit);
                            // if there's more than one page
                            if( $pages > 1 ){
                                $output .= '<div class="page-nav destination-nav">';

                                for ($pagecount=1; $pagecount <= $pages; $pagecount++){
                                    $pagination_link = get_permalink().'page/'.$pagecount;
                                    if($keyword){
                                        $pagination_link = add_query_arg('keyword', $keyword ,$pagination_link);
                                    }
                                    if($order_by && $order_by_default != $order_by){
                                        $pagination_link = add_query_arg('order_by', $order_by, $pagination_link );
                                    }
                                    if($order  && $order_default != $order){
                                        $pagination_link = add_query_arg('order', $order, $pagination_link );
                                    }

                                    //$output .=  '<div'.($page == $pagecount ? ' class="active"':'').'><a href="'.get_permalink().'page/'.$pagecount.'/">'.$pagecount.'</a></div>';
                                    if ($page == $pagecount){
                                        $output .= '<span class="page-numbers current">'.$pagecount.'</span>';
                                    } else {
                                        $output .= '<a class="page-numbers" href="'.esc_url($pagination_link).'">'.$pagecount.'</a>';
                                    }
                                }

                                $output .= '</div>';
                            }
                        }
					//end pagination
                    $output .= '</div>';
                break;
            }

            return $output;
        }

		function iwbDisplayPagination($query = '') {
			if (!$query) {
				global $wp_query;
				$query = $wp_query;
			}

			$big = 999999999; // need an unlikely integer

			$paginate_links = paginate_links(array(
				'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
				'format' => '?paged=%#%',
				'current' => max(1, get_query_var('paged')),
				'total' => $query->max_num_pages,
				'next_text' => '&raquo;',
				'prev_text' => '&laquo'
			));
			// Display the pagination if more than one page is found
			if ($paginate_links) :
				?>

				<div class="iwbvent-pagination clearfix">
					<?php echo $paginate_links; ?>
				</div>

				<?php
			endif;
		}

		function get_destination_title($destination){
			$title = array();
			$title[] = $destination->name;
			$parents = get_ancestors($destination->term_id, 'destination');
			if($parents){
				foreach ($parents as $destination_id){
					$destination = get_term( $destination_id, 'destination' );
					$title[] = $destination->name;
				}
			}

			$title = array_reverse($title);

			return implode($title , ' / ');
		}

        function get_total_tours($destination){
            global $wpdb;

            $total = $wpdb->get_var( $wpdb->prepare( "
				SELECT COUNT(*) FROM {$wpdb->posts} as post
				LEFT JOIN {$wpdb->term_relationships} as term_relationships ON term_relationships.object_id = post.ID
				WHERE post.post_type = 'tour'
				AND (post.post_status = 'publish' || post.post_status = 'private')
				AND term_relationships.term_taxonomy_id = %d
				", $destination->term_id));
            return $total;
        }

        function get_ancestors($destination){
            $html = array();
            $parents = get_ancestors($destination->term_id, 'destination');
            if($parents){
                foreach ($parents as $destination_id){
                    $destination = get_term( $destination_id, 'destination' );
                    $html[] = '<a href="'.get_term_link($destination, 'destination').'">'.$destination->name.'</a>';
                }
            }

            if($html){
                return $html[0];
            }

            return '';
        }

		function get_weather_icon($term){
			$icon_string = '';
			$openweathermap_city_id = get_term_meta($term->term_id, 'intravel_openweathermap_city_id', true);
			if($openweathermap_city_id){
				$query_string = "id=" . $openweathermap_city_id;
			}
			else{
				$query_string = "q=" . urlencode($term->name);
			}

			$appid_string = '&appid=c0a379927943bdfb5889020faf0a1459';

			$transient_name = 'intravel_openweathermap_' . $query_string;
			if(get_transient( $transient_name )){
				$weather_data = get_transient( $transient_name );
			}
			else{

				$forecast_ping = "http://api.openweathermap.org/data/2.5/forecast/daily?" . $query_string . "&cnt=7" . $appid_string;

				$forecast_ping_get = wp_remote_get( $forecast_ping );
				if( is_wp_error( $forecast_ping_get ) )
				{
					return $forecast_ping_get->get_error_message();
				}

				$weather_data = json_decode( $forecast_ping_get['body'] );

				if( isset($weather_data->cod) AND $weather_data->cod == 404 )
				{
					return $weather_data->message;
				}
				else
				{
					set_transient( $transient_name, $weather_data, 1800);
				}
			}
			if($weather_data && $weather_data->list){
				$dt_today = date( 'Ymd', current_time( 'timestamp', 0 ) );
				$i = 1;
				foreach( (array) $weather_data->list as $forecast )
				{
					if($i > 3) break;

					if( $dt_today > date('Ymd', $forecast->dt)) continue;
					if(isset($forecast->weather[0]->id)){
						$icon_string .= '<span class="'.$this->get_icon($forecast->weather[0]->id).'"></span>';
					}
					$i++;
				}
			}

			return $icon_string;
		}

		function get_icon($code)
		{
			//https://gist.github.com/tbranyen/62d974681dea8ee0caa1

			$icons = array();
			//"label": "thunderstorm with light rain",
			$icons['200'] = 'storm-showers';
			//"label": "thunderstorm with rain",
			$icons['201'] = 'storm-showers';
			//"label": "thunderstorm with heavy rain",
			$icons['202'] = 'storm-showers';
			//"label": "light thunderstorm",
			$icons['210'] = 'storm-showers';
			//"label": "thunderstorm",
			$icons['211'] = 'thunderstorm';
			//"label": "heavy thunderstorm",
			$icons['212'] = 'thunderstorm';
			//"label": "ragged thunderstorm",
			$icons['221'] = 'thunderstorm';
			//"label": "thunderstorm with light drizzle",
			$icons['230'] = 'storm-showers';
			//"label": "thunderstorm with drizzle",
			$icons['231'] = 'storm-showers';
			//"label": "thunderstorm with heavy drizzle",
			$icons['232'] = 'storm-showers';
			//"label": "light intensity drizzle",
			$icons['300'] = 'sprinkle';
			//"label": "drizzle",
			$icons['301'] = 'sprinkle';
			//"label": "heavy intensity drizzle",
			$icons['302'] = 'sprinkle';
			//"label": "light intensity drizzle rain",
			$icons['310'] = 'sprinkle';
			//"label": "drizzle rain",
			$icons['311'] = 'sprinkle';
			//"label": "heavy intensity drizzle rain",
			$icons['312'] = 'sprinkle';
			//"label": "shower rain and drizzle",
			$icons['313'] = 'sprinkle';
			//"label": "heavy shower rain and drizzle",
			$icons['314'] = 'sprinkle';
			//"label": "shower drizzle",
			$icons['321'] = 'sprinkle';
			//"label": "light rain",
			$icons['500'] = 'rain';
			//"label": "moderate rain",
			$icons['501'] = 'rain';
			//"label": "heavy intensity rain",
			$icons['502'] = 'rain';
			//"label": "very heavy rain",
			$icons['503'] = 'rain';
			//"label": "extreme rain",
			$icons['504'] = 'rain';
			//"label": "freezing rain",
			$icons['511'] = 'rain-mix';
			//"label": "light intensity shower rain",
			$icons['520'] = 'showers';
			//"label": "shower rain",
			$icons['521'] = 'showers';
			//"label": "heavy intensity shower rain",
			$icons['522'] = 'showers';
			//"label": "ragged shower rain",
			$icons['531'] = 'showers';
			//"label": "light snow",
			$icons['600'] = 'snow';
			//"label": "snow",
			$icons['601'] = 'snow';
			//"label": "heavy snow",
			$icons['602'] = 'snow';
			//"label": "sleet",
			$icons['611'] = 'sleet';
			//"label": "shower sleet",
			$icons['612'] = 'sleet';
			//"label": "light rain and snow",
			$icons['615'] = 'rain-mix';
			//"label": "rain and snow",
			$icons['616'] = 'rain-mix';
			//"label": "light shower snow",
			$icons['620'] = 'rain-mix';
			//"label": "shower snow",
			$icons['621'] = 'rain-mix';
			//"label": "heavy shower snow",
			$icons['622'] = 'rain-mix';
			//"label": "mist",
			$icons['701'] = 'sprinkle';
			//"label": "smoke",
			$icons['711'] = 'smoke';
			//"label": "haze",
			$icons['721'] = 'day-haze';
			//"label": "sand, dust whirls",
			$icons['731'] = 'cloudy-gusts';
			//"label": "fog",
			$icons['741'] = 'fog';
			//"label": "sand",
			$icons['751'] = 'cloudy-gusts';
			//"label": "dust",
			$icons['761'] = 'dust';
			//"label": "volcanic ash",
			$icons['762'] = 'smog';
			//"label": "squalls",
			$icons['771'] = 'day-windy';
			//"label": "tornado",
			$icons['781'] = 'tornado';
			//"label": "clear sky",
			$icons['800'] = 'sunny';
			//"label": "few clouds",
			$icons['801'] = 'cloudy';
			//"label": "scattered clouds",
			$icons['802'] = 'cloudy';
			//"label": "broken clouds",
			$icons['803'] = 'cloudy';
			//"label": "overcast clouds",
			$icons['804'] = 'cloudy';
			//"label": "tornado",
			$icons['900'] = 'tornado';
			//"label": "tropical storm",
			$icons['901'] = 'hurricane';
			//"label": "hurricane",
			$icons['902'] = 'hurricane';
			//"label": "cold",
			$icons['903'] = 'snowflake-cold';
			//"label": "hot",
			$icons['904'] = 'hot';
			//"label": "windy",
			$icons['905'] = 'windy';
			//"label": "hail",
			$icons['906'] = 'hail';
			//"label": "calm",
			$icons['951'] = 'sunny';
			//"label": "light breeze",
			$icons['952'] = 'cloudy-gusts';
			//"label": "gentle breeze",
			$icons['953'] = 'cloudy-gusts';
			//"label": "moderate breeze",
			$icons['954'] = 'cloudy-gusts';
			//"label": "fresh breeze",
			$icons['955'] = 'cloudy-gusts';
			//"label": "strong breeze",
			$icons['956'] = 'cloudy-gusts';
			//"label": "high wind, near gale",
			$icons['957'] = 'cloudy-gusts';
			//"label": "gale",
			$icons['958'] = 'cloudy-gusts';
			//"label": "severe gale",
			$icons['959'] = 'cloudy-gusts';
			//"label": "storm",
			$icons['960'] = 'thunderstorm';
			//"label": "violent storm",
			$icons['961'] = 'thunderstorm';
			//"label": "hurricane",
			$icons['962'] = 'cloudy-gusts';

			// If we are not in the ranges mentioned above, add a day/night prefix.
			if (!($code > 699 && $code < 800) && !($code > 899 && $code < 1000)) {
				return 'wi wi-day-'. $icons[$code];
			}
			else{
				return "wi wi-".$icons[$code];
			}
		}
    }
}

new InTravel_Locations;
