<?php

/*
 * Inwave_Heading for Visual Composer
 */
if (!class_exists('InTravel_Spotlight_Destination')) {

    class InTravel_Spotlight_Destination extends Inwave_Shortcode{

        protected $name = 'intravel_spotlight_destination';

        function init_params() {
            $args = array(
                'taxonomy' => 'destination',
                'hide_empty' => false,
            );

            $_destinations = get_terms($args);
            $destinations = array();

            if(!is_wp_error($_destinations) && $_destinations) {
                foreach ($_destinations as $destination) {
                    $destinations[$destination->name] = $destination->slug;
                }
            }

            $args = array(
                'taxonomy' => 'tour_type',
                'hide_empty' => false,
            );
            $_tour_types = get_terms($args);
            $tour_types = array();
            if(!is_wp_error($_tour_types) && $_tour_types) {
                foreach ($_tour_types as $tour_type) {
                    $tour_types[$tour_type->name] = $tour_type->slug;
                }
            }

            return array(
                'name' => __('Tour Spotlight Destination', 'inwavethemes'),
                'description' => __('Show a Destination with some tour types', 'inwavethemes'),
                'base' => $this->name,
                'icon' => 'iw-default',
                'category' => 'Custom',
                'params' => array(
                    array(
                        "type" => "dropdown",
                        "admin_label" => true,
                        "heading" => "Style",
                        "param_name" => "style",
                        "value" => array(
                            "Style 1 - " => "style1",
                            "Style 2 - Video" => "style2",
                        )
                    ),
                    array(
                        "type" => "iwevent_preview_image",
                        "heading" => __("Preview Style", "inwavethemes"),
                        "param_name" => "preview_style1",
                        "value" => get_template_directory_uri() . '/assets/images/shortcodes/spotlight-destination-v1.jpg',
                        "dependency" => array('element' => 'style', 'value' => 'style1')
                    ),
                    array(
                        "type" => "iwevent_preview_image",
                        "heading" => __("Preview Style", "inwavethemes"),
                        "param_name" => "preview_style2",
                        "value" => get_template_directory_uri() . '/assets/images/shortcodes/spotlight-destination-v2.jpg',
                        "dependency" => array('element' => 'style', 'value' => 'style2')
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Title", 'inwavethemes'),
                        "param_name" => "title",
                        "value" => 'Spotlight Destination',
                        "dependency" => array('element' => 'style', 'value' => 'style1')
                    ),
                    array(
                        "type" => "dropdown",
                        "heading" => __("Select Location", 'inwavethemes'),
                        "param_name" => "destination",
                        "value" => $destinations,
                        "dependency" => array('element' => 'style', 'value' => 'style1')
                    ),
                    array(
                        'type' => 'textfield',
                        "holder" => "div",
                        "heading" => __("Video URL", "inwavethemes"),
                        "value" => "",
                        "param_name" => "url",
                        "dependency" => array('element' => 'style', 'value' => 'style2')
                    ),
                    array(
                        'type' => 'attach_image',
                        "heading" => __("Poster image", "inwavethemes"),
                        "param_name" => "poster",
                        "dependency" => array('element' => 'style', 'value' => 'style2')
                    ),
                    array(
                        "type" => "checkbox",
                        "heading" => __("Select Tour types", 'inwavethemes'),
                        "param_name" => "tour_types",
                        "value" => $tour_types,
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Extra Class", "inwavethemes"),
                        "param_name" => "class",
                        "value" => "",
                        "description" => __("Write your own CSS and mention the class name here.", "inwavethemes"),
                    )
                )
            );
        }

        // Shortcode handler function for list Icon
        function init_shortcode($atts, $content = null) {

            if(!class_exists('inTravel')){
                return __('Please active the plugin inTravel', 'inwavethemes');
            }

            $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( $this->name, $atts ) : $atts;

            $output = '';
            extract(shortcode_atts(array(
                'style' => '',
                'title' => '',
                'destination' => '',
                'url' => '',
                'poster' => '',
                'tour_types' => '',
                'class' => '',
            ), $atts));
            if ($tour_types) {
                $tour_types = explode(',', $tour_types);
            }
            else {
                $tour_types = '';
            }
            if ($destination) {
                $destination = get_term_by('slug', $destination, 'destination');
            }

            switch ($style) {
                case 'style1':
                if($destination){
                    $output .= '<div class="intravel-spotlight-destination style1'.esc_attr($class ? ' '.$class : '').'">';
                        $output .= '<div class="row">';
                            $output .= '<div class="col-md-6 col-sm-12 col-xs-12">';
                                $output .= '<div class="destination iw-effect-1">';
                                    $image = get_term_meta($destination->term_id, 'intravel_image', true);
                                    if(!$image){
                                        $image = it_get_placeholder_image();
                                    }
                                    if($image){
                                        $image = inwave_resize($image, 570, 570, true);
                                    }

                                    $output .= '<img src="'.esc_url($image).'" alt="'.esc_attr($destination->name).'">';
                                    $output .= '<div class="destination-info">';
                                    $output .= '<h4 class="title">'.$title.'</h4>';
                                    $output .= '<h3><a href="'.get_term_link($destination, 'destination').'">'.$destination->name.'</a></h3>';
                                    $output .= '<p class="description-destination">'.wp_trim_words($destination->description, 15).'</p>';
                                    $output .= '</div>';
                                $output .= '</div>';
                            $output .= '</div>';
                            $output .= '<div class="col-md-6 col-sm-12 col-xs-12 tour-types">';
                                $output .= '<div class="row">';
                                    if($tour_types){
                                        $link = it_get_page_permalink('tours');
                                        $link = add_query_arg('destination', $destination->slug, $link);
                                        $i = 0;
                                        foreach ($tour_types as $tour_type){
                                            if($i > 0 && count($tour_types) > $i && $i % 2 == 0){
                                                $output .= '</div>';
                                                $output .= '<div class="row">';
                                            }
                                            $output .= '<div class="col-md-6 col-sm-6 col-xs-12">';
                                                $tour_type = get_term_by('slug', $tour_type, 'tour_type');
                                                $image = get_term_meta($tour_type->term_id, 'intravel_image', true);
                                                if(!$image){
                                                    $image = it_get_placeholder_image();
                                                }
                                                if($image){
                                                    $image = inwave_resize($image, 600, 600, true);
                                                }

                                                $icon_image = get_term_meta($tour_type->term_id, 'intravel_icon_image', true);
                                                if($icon_image){
                                                    $icon_image = inwave_resize($icon_image, 60, 60, true);
                                                }
                                                $output .= '<div class="tour-type iw-effect-1">';
                                                    $output .= '<img src="'.esc_url($image).'" alt="'.esc_attr($tour_type->name).'">';
                                                    $output .= '<div class="tour-type-info">';
                                                        $output .= '<div class="tour-type-icon"><img src="'.esc_url($icon_image).'" alt=""></div>';
                                                        $output .= '<h3><a href="'.esc_url(add_query_arg('tour_type', $tour_type->slug, $link)).'">'.$tour_type->name.'</a></h3>';
                                                    $output .= '</div>';
                                                $output .= '</div>';
                                            $output .= '</div>';
                                            $i++;
                                        }
                                    }
                                $output .= '</div>';
                            $output .= '</div>';
                        $output .= '</div>';
                    $output .= '</div>';
                }
                else{
                    $output .= '<p>'.__('Please select a destination', 'intravel').'</p>';
                }
                    break;
                case 'style2':
                    $output .= '<div class="intravel-spotlight-destination style2 '.esc_attr($class ? ' '.$class : '').'">';
                    $output .= '<div class="row">';
                    $output .= '<div class="col-md-4 col-sm-12 col-xs-12 iw-video">';
                    if ($url) {
                        if($poster){
                            $poster = wp_get_attachment_image_src($poster, 'full');
                            $poster = $poster[0];
                            $poster = inwave_resize($poster, 600, 800, true);
                            $output .= '<div class="tour-type-img iw-effect-1"><img src="'.esc_url($poster).'" alt=""></div>';
                        }
                        $output .= '<button type="button" class="btn btn-info btn-lg open-popup" data-toggle="modal" data-target="#myModal"><i class="icon ion-ios-play-outline"></i></button>';
                        $output .= '<div class="iw-video-player modal fade" id="myModal" role="dialog">';
                        $output .= '<div class="modal-dialog">';
                        $output .= '<div class="play-button"><i class="icon ion-ios-play-outline"></i></div>';
                        if($url){
                            $output .= '<div class="video"><video src="'.$url.'"></video></div>';
                            $output .= '<button type="button" class="btn btn-default close-popup" data-dismiss="modal"><i class="icon ion-close"></i></button>';
                        }
                        $output .= '</div>';
                        $output .= '</div>';
                    }
                    $output .= '</div>';
                    $output .= '<div class="col-md-8 col-sm-12 col-xs-12 tour-types">';
                    $output .= '<div class="row">';
                    if($tour_types){
                        $i = 0;
                        foreach ($tour_types as $tour_type){
                            if($i > 0 && count($tour_types) > $i && $i % 3 == 0){
                                $output .= '</div>';
                                $output .= '<div class="row">';
                            }
                            $output .= '<div class="col-md-4 col-sm-4 col-xs-12 tour-type-item iw-effect-img">';
                            $tour_type = get_term_by('slug', $tour_type, 'tour_type');
                            $image = get_term_meta($tour_type->term_id, 'intravel_image', true);
                            if(!$image){
                                $image = it_get_placeholder_image();
                            }
                            if($image){
                                $image = inwave_resize($image, 900, 900, true);
                            }

                            $icon_image = get_term_meta($tour_type->term_id, 'intravel_icon_image', true);
                            if($icon_image){
                                $icon_image = inwave_resize($icon_image, 60, 60, true);
                            }
                            $output .= '<div class="tour-type">';
                            $output .= '<div class="tour-type-img effect-1"><img src="'.esc_url($image).'" alt=""></div>';
                            $output .= '<div class="tour-type-info">';
                            $output .= '<div class="tour-type-icon"><img src="'.esc_url($icon_image).'" alt=""></div>';
                            $output .= '<h3>'.$tour_type->name.'</h3>';
                            $output .= '<div class="tour-type-description">'.wp_trim_words($tour_type->description, 10).'</div>';
                            $link = get_term_link($tour_type->term_id, 'tour_type');
                            $output .= '<div class="tour-type-detail"><a href="'.esc_url($link).'">'.__("Discover ", "inwavethemes").'<i class="icon ion-arrow-right-c"></i></a></div>';
                            $output .= '</div>';
                            $output .= '</div>';
                            $output .= '</div>';
                            $i++;
                        }
                    }
                    $output .= '</div>';
                    $output .= '</div>';
                    $output .= '</div>';
                    $output .= '</div>';
                    break;
            }

            return $output;
        }
    }
}

new InTravel_Spotlight_Destination;
