<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
get_header();
global $wp_query;
$tour = it_get_tour();
$search_string = (isset($_GET['s']) && $_GET['s']) ? sanitize_text_field($_GET['s']) : '';
$destination_slug = (isset($_GET['destination']) && $_GET['destination']) ? sanitize_text_field($_GET['destination']) : '';
$tour_type_slug = (isset($_GET['tour_type']) && $_GET['tour_type']) ? sanitize_text_field($_GET['tour_type']) : '';
$sidebar_position = Inwave_Helper::getPostOption('sidebar_position', 'sidebar_position');
wp_enqueue_script('isotope');
wp_enqueue_script('imagesloaded');
$layout = isset($_GET['layout']) ? $_GET['layout'] : (isset($_COOKIE['tours-layout']) ? $_COOKIE['tours-layout'] : it_get_option('default_tours_layout', 'grid'));
if(!$layout){
    $layout = 'grid';
}
$order = isset($_GET['order']) ? $_GET['order'] : 'asc';
$orderby = isset($_GET['orderby']) ? $_GET['orderby'] : '';
?>
<div class="iw-tour-listing">
    <div class="iw-tours-content">
        <div class=" container">
            <div class="row">
                <div class="<?php echo esc_attr(inwave_get_classes('container', $sidebar_position))?> blog-content">
                    <div class="tour-order-layout-form">
                        <form id="orderForm" method="get" action="<?php echo it_get_page_permalink('tours'); ?>" name="orderForm">
                            <select class="tours-order iw-select-2" name="order">
                                <option value="desc" <?php echo $order == 'desc' ? 'selected' : ''; ?>><?php echo __('Descending', 'intravel'); ?></option>
                                <option value="asc" <?php echo $order == 'asc' ? 'selected' : ''; ?>><?php echo __('Ascending', 'intravel'); ?></option>
                            </select>
                            <select class="tours-orderby iw-select-2" name="orderby">
                                <option value="" <?php echo $orderby == '' ? 'selected' : ''; ?>><?php echo __('Ordering', 'intravel'); ?></option>
                                <option value="date" <?php echo $orderby == 'date' ? 'selected' : ''; ?>><?php echo __('Date', 'intravel'); ?></option>
                                <option value="price" <?php echo $orderby == 'price' ? 'selected' : ''; ?>><?php echo __('Price', 'intravel'); ?></option>
                                <option value="rating" <?php echo $orderby == 'rating' ? 'selected' : ''; ?>><?php echo __('Rating', 'intravel'); ?></option>
                                <option value="popularity" <?php echo $orderby == 'popularity' ? 'selected' : ''; ?>><?php echo __('Popularity', 'intravel'); ?></option>
                                <option value="title" <?php echo $orderby == 'title' ? 'selected' : ''; ?>><?php echo __('Title', 'intravel'); ?></option>
                            </select>
                            <?php
                            $varibles = array('s', 'tour_type', 'destination', 'start_date', 'min_price', 'max_price');
                            foreach ($varibles as $varible){
                                if(isset($_GET[$varible]) && $_GET[$varible]){
                                    echo '<input type="hidden" name="'.esc_attr($varible).'" value="'.esc_attr($_GET[$varible]).'">';
                                }
                            }
                            ?>
                            <div class="layout-switcher">
                                <div class="layout-switcher">
                                    <ul>
                                        <li class="<?php echo $layout == 'list' ? 'theme-bg active' : ''; ?>">
                                            <?php if ($layout == 'grid'): ?>
                                                <a href="#" class="tours-layout layout-list"><i class="icon ion-navicon"></i></a>
                                            <?php else: ?>
                                                <i class="icon ion-navicon"></i>
                                            <?php endif; ?>
                                        </li>
                                        <li class="<?php echo $layout == 'grid' ? 'theme-bg active' : ''; ?>">
                                            <?php if ($layout == 'list'): ?>
                                                <a href="#" class="tours-layout layout-grid"><i class="icon ion-grid"></i></a>
                                            <?php else: ?>
                                                <i class="icon ion-grid"></i>
                                            <?php endif; ?>
                                        </li>
                                    </ul>
                                    <input type="hidden" name="layout" value="list">
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </form>
                    </div>
                    <?php
                        if($layout == 'list'){
                            it_get_template_part('tours/list');

                        }
                        else{
                            it_get_template_part('tours/grid');
                        }
                    ?>
                    <div class="page-nav">
                        <?php echo paginate_links(array(
                                'type'=>'plain',
                                'prev_text'          => wp_kses(__('<i class="fa fa-angle-left"></i>', 'inevent'), inwave_allow_tags('i')),
                                'next_text'          => wp_kses(__('<i class="fa fa-angle-right"></i>', 'inevent'), inwave_allow_tags('i'))
                            )
                        ) ?>
                        <div style="clear:both;"></div>
                    </div>
                </div>
                <?php if ($sidebar_position && $sidebar_position != 'none') { ?>
                    <div class="<?php echo esc_attr(inwave_get_classes('sidebar', $sidebar_position))?> tour-sidebar">
                        <?php
                        if(is_tours()){
                            $sidebar = Inwave_Helper::getPostOption('sidebar_name');
                            if(!$sidebar) $sidebar = 'sidebar-tours';

                            if (is_active_sidebar(  $sidebar) ) {
                                dynamic_sidebar($sidebar);
                            }
                        }else{
                            get_sidebar('tours');
                        }
                        ?>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
</div>
<?php get_footer(); ?>
