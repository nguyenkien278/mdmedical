<?php
/*
Plugin Name: CMB2 Metatabs Options
Plugin URI:  https://github.com/rogerlos/cmb2-metatabs-options
Description: Add admin option pages with multiple metaboxes--and place those metaboxes into optional tabs. Requires CMB2.
Version:     1.0.1
Author:      Roger Los
Author URI:  https://github.com/rogerlos
Text Domain: cmb2
License:     GPLv2 or later
 */

if ( ! defined( 'WPINC' ) ) die;

if(!function_exists('cmb2_render_iwschedule')){
    function cmb2_render_iwschedule($field, $escaped_value, $object_id, $object_type, $field_type_object ){
        wp_enqueue_style( 'iwschedule' , INTRAVEL_PLUGIN_URL .'/libs/intravel-schedule/css/iwschedule.css');
        wp_enqueue_script( 'iwschedule' , INTRAVEL_PLUGIN_URL .'/libs/intravel-schedule/js/iwschedule.js');
        wp_localize_script('iwschedule', 'iwscheduleCfg', array(
            'marker_url' => it_get_marker_url(),
            'lat' => it_get_option('map_lat', -33.8688),
            'lng' => it_get_option('map_lng', 151.2195),
            'zoom' => it_get_option('map_zoom', 15),
            'polyline_color' => it_get_option('map_polyline_color', '#FF0000'),
            'polyline_stroke_opacity' => it_get_option('map_polyline_stroke_opacity', 0.5),
            'polyline_stroke_weight' => it_get_option('map_polyline_stroke_weight', 4),
        ));
        global $inwave_theme_option;
        $google_map_api = it_get_option('google_api') ? it_get_option('google_api') : (isset($inwave_theme_option['google_api']) ? $inwave_theme_option['google_api'] : '');
        wp_enqueue_script('googlemap-api', 'https://maps.googleapis.com/maps/api/js?key='.$google_map_api.'&libraries=places', array('jquery'), INTRAVEL_VERSION);

        $meta_value = $field->value;

        $meta_value = json_decode($meta_value, true);
        $name = $field->args['id'];
        echo '<div id="'.$field->args['id'].'" class="intravel-schedule-field" data-count="'.count($meta_value).'">';
        echo '<div class="map-view" style="height: 300px; margin-bottom: 10px;"></div>';
        echo '<div class="schedule-list">';
        if ( $meta_value) {
            $i = 0 ;
            foreach ( $meta_value as $value) {
                $item_name = $name.'['.$i.']';
                echo '<div class="schedule-item schedule-'.(int)$i.'" data-schedule="'.$i.'">';
                echo '<div class="schedule-item-inner">';
                echo '<div class="div-left">';
                echo '<div class="div-left-inner">';
                echo '<label>Title</label>';
                echo '<input type="text" class="" name="'.$item_name.'[title]" value="'.$value['title'].'">';
                echo '</div>';
                echo '</div>';
                echo '<div class="div-right">';
                echo '<div class="div-right-inner">';
                echo '<label>Date Time</label>';
                echo '<input type="text"  name="'.$item_name.'[date_time]" value="'.$value['date_time'].'">';
                echo '</div>';
                echo '</div>';
                echo '<div class="div-left">';
                echo '<div class="div-left-inner">';
                echo '<label>Address</label>';
                $address = isset($value['address']) ? esc_attr($value['address']) : '';
                $lat = isset($value['lat']) ? esc_attr($value['lat']) : '';
                $lng = isset($value['lng']) ? esc_attr($value['lng']) : '';
                echo '<input type="text" class="schedule-address" name="'.$item_name.'[address]" value="'.$address.'">';
                echo '<input type="hidden" class="schedule-lat" name="'.$item_name.'[lat]" value="'.$lat.'">';
                echo '<input type="hidden" class="schedule-lng" name="'.$item_name.'[lng]" value="'.$lng.'">';
                echo '</div>';
                echo '</div>';
                echo '<div class="div-right">';
                echo '<div class="div-right-inner">';
                echo '<label>Marker Icon</label>';
                echo '<select class="schedule-marker-icon" name="'.$item_name.'[marker_icon]">';
                echo '<option value="">'.__('Marker default', 'intravel').'</option>';
                $marker_icons = it_get_marker_icons();
                $marker_icon_value = isset($value['marker_icon']) ? $value['marker_icon'] : '';
                foreach($marker_icons as $marker_icon){
                    echo '<option value="'.esc_attr($marker_icon).'" '.($marker_icon_value == $marker_icon ? 'selected' : '').'>'.$marker_icon.'</option>';
                }
                echo '</select>';
                echo '</div>';
                echo '</div>';
                echo '<label>Description</label>';
                echo '<textarea name="'.$item_name.'[description]" rows="4">'.$value['description'].'</textarea>';
                echo '</div>';
                echo '<a href="#" class="remove-schedule">X</a>';
                echo '</div>';
                $i++;
            }
        }
        echo '</div>';

        echo '<a class="button button-primary intravel-add-schedule" href="#" data-name="'.$name.'" data-count="'.count($meta_value).'">'.__( 'Add Schedule', 'intravel' ).'</a>';
        echo '<textarea class="intravel-schedule-value" style="display: none">'.json_encode($meta_value).'</textarea>';
        echo '<select class="intravel-schedule-icon" style="display: none">';
        echo '<option value="">'.__('Marker default', 'intravel').'</option>';
        $marker_icons = it_get_marker_icons();
        foreach($marker_icons as $marker_icon){
            echo '<option value="'.esc_attr($marker_icon).'" >'.$marker_icon.'</option>';
        }
        echo '</select>';
        echo '</div>';
    }

    add_action( 'cmb2_render_iwschedule', 'cmb2_render_iwschedule', 10, 5 );

    function cmb2_validate_iwschedule( $override_value, $value, $object_id, $args, $sanitizer ) {
        $value = (array)$value;
        foreach ($value as $key=>$schedule){
            if(empty($schedule['title']) && empty($schedule['address']) && empty($schedule['date_time']) && empty($schedule['description'])){
                unset($value[$key]);
            }
        }
        if(defined('JSON_UNESCAPED_UNICODE')){
            $value = json_encode($value, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE);
        }else{
            $value = array_values($value);
            $value = json_encode($value);
            $value = preg_replace_callback(
                '/\\\\u([0-9a-f]{4})/i',
                function ($matches) {
                    $sym = mb_convert_encoding(
                        pack('H*', $matches[1]),
                        'UTF-8',
                        'UTF-16'
                    );
                    return $sym;
                },
                $value
            );
        }

        return $value;
    }

    add_filter( 'cmb2_validate_iwschedule', 'cmb2_validate_iwschedule', 10, 5 );
}
