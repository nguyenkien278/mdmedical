<?php
/**
 * Installation related functions and actions
 *
 * @author   inTravel
 * @category Admin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * IT_Install Class.
 */
class IT_Install {

	/** @var array DB updates that need to be run */
	private static $db_updates = array(
	);

	/**
	 * Hook in tabs.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'update' ), 5 );
		//add_action( 'admin_init', array( __CLASS__, 'install_actions' ) );
		//add_action( 'in_plugin_update_message-intravel', array( __CLASS__, 'in_plugin_update_message' ) );
		//add_filter( 'plugin_action_links_' . IT_PLUGIN_BASENAME, array( __CLASS__, 'plugin_action_links' ) );
		//add_filter( 'plugin_row_meta', array( __CLASS__, 'plugin_row_meta' ), 10, 2 );
		//add_filter( 'wpmu_drop_tables', array( __CLASS__, 'wpmu_drop_tables' ) );
		//add_filter( 'cron_schedules', array( __CLASS__, 'cron_schedules' ) );
	}

	/**
	 * Check inTravel version and run the updater is required.
	 *
	 * This check is done on all requests and runs if he versions do not match.
	 */
	public static function update() {
		$installed_version = get_option('intravel_version' );
		if ( ! defined( 'IFRAME_REQUEST' ) && $installed_version !== IT()->version ) {
			if(version_compare($installed_version , '1.1' , '<')){
				self::create_cron_jobs();
				$tours_page_id = it_get_page_id('tours');
				if($tours_page_id){
					update_post_meta($tours_page_id, 'inwave_sidebar_name', 'sidebar-tours' );
				}
			}
			//do_action( 'intravel_updated' );
		}
	}

	/**
	 * Install actions when a update button is clicked within the admin area.
	 *
	 * This function is hooked into admin_init to affect admin only.
	 */
	public static function install_actions() {
		if ( ! empty( $_GET['do_update_intravel'] ) ) {
			self::update();
			//IT_Admin_Notices::remove_notice( 'update' );
			add_action( 'admin_notices', array( __CLASS__, 'updated_notice' ) );
		}
	}

	/**
	 * Show notice stating update was successful.
	 */
	public static function updated_notice() {
		?>
		<div id="message" class="updated intravel-message">
			<p><?php _e( 'inTravel data update complete. Thank you for updating to the latest version!', 'intravel' ); ?></p>
		</div>
		<?php
	}

	/**
	 * Install IT.
	 */
	public static function install() {
		global $wpdb;

		if ( ! defined( 'INTRAVEL_INSTALLING' ) ) {
			define( 'INTRAVEL_INSTALLING', true );
		}

		// Ensure needed classes are loaded
		//include_once( 'admin/admin.notices.class.php' );

		self::create_options();
		//self::create_tables();
		//self::create_roles();

		// Register post types
		//IT_Post_types::register_post_types();
		//IT_Post_types::register_taxonomies();

		// Also register endpoints - this needs to be done prior to rewrite rule flush
		IT()->query->init_query_vars();
		IT()->query->add_endpoints();

		//self::create_terms();
		self::create_cron_jobs();
		//self::create_pages();
		//self::create_files();

		// Queue upgrades/setup wizard
		$current_it_version    = get_option( 'intravel_version', null );
		$current_db_version    = get_option( 'intravel_db_version', null );
		//$major_wc_version      = substr( IT()->version, 0, strrpos( IT()->version, '.' ) );

		//IT_Admin_Notices::remove_all_notices();

		// No versions? This is a new install :)
		if ( is_null( $current_it_version ) && is_null( $current_db_version ) && apply_filters( 'intravel_enable_setup_wizard', true ) ) {
			//IT_Admin_Notices::add_notice( 'install' );
			//set_transient( 'intravel_activation_redirect', 1, 30 );

		// No page? Let user run wizard again..
		} elseif ( ! it_get_option('checkout_page_id' ) ) {
			//IT_Admin_Notices::add_notice( 'install' );
		}

		if ( ! is_null( $current_db_version ) && version_compare( $current_db_version, max( array_keys( self::$db_updates ) ), '<' ) ) {
			//IT_Admin_Notices::add_notice( 'update' );
		} else {
			//self::update_db_version();
		}

		self::update_intravel_version();

		// Flush rules after install
		flush_rewrite_rules();

		/*
		 * Deletes all expired transients. The multi-table delete syntax is used.
		 * to delete the transient record from table a, and the corresponding.
		 * transient_timeout record from table b.
		 *
		 * Based on code inside core's upgrade_network() function.
		 */
		$sql = "DELETE a, b FROM $wpdb->options a, $wpdb->options b
			WHERE a.option_name LIKE %s
			AND a.option_name NOT LIKE %s
			AND b.option_name = CONCAT( '_transient_timeout_', SUBSTRING( a.option_name, 12 ) )
			AND b.option_value < %d";
		$wpdb->query( $wpdb->prepare( $sql, $wpdb->esc_like( '_transient_' ) . '%', $wpdb->esc_like( '_transient_timeout_' ) . '%', time() ) );

		// Trigger action
		do_action( 'intravel_installed' );
	}
	
	/**
	 * Update IT version to current.
	 */
	private static function update_intravel_version() {
		update_option( 'intravel_version', IT()->version );
	}

	/**
	 * Update DB version to current.
	 */
	private static function update_db_version( $version = null ) {
		update_option('intravel_db_version', is_null( $version ) ? IT()->version : $version );
	}

	/**
	 * Add more cron schedules.
	 * @param  array $schedules
	 * @return array
	 */
	public static function cron_schedules( $schedules ) {
		$schedules['monthly'] = array(
			'interval' => 2635200,
			'display'  => __( 'Monthly', 'intravel' )
		);
		return $schedules;
	}

	/**
	 * Create cron jobs (clear them first).
	 */
	private static function create_cron_jobs() {
		wp_clear_scheduled_hook( 'intravel_scheduled_sales' );
		wp_clear_scheduled_hook( 'intravel_cancel_unpaid_orders' );
		wp_clear_scheduled_hook( 'intravel_paypal_cancel_unpaid_orders' );

		$ve = get_option( 'gmt_offset' ) > 0 ? '+' : '-';

		wp_schedule_event( strtotime( '00:00 tomorrow ' . $ve . get_option( 'gmt_offset' ) . ' HOURS' ), 'daily', 'intravel_scheduled_sales' );

		$held_duration = it_get_option( 'hold_stock_hours', '50' );
		if ( $held_duration != '' ) {
			wp_schedule_single_event( time() + ( absint( $held_duration ) * 60 * 60), 'intravel_cancel_unpaid_orders' );
		}

		$held_duration = it_get_option( 'paypal_hold_stock_hours', '1' );
		if ( $held_duration != '' ) {
			wp_schedule_single_event( time() + ( absint( $held_duration ) * 60 * 60), 'intravel_paypal_cancel_unpaid_orders' );
		}
	}

	/**
	 * Create pages that the plugin relies on, storing page id's in variables.
	 */
	public static function create_pages() {
		$pages = apply_filters( 'intravel_create_pages', array(
			'tours' => array(
				'name'    => _x( 'tours', 'Page slug', 'intravel' ),
				'title'   => _x( 'Tours', 'Page title', 'intravel' ),
				'content' => ''
			),
			'checkout' => array(
				'name'    => _x( 'tour-checkout', 'Page slug', 'intravel' ),
				'title'   => _x( 'Tour Checkout', 'Page title', 'intravel' ),
				'content' => ''
			),
			'checkorder' => array(
				'name'    => _x( 'tour-check-order', 'Page slug', 'intravel' ),
				'title'   => _x( 'Tour Check Order', 'Page title', 'intravel' ),
				'content' => ''
			),
		) );

		foreach ( $pages as $key => $page ) {
			it_create_page( esc_sql( $page['name'] ), $key . '_page_id', $page['title'], $page['content'], ! empty( $page['parent'] ) ? it_get_page_id( $page['parent'] ) : '' );
		}
	}

	/**
	 * Default options.
	 *
	 * Sets up the default options used on the settings page.
	 */
	private static function create_options() {
		if(!get_option('plg-intravel-options', '')){
			$default_option = unserialize('a:73:{s:25:"intravel_checkout_page_id";s:1:"2";s:22:"intravel_tours_page_id";s:3:"466";s:37:"intravel_use_woocommerce_for_checkout";s:2:"on";s:45:"intravel_completed_order_woocommerce_statuses";a:1:{i:0;s:9:"completed";}s:45:"intravel_cancelled_order_woocommerce_statuses";a:1:{i:0;s:9:"cancelled";}s:14:"intravel_taxes";s:2:"10";s:27:"intravel_prices_include_tax";s:2:"no";s:26:"intravel_tax_display_tours";s:4:"excl";s:17:"intravel_currency";s:3:"USD";s:21:"intravel_currency_pos";s:4:"left";s:27:"intravel_price_thousand_sep";s:1:".";s:27:"intravel_price_num_decimals";s:1:"2";s:16:"checkout_page_id";s:3:"212";s:13:"tours_page_id";s:3:"251";s:36:"completed_order_woocommerce_statuses";a:1:{i:0;s:9:"completed";}s:36:"cancelled_order_woocommerce_statuses";a:1:{i:0;s:9:"cancelled";}s:18:"prices_include_tax";s:2:"no";s:17:"tax_display_tours";s:4:"excl";s:8:"currency";s:3:"USD";s:12:"currency_pos";s:5:"right";s:18:"price_thousand_sep";s:1:".";s:18:"price_num_decimals";s:1:"2";s:20:"email_new_recipients";s:26:"{intravel_custommer_email}";s:17:"email_new_subject";s:9:"New order";s:19:"email_new_body_text";s:164:"{intravel_custommer_name} have just created a new order. This order will be automatically cancelled within {intravel_hold_booking_minutes} minutes if you do not pay";s:19:"email_new_body_html";s:146:"Hi {intravel_custommer_name} you have just created a new order #{intravel_order_code}. Your order details are shown in {intravel_check_order_link}";s:19:"email_onhold_enable";s:2:"on";s:22:"email_cancelled_enable";s:2:"on";s:22:"email_completed_enable";s:2:"on";s:14:"email_new_mode";s:1:"2";s:17:"email_onhold_mode";s:1:"1";s:20:"email_cancelled_mode";s:1:"1";s:20:"email_completed_mode";s:1:"1";s:16:"email_new_enable";s:2:"on";s:26:"email_cancelled_recipients";s:26:"{intravel_custommer_email}";s:23:"email_cancelled_subject";s:20:"Your Order cancelled";s:25:"email_cancelled_body_text";s:38:"Order {intravel_order_code} cancelled!";s:23:"email_onhold_recipients";s:26:"{intravel_custommer_email}";s:20:"email_onhold_subject";s:24:"Your Order is processing";s:22:"email_onhold_body_text";s:36:"{intravel_order_code}  is processing";s:26:"email_completed_recipients";s:26:"{intravel_custommer_email}";s:23:"email_completed_subject";s:20:"Your order completed";s:25:"email_completed_body_text";s:30:"Thank you for purchasing tour.";s:33:"onhold_order_woocommerce_statuses";a:1:{i:0;s:7:"on-hold";}s:26:"who_can_rating_destination";s:6:"anyone";s:19:"default_tours_order";s:4:"desc";s:9:"tour_slug";s:5:"tours";s:14:"tour_type_slug";s:9:"tour-type";s:13:"tour_tag_slug";s:8:"tour-tag";s:16:"destination_slug";s:11:"destination";s:25:"endpoint_booking_received";s:16:"booking-received";s:18:"paypal_sanbox_mode";s:2:"on";s:12:"paypal_email";s:28:"hoak34-facilitator@gmail.com";s:5:"taxes";s:2:"10";s:18:"checkorder_page_id";s:4:"1474";s:20:"default_tours_layout";s:4:"grid";s:19:"thankyou_page_title";s:46:"Congratulation! Your order has been confirmed!";s:25:"thankyou_page_description";s:202:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras sollicitudin, tellus vitae condimentum egestas, libero dolor auctor tellus, eu consectetur neque elit quis nunc. Cras elementum pretium est.";s:16:"hold_stock_hours";s:2:"50";s:25:"email_cancelled_body_html";s:79:"The order #{intravel_order_code} from {intravel_site_title} has been cancelled.";s:25:"email_completed_body_html";s:148:"Hi there. Your order #{intravel_order_code} on {intravel_site_title} has been completed. Your order details are shown in {intravel_check_order_link}";s:22:"email_onhold_body_html";s:148:"Your order #{intravel_order_code} is on-hold until we confirm payment has been received. Your order details are shown in {intravel_check_order_link}";s:18:"email_from_address";s:19:"admin@localhost.com";s:15:"email_from_name";s:8:"inTravel";s:18:"submit_form_status";s:7:"pending";s:28:"submit_form_hold_stock_hours";s:2:"50";s:23:"paypal_hold_stock_hours";s:1:"1";s:7:"map_lat";s:8:"-33.8688";s:7:"map_lng";s:8:"151.2195";s:8:"map_zoom";s:2:"15";s:27:"map_polyline_stroke_opacity";s:3:"0.5";s:26:"map_polyline_stroke_weight";s:1:"4";s:18:"map_polyline_color";s:7:"#FF0000";}');
			$default_option['email_from_address'] = get_option('admin_email');
			$default_option['email_from_name'] = get_option('blogname');

			update_option('plg-intravel-options', $default_option);
		}
	}


	/**
	 * Add the default terms for IT taxonomies - product types and order statuses. Modify this at your own risk.
	 */
	private static function create_terms() {
		
	}

	/**
	 * Set up the database tables which the plugin needs to function.
	 *
	 * Tables:
	 */
	private static function create_tables() {
	}

	/**
	 * Get Table schema.
	 * @return string
	 */
	private static function get_schema() {
		
	}

	/**
	 * Create roles and capabilities.
	 */
	public static function create_roles() {
		global $wp_roles;

		if ( ! class_exists( 'WP_Roles' ) ) {
			return;
		}

		if ( ! isset( $wp_roles ) ) {
			$wp_roles = new WP_Roles();
		}
	}

	/**
	 * Get capabilities for inTravel - these are assigned to admin/shop manager during installation or reset.
	 *
	 * @return array
	 */
	 private static function get_core_capabilities() {
	}

	/**
	 * intravel_remove_roles function.
	 */
	public static function remove_roles() {
	}

	/**
	 * Create files/directories.
	 */
	private static function create_files() {
	}

	/**
	 * Show plugin changes. Code adapted from W3 Total Cache.
	 */
	public static function in_plugin_update_message( $args ) {
		$transient_name = 'intravel_upgrade_notice_' . $args['Version'];

		if ( false === ( $upgrade_notice = get_transient( $transient_name ) ) ) {
			$response = wp_safe_remote_get( 'https://plugins.svn.wordpress.org/intravel/trunk/readme.txt' );

			if ( ! is_wp_error( $response ) && ! empty( $response['body'] ) ) {
				$upgrade_notice = self::parse_update_notice( $response['body'] );
				set_transient( $transient_name, $upgrade_notice, DAY_IN_SECONDS );
			}
		}

		echo wp_kses_post( $upgrade_notice );
	}

	/**
	 * Parse update notice from readme file.
	 * @param  string $content
	 * @return string
	 */
	private static function parse_update_notice( $content ) {
		// Output Upgrade Notice
		$matches        = null;
		$regexp         = '~==\s*Upgrade Notice\s*==\s*=\s*(.*)\s*=(.*)(=\s*' . preg_quote( IT_VERSION ) . '\s*=|$)~Uis';
		$upgrade_notice = '';

		if ( preg_match( $regexp, $content, $matches ) ) {
			$version = trim( $matches[1] );
			$notices = (array) preg_split('~[\r\n]+~', trim( $matches[2] ) );

			if ( version_compare( IT_VERSION, $version, '<' ) ) {

				$upgrade_notice .= '<div class="intravel_plugin_upgrade_notice">';

				foreach ( $notices as $index => $line ) {
					$upgrade_notice .= wp_kses_post( preg_replace( '~\[([^\]]*)\]\(([^\)]*)\)~', '<a href="${2}">${1}</a>', $line ) );
				}

				$upgrade_notice .= '</div> ';
			}
		}

		return wp_kses_post( $upgrade_notice );
	}

	/**
	 * Show action links on the plugin screen.
	 *
	 * @param	mixed $links Plugin Action links
	 * @return	array
	 */
	public static function plugin_action_links( $links ) {
		$action_links = array(
			'settings' => '<a href="' . admin_url( 'admin.php?page=wc-settings' ) . '" title="' . esc_attr( __( 'View inTravel Settings', 'intravel' ) ) . '">' . __( 'Settings', 'intravel' ) . '</a>',
		);

		return array_merge( $action_links, $links );
	}

	/**
	 * Show row meta on the plugin screen.
	 *
	 * @param	mixed $links Plugin Row Meta
	 * @param	mixed $file  Plugin Base file
	 * @return	array
	 */
	public static function plugin_row_meta( $links, $file ) {

		return (array) $links;
	}

	/**
	 * Uninstall tables when MU blog is deleted.
	 * @param  array $tables
	 * @return string[]
	 */
	public static function wpmu_drop_tables( $tables ) {
		global $wpdb;

		//$tables[] = $wpdb->prefix . 'intravel_sessions';
		return $tables;
	}
}

IT_Install::init();
