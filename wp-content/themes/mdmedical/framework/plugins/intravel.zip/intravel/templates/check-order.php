<?php
/**
 * The template for displaying pages
 * @package intravel
 */
get_header();
$message_arr = array();
$message_arr[1] = __('Order invalid.', 'intravel');
$message_arr[2] = __('Code invalid.', 'intravel');
$message_arr[3] = __('Sorry your order can not cancel.', 'intravel');
$message_arr[4] = __('Your order has been cancelled.', 'intravel');
$message_arr[5] = __('Sorry your order can not pay.', 'intravel');
?>
<div class="contents-main intravel-check-order-page" id="contents-main">
    <div class="page-content">
        <div class="main-content">
            <div class="container">
                <?php
                if(isset($_GET['message'])){
                    echo isset($message_arr[$_GET['message']]) ? '<div class="intravel-check-order-message">'.$message_arr[$_GET['message']].'</div>' : '';
                    echo '<div class="back-homepage"><a class="theme-bg" href="'.esc_url(get_home_url()).'">'.__( 'Home page', 'intravel').'</a></div>';
                }elseif(isset($_GET['email']) && isset($_GET['order'])){
                    $booking = it_get_booking($_GET['order']);
                    if($booking->post->ID && $booking->email == $_GET['email']){
                        $tour = it_get_tour($booking->tour);
                        $type = $tour->get_type();
                        echo '<div class="tour-check-order">';
                        echo '<div class="tour-infomation">
                                    <h3><a href="'.esc_url(get_permalink($booking->tour)).'" target="_blank">'.get_the_title($booking->tour).'</a></h3>
                                    <div class="tour-meta">
                                        <span class="tour-duration">' .__('Tour duration: ', 'intravel'). $booking->duration.'</span>, 
                                        '.(!is_wp_error($type) ? '<span class="tour-type">' .__('Tour type: ', 'intravel'). '<a href="'.get_term_link($type->term_id, 'tour_type').'" target="_blank">'.$type->name.'</a></span>' : '').'
                                    </div>
                                </div>';
                        echo '<div class="booking-information">
                                    <h3>' .__('Booking infomation', 'intravel'). '</h3>
                                    <div class="info-item">
                                        <label>' .__('Number of adult: ', 'intravel'). '</label>
                                        <span>'.$booking->adult_ticket.'</span>
                                    </div>
                                    <div class="info-item">
                                        <label>' .__('Number of children: ', 'intravel'). '</label>
                                        <span>'.$booking->children_ticket.'</span>
                                    </div>
                                    <div class="info-item">
                                        <label>' .__('Tour start date: ', 'intravel'). '</label>
                                        <span>'.$booking->start_date.'</span>
                                    </div>
                                    <div class="info-item tour-price-now">
                                        <label>' .__('Total price: ', 'intravel'). '</label>
                                        <span>'.it_price($booking->price, $booking->currency).'</span>
                                    </div>';
                        echo '</div>';
                        if($booking->status == 'pending'){
                            echo '<div class="action-group">';
                            echo '<a href="'.$booking->getCancelUrl().'">'.__('Cancel order', 'intravel').'</a>';
                            echo '<a class="theme-bg" href="'.$booking->getPayUrl().'">'.__('Pay order', 'intravel').'</a>';
                            echo '</div>';
                        }
                        else {
                            echo '<div class="order-status">'.$booking->status.'</div>';
                        }
                    }
                    else{
                        echo '<div class="check-order-desc">'.__('Sorry order is not found.', 'intravel').'</div>';
                    }
                }
                else{
                    ?>
                    <form action="" method="get">
                        <input type="text" name="order" placeholder="<?php _e('Order', 'intravel'); ?>">
                        <input type="email" name="email" placeholder="<?php _e('Email', 'intravel'); ?>">
                        <button class="theme-bg" type="submit"><?php _e('Submit', 'intravel'); ?></button>
                    </form>
                    <?php
                }
                ?>
            </div>
        </div>
    </div>
</div>
<?php get_footer(); ?>
