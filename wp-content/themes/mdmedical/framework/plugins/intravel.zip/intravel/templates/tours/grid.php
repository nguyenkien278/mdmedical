<div class="row">
    <div id="iw-isotope-main" class="tour-listing-grid isotope">
        <?php
        if (have_posts()) : while (have_posts()) : the_post();
            $tour = it_get_tour();
            $duration = $tour->get_duration();
            $price = $tour->get_price();
            $rating_html = $tour->get_rating_html();
            $destinations = $tour->get_destinations();

            ?>
            <div class="col-md-4 col-sm-6 col-xs-12 element-item">
                <div class="tour-item">
                    <div class="image-wrap">
                        <?php $large_image_url = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');
                        $img_url = $large_image_url ? $large_image_url[0] : '';
                        $img_url = inwave_resize($img_url, 270, 255, true);
                        ?>
                        <img src="<?php echo esc_url($img_url); ?>" alt=""/>
                        <div class="booking-action">
                            <a class="link-to-detail theme-bg" href="<?php echo get_permalink(); ?>">
                                <?php echo esc_html__('Book now', 'intravel'); ?>
                            </a>
                        </div>
                    </div>
                    <div class="tour-info-wrap">
                        <div class="info-top">
                            <h3 class="title"><a class="theme-color-hover" href="<?php echo get_permalink(); ?>"><?php echo the_title(); ?></a></h3>
                            <div class="post-meta">
                                <ul>
                                    <?php if ($destinations) :
                                        ?>
                                        <li class="destinations">
                                            <i class="fa fa-map-marker"> </i>
                                            <?php
                                            $destination_html = array();
                                            foreach($destinations as $destination){
                                                $destination_html[] = '<a href="'.esc_url(get_term_link($destination->slug, 'destination')).'" class="destination">'.$destination->name.'</a>';
                                            }
                                            echo implode(' / ', $destination_html);
                                            ?>
                                        </li>
                                    <?php endif; ?>
                                    <?php if ($duration) : ?>
                                        <li>
                                            <span class="duration"><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo $duration; ?></span>
                                        </li>
                                    <?php endif ?>
                                </ul>
                            </div>
                        </div>
                        <div class="tour-price-vote">
                            <?php if ($price) : ?>
                                <span class="price-tour theme-bg"><?php echo it_price($price); ?></span>
                            <?php endif; ?>
                            <div class="iwt-rating">
                                <?php echo $rating_html; ?>
                            </div>
                            <div class="iw-clear_both"></div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
        endwhile;
        endif;
        ?>
    </div>
</div>