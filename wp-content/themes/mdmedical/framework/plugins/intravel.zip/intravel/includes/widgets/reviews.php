<?php
/** Widget tours reviews */
class Inwave_Tours_Reviews extends WP_Widget
{

    function __construct() {
        $widget_ops = array('classname' => 'tour_reviews', 'description' => esc_html__('Display InTravel tour reviews.', 'intravel'));
        parent::__construct('reviews', esc_html__('InTravel Reviews', 'intravel'), $widget_ops);

    }

    public function widget($args, $instance)
    {
        $output = '';
        $limit = isset($instance['limit']) ? strip_tags($instance['limit']) : 3;
        $comments = get_comments(apply_filters('it_widget_reviews_args', array(
            'number' => $limit,
            'post_status' => 'publish',
            'post_type' => 'tour',
            'status' => 'approve'
        )));

        $output .= $args['before_widget'];
        $title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : __( 'Tour Reviews', 'intravel' );
        $title = apply_filters( 'widget_title', $title, $instance, $this->id_base );
        if ($title) {
        $output .= $args['before_title'] . $title . $args['after_title'];
        }
        $output .= '<div class="tours-reviews-widget">';
        if ($comments) {
            // Prime cache for associated posts. (Prime post term cache if we need it for permalinks.)
            $post_ids = array_unique(wp_list_pluck($comments, 'comment_post_ID'));
            _prime_post_caches($post_ids, strpos(get_option('permalink_structure'), '%category%'), false);

            foreach ((array)$comments as $comment) {
                if( $commentrating = get_comment_meta( $comment->comment_ID, 'rating', true ) ) {
                    $commentrating = '<div class="iwt-rating">
                                    <div class="iw-star-rating">
                                        <span class="rating" style="width: ' .esc_attr(($commentrating / 5) * 100). '%"></span>
                                    </div>
                                </div>';
                }
                $output .= '<div class="tours-review-item">';
                /* translators: comments widget: 1: comment author, 2: post link */
                $output .= sprintf(_x('%1$s %2$s %3$s', 'widgets','intravel'),
                    '<a class="review-title" href="' . esc_url(get_comment_link($comment->comment_ID)) . '">' . get_the_title($comment->comment_post_ID) . '</a>',
                    '<div class="review-content">' . wp_trim_words($comment->comment_content, 6, null) . '</div>',
                    '<ul>
                        <li><div class="review-rating">' . $commentrating . '</div></li>
                        <li class="light"></li>
                        <li><div class="review-author-link"><span>' .esc_html__('By ', 'intravel') .'</span><span class="theme-color">' . $comment->comment_author . '</span></div></li>
                    </ul>'
                );
                $output .= '</div>';
            }
        }
        $output .= '</div>';
        $output .= $args['after_widget'];

        echo $output;
    }

    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;
        $instance['title'] = strip_tags($new_instance['title']);
        $instance['limit'] = strip_tags($new_instance['limit']);

        return $instance;
    }

    function form( $instance ) {
        $instance = wp_parse_args( (array) $instance, array( 'title' => __( 'Tour Reviews', 'intravel' ), 'limit' => '3' ) );
        $title = strip_tags($instance['title']);
        $limit = esc_attr($instance['limit']);
        ?>
        <p>
        <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'inevent'); ?></label>
        <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('limit')); ?>"><?php esc_html_e('Limit:', 'motohero'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('limit')); ?>" name="<?php echo esc_attr($this->get_field_name('limit')); ?>" type="text" value="<?php echo esc_attr($limit); ?>" />
        </p>
    <?php
    }
}

function inwave_tours_reviews_widget() {
    register_widget('Inwave_Tours_Reviews');
}
add_action('widgets_init', 'inwave_tours_reviews_widget');