<?php
/**
 * The template for displaying pages
 * @package intravel
 */
get_header();
$cart = IT()->get_cart();
$selected_services = '';
if($cart){
    $tour = it_get_tour($cart['tour']);
    $duration = $tour->duration;
    $tour_type_name = $tour->get_type('name');
    $customer = it_get_customer();
    wp_localize_script('plg-intravel', 'tourData', array(
        'tour_id' => $tour->id,
        'booking_days' => json_encode($tour->get_booking_days()),
        'get_msg_tax' => true,
    ));
    $booking_day = $tour->get_booking_day();
    $tour_services = wp_get_post_terms( $tour->id, 'tour_service' );
    $selected_services = isset($cart['intravel_service']) ? (array)$cart['intravel_service'] : array();
}
?>
<div class="contents-main intravel-checkout-page" id="contents-main" xmlns="http://www.w3.org/1999/html">
    <div class="page-content">
        <div class="main-content">
            <div class="container">
                <?php
                    if($cart){
                ?>
                <form action="<?php echo it_get_checkout_form_url(); ?>" method="post" class="tour-checkout-form">
                    <div class="row">
                        <div class="col-md-8 col-sm-12 col-xs-12">
                                <div class="tour-infomation">
                                    <h3><a href="<?php echo esc_url(get_permalink($tour->get_id())); ?>" target="_blank"><?php echo get_the_title($tour->get_id()) ?></a></h3>
                                    <div class="tour-meta">
                                        <?php if($duration) : ?>
                                            <span class="tour-duration"><?php echo __('Tour duration: ', 'intravel') . $duration; ?></span>
                                        <?php endif; ?>
                                        <?php if($tour_type_name) : ?>
                                            <span class="tour-type"><?php echo __('Tour type: ', 'intravel');?><a href="<?php echo esc_url(get_term_link($tour->get_type('term_id'), 'tour_type')) ;?>" target="_blank"><?php echo $tour_type_name; ?></a></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="personal-info">
                                    <h3><?php echo __('Personal infomation', 'intravel'); ?></h3>
                                    <div class="personal-main">
                                        <div class="input-row">
                                            <label><?php _e('Your first name', 'intravel');?></label>
                                            <span><input class="form-control" type="text" name="first_name" value="<?php echo esc_attr($customer->first_name); ?>" required/></span>
                                        </div>
                                        <div class="input-row">
                                            <label><?php _e('Your last name', 'intravel');?></label>
                                            <span><input class="form-control" type="text" name="last_name" value="<?php echo esc_attr($customer->last_name); ?>" required/></span>
                                        </div>
                                        <div class="input-row">
                                            <label><?php _e('Your email', 'intravel');?></label>
                                            <span><input class="form-control" type="email" name="email" value="<?php echo esc_attr($customer->email); ?>" required/></span>
                                        </div>
                                        <div class="input-row">
                                            <label><?php _e('Your phone', 'intravel');?></label>
                                            <span><input class="form-control" type="text" name="phone" value="<?php echo esc_attr($customer->phone); ?>" required/></span>
                                        </div>
                                        <div class="input-row">
                                            <label><?php _e('Additional infomation', 'intravel');?></label>
                                            <span class="textarea"><textarea class="form-control" name="special_requirements"></textarea></span>
                                        </div>
                                    </div>
                                </div>
                        </div>
                        <div class="col-md-4 col-sm-12 col-xs-12">
                            <div class="checkout-left-col">
                                <div class="booking-information">
                                    <h3><?php echo __('Booking infomation', 'intravel'); ?></h3>
                                    <div class="input-row">
                                        <label><?php _e('Number of adult: ', 'intravel'); ?></label>
                                        <span><input type="text" class="form-control adult_ticket" name="adult_ticket" value="<?php echo $cart['adult_ticket']; ?>"></span>
                                    </div>
                                    <div class="input-row">
                                        <label><?php _e('Number of children: ', 'intravel'); ?></label>
                                        <span><input type="text" class="form-control children_ticket" name="children_ticket" value="<?php echo $cart['children_ticket']; ?>"></span>
                                    </div>
                                    <div class="input-row">
                                        <label><?php _e('Start date: ', 'intravel'); ?></label>
                                        <span><input type="text" class="form-control tour_start_date" name="start_date" value="<?php echo $cart['start_date']; ?>" required></span>
                                    </div>
                                    <?php
                                    if($tour->get_start_time()){
                                        $start_time_value = isset($cart['start_time']) ? $cart['start_time'] : '';
                                        ?>
                                        <div class="input-row start-time">
                                            <label><?php _e('Start time: ', 'intravel'); ?></label>
                                            <span>
                                            <select class="tour_start_time form-control" name="start_time" title="<?php echo __('Start time', 'intravel'); ?>">
                                                <?php foreach ($tour->get_start_time() as $start_time){?>
                                                    <option value="<?php echo esc_attr($start_time); ?>"><?php echo esc_html($start_time); ?></option>
                                                <?php } ?>
                                            </select>
                                            </span>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                    <div class="tour-services-now">
                                        <?php it_get_template_part('checkout/form-checkout-services'); ?>
                                    </div>
                                    <div class="input-row tour-price-now">
                                        <div class="msg-wrap">
                                            <?php
                                            $price_status = $tour->get_price_status($cart['start_date'], $cart['adult_ticket'], $cart['children_ticket'] , $selected_services, false, true);
                                            echo $price_status['msg'];
                                            ?>
                                        </div>
                                        <img alt="" src="<?php echo INTRAVEL_PLUGIN_URL.'/assets/img/facebook-loading.gif'; ?>"></div>
										<div class="clearfix"></div>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="payment-method">
                                    <h3><?php echo __('Payment method', 'intravel'); ?></h3>
                                    <?php
                                    $payment_methods = it_get_payment_methods();
                                    foreach ($payment_methods as $payment_method => $payment_method_title){
                                        ?>
                                        <div><label><input type="radio" name="payment_method" value="<?php echo $payment_method; ?>" <?php echo ($payment_method == 'submit_form') ? 'checked' : ''; ?>><?php echo $payment_method_title;?></label></div>
                                        <?php
                                    }
                                    ?>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="button-group">
                                    <input type="hidden" name="intravel-action" value="submit-tour"/>
                                    <input type="hidden" name="tour" value="<?php echo $tour->id; ?>"/>
                                    <?php wp_nonce_field('intravel-verify'); ?>
                                    <button type="submit" class="btn theme-bg tour-submit-form checkout-process-btn" value="submit"><?php _e('Process', 'intravel'); ?></button>
                                    <a href="<?php echo esc_url(get_permalink($tour->get_id())); ?>" class="btn cancel-btn"><?php _e('Cancel', 'intravel'); ?></a>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                </form>
                <?php }else{ ?>
                <div class="empty-cart">
                    <?php _e('Sorry empty cart', 'intravel'); ?>
                </div>
                 <?php } ?>
            </div>
        </div>
    </div>
</div>
<?php get_footer(); ?>
