<?php

/*
 * Inwave Slider for Visual Composer
 */
if (!class_exists('Inwave_Search_Tour_Form')) {

    class Inwave_Search_Tour_Form extends Inwave_Shortcode{

        protected $name = 'inwave_search_tour_form';

        function init_params(){
            return array(
                "name" => __("Intravel Search Tour - Form", 'inwavethemes'),
                "base" => $this->name,
                "class" => "inwave_search_tour_form",
                'icon' => 'iw-default',
                'category' => 'Custom',
                "description" => __("Search tour in Travel", "inwavethemes"),
                "show_settings_on_create" => true,
                "params" => array(
					array(
                        "type" => "dropdown",
                        "admin_label" => true,
                        "heading" => __("Style", "inwavethemes"),
                        "param_name" => "style",
                        "value" => array(
                            'Style 1' => 'style1',
							'Style 2' => 'style2',
                        )
                    ),
					array(
                        "type" => "iwevent_preview_image",
                        "heading" => __("Preview Style", "inwavethemes"),
                        "param_name" => "preview_style1",
                        "value" => get_template_directory_uri() . '/assets/images/shortcodes/preview_search_tour_style2.jpg',
					//	"dependency" => array('element' => 'style', 'value' => 'style2')
                    ),
					array(
                        'type' => 'textfield',
                        "holder" => "span",
                        "heading" => __("Title form", "inwavethemes"),
                        "description" => __("You can add |TEXT_EXAMPLE| to specify strong words, <br />{TEXT_EXAMPLE} to specify colorful words, <br />'///' to insert line break tag (br)", "inwavethemes"),
                        "value" => "Find your tours",
                        "param_name" => "title",
					//	"dependency" => array('element' => 'style', 'value' => 'style2')
                    ),
					array(
                        'type' => 'textarea',
                        "heading" => __("Description", "inwavethemes"),
                        "value" => "",
                        "param_name" => "description",
                    //	"dependency" => array("element" => "style", "value" => array("style2")
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Extra Class", "inwavethemes"),
                        "param_name" => "extra_class",
                        "value" => "",
                        "description" => __("Write your own CSS and mention the class name here.", "inwavethemes"),
                    )
                )
            );
        }

        // Shortcode handler function for search tour
        function init_shortcode($atts, $content = null) {

            if(!class_exists('inTravel')){
                return __('Please active the plugin inTravel', 'inwavethemes');
            }

            $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( $this->name, $atts ) : $atts;

            $output = $style = $extra_class = $title = $description = '';

            extract(shortcode_atts(array(
				'style'					=> '',
				'title'					=> '',
				'description'			=> '',
                'extra_class'        	=> ''
            ), $atts));
			
			$title= preg_replace('/\|(.*)\|/isU','<strong>$1</strong>',$title);
            $title= preg_replace('/\{(.*)\}/isU','<span class="theme-color">$1</span>',$title);
            $title= preg_replace('/\/\/\//i', '<br />', $title);

            $destinations = get_terms(array('taxonomy' => 'destination'));
            $tour_types = get_terms(array('taxonomy' => 'tour_type'));

			
			$min_price = isset($_GET['min_price']) ? esc_attr($_GET['min_price']) : '';
            $max_price = isset($_GET['max_price']) ? esc_attr($_GET['max_price']) : '';
            // Find min and max price in current result set
            $prices = it_get_filtered_price();
            $min = floor($prices->min_price);
            $max = ceil($prices->max_price);
            if ($min !== $max) {
                if (it_is_taxable() && 'incl' === it_get_option('tax_display_tours', 'excl') && it_get_option('prices_include_tax', 'no') === 'no') {
                    $tax = it_get_tax();
                    $max = $max + $tax;
                }
                ob_start();
                ?>
                <div class="form-group">
                    <div class="tour_price_slider_wrapper" data-style="<?php echo $style; ?>">
                        <div class="tour_price_slider" style="display:none;"></div>
                        <div class="tour_price_slider_amount">
                            <input type="text" class="tour_min_price" name="min_price"
                                   value="<?php echo esc_attr($min_price); ?>"
                                   data-min="<?php echo esc_attr(apply_filters('it_price_filter_widget_min_amount', $min)); ?>"
                                   placeholder="<?php echo esc_attr__('Min price', 'intravel'); ?>"/>
                            <input type="text" class="tour_max_price" name="max_price"
                                   value="<?php echo esc_attr($max_price); ?>"
                                   data-max="<?php echo esc_attr(apply_filters('it_price_filter_widget_max_amount', $max)); ?>"
                                   placeholder="<?php echo esc_attr__('Max price', 'intravel'); ?>"/>
                            <?php if($style == 'style1'){ ?>
                                <div class="price_label" style="display:none;">
                                    <?php echo __('Price:', 'intravel'); ?> <span class="from"></span> &mdash;
                                    <span class="to"></span>
                                </div>
                            <?php } ?>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
            <?php }
            $content = ob_get_clean();			
			
			switch ($style) {
				case 'style1':
					$output .= '<div class="intravel-search-tour style1">';
					$output .= '<form class="tour-search-form" action="'.esc_url(it_get_page_permalink('tours')).'" method="get">';
					if ($title || $description){
						$output .= '<div class="title-block-form">';
						if ($title){
							$output .= '<h3 class="title-form">'.$title.'</h3>';
						}
						if ($description){
							$output .= '<div class="desc-form">'.$description.'</div>';
						}
						$output .= '</div>';
					}
					$output .= '<div class="field-group">';
					$output .= '<div class="field-text-search">';
						$output .= '<input class="input-text" type="text" placeholder="'.esc_html__('Enter tour name', 'inwavethemes').'" name="s" value="'.(isset($_GET['s']) ? esc_attr($_GET['s']) : '').'">';
					$output .= '</div>';
					$output .= '</div>';
					$output .= '<div class="field-group">';
					$output .= '<div class="field-destination">';
						$output .= '<select class="form-control js-selected " name="destination">';

						$output .= '<option value="">'.esc_html__('Choose your destination', 'inwavethemes').'</option>';
						if($destinations){
							$destination_value = isset($_GET['destination']) ? esc_attr($_GET['destination']) : '';
							foreach ($destinations as $destination){
								$output .= '<option value="'.esc_attr($destination->slug).'" '.($destination_value == $destination->slug ? 'selected' : '').'>'.$destination->name.'</option>';
							}
						}
						$output .= '</select>';
					$output .= '</div>';
					$output .= '</div>';
					
					
				$output .= '<div class="row">';	
				$output .= '<div class="col-md-6 col-sm-12 col-xs-12">';	
					$output .= '<div class="field-group">';
					$output .= '<div class="field-tour-type">';
						$output .= '<select class="form-control js-selected " name="tour_type">';

						$output .= '<option value="">'.esc_html__('Choose your tour type', 'inwavethemes').'</option>';
						if($tour_types){
							$tour_type_value = isset($_GET['tour_type']) ? esc_attr($_GET['tour_type']) : '';
							foreach ($tour_types as $tour_type){
								$output .= '<option value="'.esc_attr($tour_type->slug).'" '.($tour_type_value == $tour_type->slug ? 'selected' : '').'>'.$tour_type->name.'</option>';
							}
						}
						$output .= '</select>';
					$output .= '</div>';
					$output .= '</div>';
				$output .= '</div>';	
				$output .= '<div class="col-md-6 col-sm-12 col-xs-12">';	
					$output .= '<div class="field-group">';
					$output .= '<div class="field-start-date">';
						$output .= '<input class="input-text has-date-picker" type="text" placeholder="'.esc_html__('Tour start date', 'inwavethemes').'" name="start_date" value="" />';
					$output .= '</div>';
					$output .= '</div>';
				$output .= '</div>';
				$output .= '</div>';	
					
					
					$output .= '<div class="price">';
					$output .= $content;
					$output .= '</div>';
					
					$output .= '<div class="field-button">';
					$output .= '<button class="theme-bg-hover">'.esc_html__('Search', 'intravel').'</button>';
					$output .= '</div>';
					
					$output .= '</form>';
					$output .= '</div>';
				break;

                case 'style2':
                    $output .= '<div class="intravel-search-tour style2">';
                    $output .= '<form class="tour-search-form" action="'.esc_url(it_get_page_permalink('tours')).'" method="get">';
                    if ($title || $description){
                        $output .= '<div class="title-block-form">';
                        if ($title){
                            $output .= '<h3 class="title-form">'.$title.'</h3>';
                        }
                        if ($description){
                            $output .= '<div class="desc-form">'.$description.'</div>';
                        }
                        $output .= '</div>';
                    }
                    $output .= '<div class="field-group">';
                    $output .= '<div class="field-text-search field-item">';
                    $output .= '<input class="input-text" type="text" placeholder="'.esc_html__('Enter tour name', 'inwavethemes').'" name="s" value="'.(isset($_GET['s']) ? esc_attr($_GET['s']) : '').'">';
                    $output .= '</div>';
                    $output .= '<div class="field-destination field-item">';
                    $output .= '<select class="form-control js-selected " name="destination">';
                    $output .= '<option value="">'.esc_html__('Destination', 'inwavethemes').'</option>';
                    if($destinations){
                        $destination_value = isset($_GET['destination']) ? esc_attr($_GET['destination']) : '';
                        foreach ($destinations as $destination){
                            $output .= '<option value="'.esc_attr($destination->slug).'" '.($destination_value == $destination->slug ? 'selected' : '').'>'.$destination->name.'</option>';
                        }
                    }
                    $output .= '</select>';
                    $output .= '</div>';
                    $output .= '<div class="field-tour-type field-item">';
                    $output .= '<select class="form-control js-selected " name="tour_type">';
                    $output .= '<option value="">'.esc_html__('Choose tour type', 'inwavethemes').'</option>';
                    if($tour_types){
                        $tour_type_value = isset($_GET['tour_type']) ? esc_attr($_GET['tour_type']) : '';
                        foreach ($tour_types as $tour_type){
                            $output .= '<option value="'.esc_attr($tour_type->slug).'" '.($tour_type_value == $tour_type->slug ? 'selected' : '').'>'.$tour_type->name.'</option>';
                        }
                    }
                    $output .= '</select>';
                    $output .= '</div>';
                    $output .= '<div class="field-start-date field-item">';
                    $output .= '<input class="input-text has-date-picker" type="text" placeholder="'.esc_html__('Tour start date', 'inwavethemes').'" name="start_date" value="" />';
                    $output .= '</div>';
                    $output .= '<div class="price field-item">';
                    $output .= $content;
                    $output .= '</div>';
                    $output .= '<div class="clearfix"></div>';
                    $output .= '</div>';
                    $output .= '<div class="field-button">';
                    $output .= '<div class="border"><button class="theme-bg">'.esc_html__('Search', 'intravel').'</button></div>';
                    $output .= '</div>';
                    $output .= '</form>';
                    $output .= '</div>';
                    break;
			}

            return $output;
        }
    }
}

new Inwave_Search_Tour_Form;

//if (class_exists('WPBakeryShortCodesContainer')) {
//    class WPBakeryShortCode_Inwave_Search_Tour extends WPBakeryShortCodesContainer {
 //   }
//}
