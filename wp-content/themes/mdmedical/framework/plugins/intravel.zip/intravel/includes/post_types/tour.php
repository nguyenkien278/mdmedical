<?php
class IT_Tour_Post_Type{
    function __construct()
    {
        add_action('init', array($this, 'register'));
        add_action('admin_menu', array($this, 'custom_admin_menu'));
        //add_action('save_post', array($this, 'custom_save_post'), 100, 1);
        add_filter('cmb2_admin_init', array($this, 'meta_boxes'));
        add_filter('cmb2_types_esc_text_date', array($this, 'cmb2_types_esc_text_date'), 10, 4);
       // add_filter('cmb2_validate_text_date', array($this, 'cmb_validate_text_date'), 10, 5);
        add_action('save_post', array($this, 'custom_save_post'), 100, 1);
        add_action('cmb2_before_post_form_intravel_tour_metabox', array($this, 'before_tabs'), 10, 2);
        add_filter('get_terms_defaults', array($this, 'get_terms_defaults_includes'), 10, 1);
        add_filter('request', array($this, 'custom_request' ));
        add_filter('manage_posts_columns' , array($this, 'custom_columns_head' ));
        add_filter('manage_posts_custom_column' , array($this, 'custom_columns_content' ), 10, 2);
        add_filter('manage_edit-tour_sortable_columns', array($this, 'custom_tour_sortable_columns' ));
        add_filter('cmb2_validate_file_list', array($this, 'cmb2_validate_file_list'), 10 ,5);
        add_filter('cmb2_types_esc_file_list', array($this, 'cmb2_types_esc_file_list'), 10 ,4);
    }

    function get_terms_defaults_includes($arg){
        if(isset($_POST['action']) && isset($_POST['tax']) && $_POST['action'] == 'get-tagcloud' && $_POST['tax'] == 'tour_feature'){
            $arg['number'] = '';
            $arg['hide_empty'] = false;
        }

        return $arg;
    }
    function register(){
        //Resigter Tour
        $labels = array(
            'name' 					=> __('Tours', 'intravel'),
            'singular_name' 		=> __('Tour', 'intravel'),
            'add_new' 				=> __('Add New', 'intravel'),
            'all_items' 			=> __('Tours', 'intravel'),
            'add_new_item' 			=> __('Add New Tour', 'intravel'),
            'edit_item' 			=> __('Edit Tour', 'intravel'),
            'new_item' 				=> __('New Tour', 'intravel'),
            'view_item' 			=> __('View Tour', 'intravel'),
            'search_items' 			=> __('Search Tour', 'intravel'),
            'not_found' 			=> __('No Tour Found', 'intravel'),
            'not_found_in_trash' 	=> __('No Tour Found in Trash', 'intravel'),
            'parent_item_colon' 	=> '',
        );

        $args = array(
            'labels' 			=> $labels,
            'public' 			=> true,
            'show_ui' 			=> true,
            'capability_type' 	=> 'post',
            'taxonomies'        => array( 'tour_cats', ),
            'hierarchical' 		=> false,
            'rewrite' 			=> array('slug' => it_get_option('tour_slug', 'tour'), 'with_front' => true),
            //'query_var' 		=> true,
            'show_in_nav_menus' => true,
            'has_archive'       => true,
            'menu_icon' 		=> 'dashicons-admin-post',
            'supports' 			=> array('title', 'thumbnail', 'excerpt', 'editor', 'author','tags', 'comments'),
        );

        register_post_type( 'tour' , $args );

        //Register Tour Type
        $labels = array(
            'name' 					=> __('Tour Types', 'intravel'),
            'popular_items' 		=> __('Popular Types', 'intravel'),
            'singular_name' 		=> __('Tour Type', 'intravel'),
            'add_new' 				=> __('Add New', 'intravel'),
            'all_items' 			=> __('Tour Type', 'intravel'),
            'add_new_item' 			=> __('Add New Type', 'intravel'),
            'edit_item' 			=> __('Edit Type', 'intravel'),
            'new_item' 				=> __('New Type', 'intravel'),
            'view_item' 			=> __('View Type', 'intravel'),
            'search_items' 			=> __('Search Type', 'intravel'),
            'not_found' 			=> __('No Type Found', 'intravel'),
            'no_terms' 	            => __('No Types', 'intravel'),
        );
        register_taxonomy('tour_type',
            array('tour'),
            array(
                'hierarchical' 		=> true,
                'public'            => true,
                'labels' 			=> $labels,
                'show_admin_column'	=>'true',
                'singular_label' 	=> 'Tour Type',
                //'query_var' 		=> true,
                'rewrite'           => array(
                    'slug'                       => it_get_option('tour_type_slug', 'tour-type'),
                    'with_front'                 => true,
                    'hierarchical'               => false,
                ),
            )
        );

        //Register Tour Tag
        $labels = array(
            'name' 					=> __('Tour Tags', 'intravel'),
            'popular_items' 		=> __('Popular Tags', 'intravel'),
            'singular_name' 		=> __('Tour Tag', 'intravel'),
            'add_new' 				=> __('Add New', 'intravel'),
            'all_items' 			=> __('Tour Tag', 'intravel'),
            'add_new_item' 			=> __('Add New Tag', 'intravel'),
            'edit_item' 			=> __('Edit Tag', 'intravel'),
            'new_item' 				=> __('New Tag', 'intravel'),
            'view_item' 			=> __('View Tag', 'intravel'),
            'search_items' 			=> __('Search Tag', 'intravel'),
            'not_found' 			=> __('No Tag Found', 'intravel'),
            'no_terms' 	            => __('No Tag', 'intravel'),
        );

        register_taxonomy('tour_tag',
            array('tour'),
            array(
                'hierarchical' 		=> false,
                'public'            => true,
                'labels' 			=> $labels,
                'show_admin_column'	=>'true',
                'singular_label' 	=> 'Tour Tag',
                //'query_var' 		=> true,
                'rewrite'           => array(
                    'slug'                       => it_get_option('tour_tag_slug', 'tour-tag'),
                    'with_front'                 => true,
                    'hierarchical'               => false,
                ),
            )
        );

        //Register Feature list
        $labels = array(
            'name' 					=> __('Tour Include list', 'intravel'),
            'popular_items' 		=> __('Popular Includes', 'intravel'),
            'singular_name' 		=> __('Tour Include', 'intravel'),
            'add_new' 				=> __('Add New', 'intravel'),
            'all_items' 			=> __('Tour Include', 'intravel'),
            'add_new_item' 			=> __('Add New Include', 'intravel'),
            'edit_item' 			=> __('Edit Include', 'intravel'),
            'new_item' 				=> __('New Include', 'intravel'),
            'view_item' 			=> __('View Include', 'intravel'),
            'search_items' 			=> __('Search Include', 'intravel'),
            'not_found' 			=> __('No Include Found', 'intravel'),
            'no_terms' 	            => __('No Include', 'intravel'),
            'choose_from_most_used' => __( 'Choose from the most used include list', 'intravel' )
        );

        register_taxonomy('tour_feature',
            array('tour'),
            array(
                'hierarchical' 		=> false,
                'public'            => true,
                'labels' 			=> $labels,
                'singular_label' 	=> 'Tour Feature',
                //'query_var' 		=> true,
                'show_tagcloud'     => false,
                'show_admin_column' => false,
                'rewrite'           => array(
                    'slug'                       => 'tour-feature',
                    'with_front'                 => true,
                    'hierarchical'               => false,
                ),
            )
        );
    }

    /* Add custom column to post list */
    function custom_columns_head( $columns )
    {
        $screen = get_current_screen();
        if ($screen->post_type == 'tour') {
            $new_columns = array();
            foreach ($columns as $key => $column){
                if($key == 'author'){
                    continue;
                }
                if($key == 'comments'){
                    $new_columns['sales'] = __('Sales', 'intravel');
                }
                $new_columns[$key] = $column;
            }

            $columns = $new_columns;
        }

        return $columns;
    }

    /* Add custom column to post list */
    function custom_columns_content( $column, $post_ID ) {
        $screen = get_current_screen();
        if($screen->post_type == 'tour'){
            if($column == 'sales') {
                $link = admin_url('edit.php?post_type=tour_booking&tour_id='.$post_ID);
                echo '<a href="' . $link . '">' . __('View Sales', 'intravel') . '</a>';
            }
        }
    }

    function custom_tour_sortable_columns($columns){
        $columns['sales'] = 'sales';

        return $columns;
    }

    function custom_request($vars){
        if ( isset( $vars['orderby'] )){
           if ($vars['orderby'] == 'sales'){
                $vars = array_merge( $vars, array(
                    'meta_key' => 'intravel_total_sales', //Custom field key
                    'orderby' => 'meta_value_num') //Custom field value (number)
                );
            }
        }

        return $vars;
    }

    function meta_boxes(){
        $prefix = 'intravel_';

        global $post;

        $sale_from = $sale_to = '';

        $post_id = 0;
        if($post){
            $post_id = $post->ID;
        }else if(isset($_GET['post'])){
            $post_id = $_GET['post'];
        }

        $feature_list = array();
        if($post_id){
            $sale_from = get_post_meta($post_id, 'intravel_sale_from', true);
            $sale_to = get_post_meta($post_id, 'intravel_sale_to', true);
            $terms = wp_get_post_terms( $post_id, 'tour_type');
            if($terms){
                $tour_type = $terms[0];
                $_feature_list = (array)get_term_meta($tour_type->term_id, 'intravel_feature_list', true);
                foreach ($_feature_list as $feature){
                    $feature_list[$feature] = $feature;
                }
            }
        }

        $meta_boxes = new_cmb2_box( array(
            'id'            => $prefix . 'tour_metabox',
            'title'         => __('Tour Metabox', 'intravel'),
            'object_types'  => array( 'tour', ), // Post type
            // 'show_on_cb' => 'yourprefix_show_if_front_page', // function should return a bool value
            // 'context'    => 'normal',
            // 'priority'   => 'high',
            // 'show_names' => true, // Show field names on the left
            // 'cmb_styles' => false, // false to disable the CMB stylesheet
            // 'closed'     => true, // true to keep the metabox closed by default
            // 'classes'    => 'extra-class', // Extra cmb2-wrap classes
            // 'classes_cb' => 'yourprefix_add_some_classes', // Add classes through a callback.
        ) );

        /*$meta_boxes->add_field(array(
            'name'       => __( 'Type', 'intravel' ),
            'id'         => $prefix . 'tour_type',
            'type'       => 'taxonomy_select',
            'taxonomy' => 'tour_type',
            'before_row'   => array($this, 'before_row'), // callback
            'tab_id'   => 'tab-1',
        ) );*/

        $meta_boxes->add_field(array(
            'name' => __( 'Featured', 'intravel' ),
            'id'   => $prefix . 'featured',
            'type' => 'radio',
            'options' => array(
                'yes'   => __( 'Yes', 'intravel' ),
                'no'     => __( 'No', 'intravel' ),
            ),
            'default' => 'no',
            'before_row'   => array($this, 'before_row'), // callback
            'tab_id'   => 'tab-1',
        ) );

        $meta_boxes->add_field(array(
            'name' => __('Heading image', 'intravel' ),
            'id'   => $prefix . 'heading_image',
            'type' => 'file',
            'filter'  => 'gallery'
        ) );

        $meta_boxes->add_field(array(
            'name' => __('Gallery', 'intravel' ),
            'id'   => $prefix . 'gallery',
            'type' => 'file_list',
            'filter'  => 'gallery',
            'after_row' => '</div>'
        ) );
        /*$meta_boxes->add_field( array(
            'name' => '',
            'id'   => $prefix . 'schedules',
            'type'    => 'iwschedule',
            //'before_row'   => array($this, 'before_row'), // callback
           // 'after_row' => '</div>',
            //'tab_id'   => 'tab-3',
        ) );*/
/*        $meta_boxes->add_field(array(
            'name' => __('Map Direction', 'intravel' ),
            'id'   => $prefix . 'map_direction',
            'type' => 'intravelmapdirection',
            'after_row' => '</div>'
        ) );*/

       /* $meta_boxes->add_field(array(
            'name' => __('Map', 'intravel' ),
            'id'   => $prefix . 'map',
            'type' => 'iwmap',
            'after_row' => '</div>'
        ) );*/

       /*$meta_boxes->add_field(array(
            'name' => __('Feature List', 'intravel' ),
            'id'   => $prefix . 'feature_list',
           'type'       => 'taxonomy_select',
           'taxonomy' => 'tour_type',
           'attributes' => array(
               'multiple' => 'multiple',
               'size' => 7
           ),
            'after_row' => '</div>'
        ) );*/

        $meta_boxes->add_field(array(
            'name' => __('Adult Price', 'intravel' ),
            'id'   => $prefix . 'regular_price',
            'type' => 'text',
            'before_row'   => array($this, 'before_row'), // callback
            'tab_id'   => 'tab-2',
            'after'   => ' ('.it_get_currency_symbol().')',
            'attributes' => array(
                'placeholder' => __('Free', 'intravel')
            )
        ) );

        $meta_boxes->add_field(array(
            'name' => __('Children Price', 'intravel' ),
            'id'   => $prefix . 'children_regular_price',
            'type' => 'text',
            'attributes' => array(
                'placeholder' => __('Free', 'intravel')
            )
        ) );

        $meta_boxes->add_field(array(
            'name' => __('Discount', 'intravel' ),
            'id'   => $prefix . 'discount',
            'type' => 'text',
            'after'   => ' (%) <a href="#" class="tour-discount-schedule">'.(($sale_from || $sale_to) ? 'Cancel Schedule' : 'Schedule').'</a>',
        ) );

        $meta_boxes->add_field(array(
            'name' => __('Discount From Date', 'intravel' ),
            'id'   => $prefix . 'discount_from',
            'type' => 'text_date',
            'after'   => ' '.__('m/d/Y', 'intravel'),
        ) );

        $meta_boxes->add_field(array(
            'name' => __('Discount To Date', 'intravel' ),
            'id'   => $prefix . 'discount_to',
            'type' => 'text_date',
            'after'   => ' '.__('m/d/Y', 'intravel'),
        ) );

        $meta_boxes->add_field(array(
            'name' => __('Tickets', 'intravel' ),
            'id'   => $prefix . 'tickets',
            'type' => 'text',
            'attributes' => array('placeholder' => __('Unlimited'))
        ) );

        $meta_boxes->add_field(array(
            'name' => __('Children Tickets', 'intravel' ),
            'id'   => $prefix . 'children_tickets',
            'type' => 'text',
            'attributes' => array('placeholder' => __('Unlimited'))
        ) );

        $meta_boxes->add_field(array(
            'name' => __('Start Date', 'intravel' ),
            'id'   => $prefix . 'start_date',
            'type' => 'text_date',
            'after'   => ' '.__('m/d/Y', 'intravel'),
        ) );
        $meta_boxes->add_field(array(
            'name' => __('Start Time', 'intravel' ),
            'desc' => __('Each line is a value.', 'intravel' ),
            'id'   => $prefix . 'start_time',
            'attributes' => array(
                'rows' => 5
            ),
            'type' => 'textarea',
        ) );
        $meta_boxes->add_field(array(
            'name' => __('End Date', 'intravel' ),
            'id'   => $prefix . 'end_date',
            'type' => 'text_date',
            'after'   => ' '.__('m/d/Y', 'intravel'),
            'attributes' => array(
                'placeholder' => __('Unlimited', 'intravel')
            )
        ) );

        $options = array(
            'Monday' => __('Monday', 'intravel'),
            'Tuesday' => __('Tuesday', 'intravel'),
            'Wednesday' => __('Wednesday', 'intravel'),
            'Thursday' => __('Thursday', 'intravel'),
            'Friday' => __('Friday', 'intravel'),
            'Saturday' => __('Saturday', 'intravel'),
            'Sunday' => __('Sunday', 'intravel'),
        );
        $meta_boxes->add_field(array(
            'name' => __('Available days', 'intravel' ),
            'id'   => $prefix . 'available_days',
            'type'    => 'multicheck',
            'options' => $options,
            'default' => array($options),
            'attributes' => count($options) > 8 ? array('class' => 'colums-3') : array()
        ) );

        $meta_boxes->add_field(array(
            'name' => __('Duration', 'intravel' ),
            'id'   => $prefix . 'duration',
            'type' => 'text',
        ) );
        $args = array(
            'taxonomy' => 'tour_service',
            'orderby' => 'term_group',
            'parent' => '0',
            'hide_empty' => false,
        );
        $meta_boxes->add_field(array(
            'name' => '',
            'id'   => $prefix . 'periods',
            'type'    => 'iwperiod',
            'after_row' => '</div>',
            'before_field' => '<h1 class="intravel-alt">'.__('Custom Price & Tickets', 'intravel').'</h1>',
        ) );


        $meta_boxes->add_field( array(
            'name' => '',
            'id'   => $prefix . 'schedules',
            'type'    => 'iwschedule',
            'before_row'   => array($this, 'before_row'), // callback
            'after_row' => '</div>',
            'tab_id'   => 'tab-3',
        ) );

        $_tour_services = get_terms($args);
        $tour_services = array();
        if($_tour_services){
            foreach ($_tour_services as $_tour_service){
                if($_tour_service->parent){
                    $tour_services[$_tour_service->term_id] = '--'.$_tour_service->name;
                }
                else{
                    $tour_services[$_tour_service->term_id] = $_tour_service->name;
                }
            }
        }
        $meta_boxes->add_field(array(
            //'name'       => __( 'Additional Services', 'intravel' ),
            'desc'       => __( 'Navigation to Tours > Services to add more service', 'intravel' ),
            'id'         => $prefix . 'tour_service',
            'type'       => 'multicheck',
            'options' => $tour_services,
            'before_row'   => array($this, 'before_row'), // callback
            'after_row' => '</div>',
            'tab_id'   => 'tab-4',
        ) );

        $cmb_term = new_cmb2_box( array(
            'id'               => $prefix . 'tour_type_metabox',
            'title'            => 'Tour Type Metabox',
            'object_types'     => array( 'term' ),
            'taxonomies'       => array( 'tour_type'),
            'new_term_section' => true,
        ) );

        /*$cmb_term->add_field( array(
            'name'      => 'Font AwesomeIcon',
            'desc'      => 'Font AwesomIcon. Ex: fa-home',
            'id'        => $prefix . 'icon',
            'type'      => 'text',
        ) );*/

        $cmb_term->add_field( array(
            'name'      => 'Icon',
            'desc'      => 'Select icon image',
            'id'        => $prefix . 'icon_image',
            'type'      => 'file',
            'filter'  => 'gallery'
        ) );
        $cmb_term->add_field( array(
            'name'      => __('Image','intravel'),
            'id'        => $prefix . 'image',
            'type'      => 'file',
        ) );
        /*$cmb_term->add_field( array(
            'name'      => 'Feature List',
            'id'        => $prefix . 'feature_list',
            'type'      => 'text',
            'repeatable' => true,
        ) );*/
    }

    function before_row($field_args, $field){
        $tab_id = $field->args( 'tab_id' );
        if($tab_id){
            echo '<div class="int-tabs-content" id="'.$tab_id.'">';
        }
    }

    function before_tabs($object_id, $cmb2){
        echo '<ul class="int-tabs-menu">';
        echo '<li class="current"><a href="#tab-1">' . __('General', 'intravel') . '</a></li>';
        echo '<li ><a href="#tab-2">' . __('Price & Tickets', 'intravel') . '</a></li>';
        echo '<li ><a href="#tab-3">' . __('Schedules', 'intravel') . '</a></li>';
        echo '<li ><a href="#tab-4">' . __('Additional Services', 'intravel') . '</a></li>';
        echo '</ul>';
    }

    function custom_admin_menu(){
        // Disable new tour link
        global $submenu;
        unset($submenu['edit.php?post_type=tour'][10]);
        // Hide link on listing page
        /*if (isset($_GET['post_type']) && $_GET['post_type'] == 'tour') {
            echo '<style type="text/css">
            .add-new-h2{ display:none; }
            </style>';
        }*/

        //remove support in tour booking
        remove_post_type_support( 'tour_booking', 'title' );
        remove_post_type_support( 'tour_booking', 'editor' );
    }

    function cmb2_types_esc_text_date($null, $value, $args, $self){
        if($value && ($args['id'] == 'intravel_discount_from' || $args['id'] == 'intravel_discount_to')){
             return date('m/d/Y', $value);
        }
    }

    function cmb_validate_text_date($null, $value, $id, $args, $self){
        if($value){
            $value = sanitize_text_field($value);
            if($value) return strtotime($value);
        }

        return '';
    }

    function custom_save_post($post_id){
        if(get_post_type($post_id) == 'tour'){
            if(isset($_POST['intravel_tour_service'])){
                wp_set_post_terms( $post_id, $_POST['intravel_tour_service'], 'tour_service');
            }

            if(!get_post_meta( $post_id, 'intravel_total_sales', true )){
                update_post_meta( $post_id, 'intravel_adult_sales', 0);
                update_post_meta( $post_id, 'intravel_children_sales', 0);
                update_post_meta( $post_id, 'intravel_total_sales', 0);
            }

            if(!get_post_meta( $post_id, 'intravel_start_date', true )){
                update_post_meta( $post_id, 'intravel_start_date', date('m/d/Y'));
            }
            if(!get_post_meta( $post_id, 'intravel_end_date', true )){
                update_post_meta( $post_id, 'intravel_end_date', '');
            }
            
            $regular_price = it_format_decimal(get_post_meta($post_id, 'intravel_regular_price', true));
            update_post_meta( $post_id, 'intravel_regular_price', $regular_price );

            $children_regular_price = it_format_decimal(get_post_meta($post_id, 'intravel_children_regular_price', true));
            update_post_meta( $post_id, 'intravel_children_regular_price', $children_regular_price );

            $discount = get_post_meta($post_id, 'intravel_discount', true);
            $discount = (int)$discount > 100 ? 100 : (int)$discount;
            $discount = (int)$discount < 0 ? '' : (int)$discount;
            update_post_meta( $post_id, 'intravel_discount', $discount);
            $date_from  = get_post_meta($post_id, 'intravel_discount_from', true);
            $date_to    = get_post_meta($post_id, 'intravel_discount_to', true);
            if($discount){
                if($date_to && !$date_from){
                    update_post_meta( $post_id, 'intravel_discount_to', strtotime( $date_to ) );
                    update_post_meta( $post_id, 'intravel_discount_from', strtotime( 'NOW', current_time( 'timestamp' ) ) );
                }
                elseif ( $date_to && $date_from ) {
                    update_post_meta( $post_id, 'intravel_discount_from', strtotime( $date_from ));
                    update_post_meta( $post_id, 'intravel_discount_to', strtotime( $date_to ));
                }else{
                    update_post_meta( $post_id, 'intravel_discount_from', '');
                    update_post_meta( $post_id, 'intravel_discount_to', '');
                }
            }
            else
            {
                update_post_meta( $post_id, 'intravel_discount_from', '' );
                update_post_meta( $post_id, 'intravel_discount_to', '' );
                update_post_meta( $post_id, 'intravel_discount', '' );
            }

            $sale_price = $children_sale_price = '';
            if($discount){
                $sale_price = $regular_price - ($regular_price * (int)$discount /100);
                $children_sale_price = $children_regular_price - ($children_regular_price * (int)$discount /100);
            }

            if ( $discount && '' === $date_to && '' === $date_from ) {
                update_post_meta( $post_id, 'intravel_price', $sale_price );
                update_post_meta( $post_id, 'intravel_children_price', $children_sale_price );
            } else {
                update_post_meta( $post_id, 'intravel_price', $regular_price );
                update_post_meta( $post_id, 'intravel_children_price', $children_regular_price );
            }

            if ( $discount && $date_from && strtotime( $date_from ) < strtotime( 'NOW', current_time( 'timestamp' ) ) ) {
                update_post_meta( $post_id, 'intravel_price', $sale_price );
                update_post_meta( $post_id, 'intravel_children_price', $children_regular_price );
            }

            if ( $date_to && strtotime( $date_to ) < strtotime( 'NOW', current_time( 'timestamp' ) ) ) {
                update_post_meta( $post_id, 'intravel_price', $regular_price );
                update_post_meta( $post_id, 'intravel_children_price', $children_regular_price );
                update_post_meta( $post_id, 'intravel_discount', '');
                update_post_meta( $post_id, 'intravel_discount_from', '' );
                update_post_meta( $post_id, 'intravel_discount_to', '' );
            }
        }
    }
    
    function cmb2_validate_file_list($null, $value, $field, $args, $self){
        if($value){
            return json_encode((array)$value);
        }
        else{
            return '';
        }
    }
    function cmb2_types_esc_file_list($null, $value, $args, $self){
        if($value){
            return json_decode($value, true);
        }
        else{
            return array();
        }
    }
}

new IT_Tour_Post_Type();
?>