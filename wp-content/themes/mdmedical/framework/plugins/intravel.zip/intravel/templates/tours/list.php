<div class="tour-listing-row">
    <?php
    if (have_posts()) : while (have_posts()) : the_post();
        global $inwave_theme_option;
        $tour = it_get_tour();
        $duration = $tour->get_duration();
        $price = $tour->get_price();
        $rating_html = $tour->get_rating_html();
        $destinations = $tour->get_destinations();
        $destination_tour = get_the_excerpt();
        $large_image_url = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');
        $img_url = $large_image_url ? $large_image_url[0] : '';
        $img_url = inwave_resize($img_url, 600, 560, true);
        ?>
        <div class="tour-item">
            <div class="image-wrap">
                <div class="img" style="background: url('<?php echo esc_url($img_url); ?>') no-repeat center center / cover "></div>
                <div class="booking-action">
                    <a class="link-to-detail theme-bg" href="<?php echo get_permalink(); ?>">
                        <?php echo esc_html__('Book now', 'intravel'); ?>
                    </a>
                </div>
            </div>
            <div class="tour-info-wrap">
                <div class="info-top">
                    <h3 class="title"><a class="theme-color" href="<?php echo get_permalink(); ?>"><?php echo the_title(); ?></a></h3>
                    <div class="post-meta">
                        <ul>
                            <li>
                                <div class="iwt-rating">
                                    <?php echo $rating_html; ?>
                                </div>
                            </li>
                            <?php if ($destinations) :
                                ?>
                                <li class="destinations">
                                    <i class="fa fa-map-marker"> </i>
                                    <?php
                                    $destination_html = array();
                                    foreach($destinations as $destination){
                                        $destination_html[] = '<a href="'.esc_url(get_term_link($destination->slug, 'destination')).'" class="destination">'.$destination->name.'</a>';
                                    }
                                    echo implode(' / ', $destination_html);
                                    ?>
                                </li>
                            <?php endif; ?>
                            <?php if ($duration) : ?>
                                <li>
                                    <span class="duration"><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo $duration; ?></span>
                                </li>
                            <?php endif ?>
                        </ul>
                    </div>
                    <div class="description"><?php echo wp_trim_words($destination_tour, 20); ?></div>
                </div>
                <div class="tour-price-vote">
                    <?php if ($price) : ?>
                        <div class="price-tour theme-color"><?php echo it_price($price); ?></div>
                    <?php endif; ?>
                    <div class="tour-social">
                        <ul class="socials">
                            <?php if (!empty($inwave_theme_option['social_links'])) {
                                $social_links = $inwave_theme_option['social_links'];
                                unset($social_links[0]);
                                foreach ($social_links as $social_link) {
                                    echo '<li><a href="' . esc_url($social_link['link']) . '">
                                    <i class="fa ' . esc_attr($social_link['icon']) . '"></i>
                                    </a></li>';
                                }
                            }?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
        <?php
    endwhile;
    endif;
    ?>
</div>