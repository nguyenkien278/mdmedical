<?php
/**
 * Intravel Uninstall
 *
 * Uninstalling Intravel deletes user roles, pages, tables, and options.
 *
 * @author      InwaveThemes
 * @category    Core
 * @package     Intravel/Uninstaller
 * @version     1.0.0
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

wp_clear_scheduled_hook( 'intravel_scheduled_sales' );
wp_clear_scheduled_hook( 'intravel_cancel_unpaid_orders' );
wp_clear_scheduled_hook( 'intravel_paypal_cancel_unpaid_orders' );

// Roles + caps.
include_once( 'includes/install.class.php' );
IT_Install::remove_roles();

// Pages.
wp_trash_post( it_get_option('tours_page_id' ) );
wp_trash_post( it_get_option('checkout_page_id' ) );
wp_trash_post( it_get_option('checkorder_page_id' ) );

// Tables.
//$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}" );

// Delete options.
$wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE 'intravel\_%';");

// Delete posts + data.
$wpdb->query( "DELETE FROM {$wpdb->posts} WHERE post_type IN ( 'tour' );" );
$wpdb->query( "DELETE meta FROM {$wpdb->postmeta} meta LEFT JOIN {$wpdb->posts} posts ON posts.ID = meta.post_id WHERE posts.ID IS NULL;" );
