<?php

/*
 * Inwave_Item_Info for Visual Composer
 */
if (!class_exists('Inwave_Item_Info')) {

    class Inwave_Item_Info extends Inwave_Shortcode{

        protected $name = 'inwave_item_info';

        function init_params() {
            return array(
                'name' => __("Item Info", 'inwavethemes'),
                'description' => __('Add a item info', 'inwavethemes'),
                'base' => $this->name,
                'category' => 'Custom',
                'icon' => 'iw-default',
                'params' => array(
                    array(
                        "type" => "dropdown",
                        "admin_label" => true,
                        "heading" => "Style",
                        "param_name" => "style",
                        "value" => array(
                            "Default" => "default",
							"Style 2" => "style2",
							"Style 3" => "style3",
                        )
                    ),
					array(
                        "type" => "iwevent_preview_image",
                        "heading" => __("Preview Style", "inwavethemes"),
                        "param_name" => "preview_default",
                        "value" => get_template_directory_uri() . '/assets/images/shortcodes/info-item-1.jpg',
                        "dependency" => array('element' => 'style', 'value' => 'default')
                    ),
					array(
                        "type" => "iwevent_preview_image",
                        "heading" => __("Preview Style", "inwavethemes"),
                        "param_name" => "preview_style2",
                        "value" => get_template_directory_uri() . '/assets/images/shortcodes/info-item-2.jpg',
                        "dependency" => array('element' => 'style', 'value' => 'style2')
                    ),
					array(
                        "type" => "iwevent_preview_image",
                        "heading" => __("Preview Style", "inwavethemes"),
                        "param_name" => "preview_style3",
                        "value" => get_template_directory_uri() . '/assets/images/shortcodes/info-item-3.jpg',
                        "dependency" => array('element' => 'style', 'value' => 'style3')
                    ),
                    array(
                        'type' => 'textfield',
                        "admin_label" => true,
                        "heading" => __("Title", "inwavethemes"),
                        "value" => "",
                        "param_name" => "title",
                    ),
                    array(
                        'type' => 'textfield',
                        "admin_label" => true,
                        "heading" => __("Sub Title", "inwavethemes"),
                        "value" => "",
                        "param_name" => "sub_title",
                        "dependency" => array(
                            'element' => 'style',
                            'value' => array('style3')
                        )
                    ),
                    array(
                        'type' => 'textfield',
                        "heading" => __("Link", "inwavethemes"),
                        "value" => "#",
                        "param_name" => "link",
                    ),
                    array(
                        'type' => 'iw_icon',
                        "heading" => __("Icon", "inwavethemes"),
                        "value" => "",
                        "param_name" => "icon",
                    ),
					array(
                        "type" => "textfield",
                        "heading" => __("Icon Size", "inwavethemes"),
                        "param_name" => "icon_size",
                        "description" => __("Example: 30", "inwavethemes"),
                        "value" => "30",
                        "dependency" => array(
                            'element' => 'style',
                            'value' => array('style2', 'style3')
                        )
                    ),
                    array(
                        'type' => 'textarea',
                        "heading" => __("Description", "inwavethemes"),
                        "value" => "",
                        "param_name" => "description",
                    ),
					array(
                        "type" => "dropdown",
                        "group" => "Style",
                        "heading" => __("Text align", "inwavethemes"),
                        "param_name" => "align",
                        "value" => array(
                            "Default" => "",
                            "Left" => "left",
                            "Right" => "right",
                            "Center" => "center"
                        )
                    ),
					array(
                        'type' => 'css_editor',
                        'heading' => __( 'CSS box', 'js_composer' ),
                        'param_name' => 'css',
                        'group' => __( 'Design Options', 'js_composer' )
                    )
                )
            );
        }

        // Shortcode handler function for list Icon
        function init_shortcode($atts, $content = null) {
            $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( $this->name, $atts ) : $atts;

            $output = $class = '';
            extract(shortcode_atts(array(
                'style' => '',
                'title' => '',
                'sub_title' => '',
                'link' => '',
                'icon' => '',
				'icon_size' => '',
				'align' => '',
                'description' => '',
                'css' => '',
				'class' => '',
            ), $atts));

            $class .= ' '.$style.' '. vc_shortcode_custom_css_class( $css);
            if($align){
                $class.= ' '.$align.'-text';
            }

            switch ($style) {
                // Normal style
                case 'default':
					$output .= '<div class="iw-item-info ' . $class . '">';
					$output .= '<i class="'.esc_attr($icon).' theme-bg"></i>';
					$output .= '<h3 class="title"><a href="'.esc_url($link).'" >'.$title.'</a></h3>';
					$output .= '<p class="description">'.$description.'</p>';
					$output .= '<p class="dot"><span></span><span></span><span></span></p>';
					$output .= '</div>';
                break;
				case 'style2':
					$output .= '<div class="iw-item-info ' . $class . '">';
					if ($icon){
						$output .= '<div class="icon theme-bg" style="font-size:' . $icon_size . 'px"><i class="'.esc_attr($icon).'"></i></div>';
					}
					$output .= '<div class="item-info-content">';
					if ($title){
						if ($link){
							$output .= '<h3 class="title"><a href="'.esc_url($link).'" >'.$title.'</a></h3>';
						} else {
							$output .= '<h3 class="title">'.$title.'</h3>';
						}
					}
					if ($description){
						$output .= '<p class="description">'.$description.'</p>';
					}
					$output .= '</div>';
					$output .= '</div>';
				break;
                case 'style3':
                    $output .= '<div class="iw-item-info ' . $class . ' theme-bg-hover">';
                    if ($icon){
                        $output .= '<div class="icon theme-color" style="font-size:' . $icon_size . 'px"><i class="'.esc_attr($icon).'"></i></div>';
                    }
                    if ($title){
                        $output .= '<h3 class="title"><a href="'.esc_url($link).'" >'.$title.'</a></h3>';
                    }
                    if ($sub_title){
                        $output .= '<div class="sub-title">'.$sub_title.'</div>';
                    }
                    if ($description){
                        $output .= '<p class="description">'.$description.'</p>';
                    }
                    $output .= '<p class="dot"><span></span><span></span><span></span></p>';
                    $output .= '</div>';
                    break;
            }
            return $output;
        }
    }
}

new Inwave_Item_Info;
