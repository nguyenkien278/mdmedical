<?php
/*
Plugin Name: CMB2 Metatabs Options
Plugin URI:  https://github.com/rogerlos/cmb2-metatabs-options
Description: Add admin option pages with multiple metaboxes--and place those metaboxes into optional tabs. Requires CMB2.
Version:     1.0.1
Author:      Roger Los
Author URI:  https://github.com/rogerlos
Text Domain: cmb2
License:     GPLv2 or later
 */

if ( ! defined( 'WPINC' ) ) die;

if(!function_exists('cmb2_render_gallery')){
    function cmb2_render_gallery($field, $escaped_value, $object_id, $object_type, $field_type_object ){
        // include our gallery scripts only when we need them
        wp_enqueue_media();
        wp_enqueue_style( 'pixgallery' , INTRAVEL_PLUGIN_URL .'/libs/cmb2-gallery/css/style.css');
        wp_enqueue_script( 'pixgallery' , INTRAVEL_PLUGIN_URL .'/libs/cmb2-gallery/js/pixgallery.js');
        // ensure the wordpress modal scripts even if an editor is not present
        wp_enqueue_script( 'jquery-ui-dialog', false, array('jquery'), false, true );
        wp_localize_script( 'pixgallery', 'locals', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'pixtypes_l18n' => array(
                'confirmClearGallery' => __( 'You want for sure to clear this gallery?', 'pixtypes' ),
                'alertGalleryIsEmpty' => __( 'Gallery is already empty!', 'pixtypes' )
            )
        ) );

        $ids = array();
        $escaped_value = rtrim( $escaped_value, ',' );
        if($escaped_value){
            $ids = explode( ',', $escaped_value );
        }

        $size = 'thumbnail';
        if ( count( $ids ) === 1 ) {
            $size = 'medium';
        }
        $html = '<div id="'.$field->args['id'].'" class="pixgallery_field '.(count($ids) > 1 ? 'has-items' : 'no-items').'" >';
        $html .= '<ul>';
        foreach ( $ids as $id ) {
            $attach = wp_get_attachment_image_src( $id, $size, false );
            $html .= '<li><img src="' . $attach[0] . '" /></li>';
        }
        $html .= '</ul>';
        $html .= '<a class="open_pixgallery" href="#" >';
        $html .= '<input type="hidden" name="'.$field->args['id'].'" id="pixgalleries" value="" />
                <div><i class="icon dashicons dashicons-images-alt2"></i> <span>'.__('Add Image', 'pixtypes' ).'</span></div>
                <span class="clear_gallery">'.__('Clear', 'pixtypes' ).'</span>
            </a>
        </div>';

        echo $html;
    }

    add_action( 'cmb2_render_gallery', 'cmb2_render_gallery', 10, 5 );
}
