<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


/**
 * Customer
 *
 * The InTravel customer class handles storage of the current customer's data, such as destination.
**/

class IT_Customer {

	/**
	 * Stores customer data.
	 *
	 * @var array
	 */
	protected $_data = array();

	/**
	 * Constructor for the customer class loads the customer data.
	 *
	 */
	public function __construct() {
		
		//unset($_SESSION['intravel_customer']);
		// No data - set defaults
		if ( !isset($_SESSION['intravel_customer']) || empty($_SESSION['intravel_customer']) ) {
            $_SESSION['intravel_customer'] = $this->get_data();
		}

        $this->_data = isset($_SESSION['intravel_customer']) ? $_SESSION['intravel_customer'] : array();

		// When leaving or ending page load, store data
		add_action( 'shutdown', array( $this, 'save_data' ), 10 );
	}

	/**
	 * Save data function.
	 */
	public function save_data() {
			$_SESSION['intravel_customer'] = $this->_data;
	}

	/**
	 * __set function.
	 *
	 * @param mixed $property
	 * @return bool
	 */
	public function __isset( $property ) {
		if ( 'address' === $property ) {
			$property = 'address_1';
		}
		if ( 'shipping_address' === $property ) {
			$property = 'shipping_address_1';
		}
		return isset( $this->_data[ $property ] );
	}

	/**
	 * __get function.
	 *
	 * @param string $property
	 * @return string
	 */
	public function __get( $property ) {
		return isset( $this->_data[ $property ] ) ? $this->_data[ $property ] : '';
	}

	/**
	 * __set function.
	 *
	 * @param mixed $property
	 * @param mixed $value
	 */
	public function __set( $property, $value ) {
		$this->_data[ $property ] = $value;
	}

	public function get_name(){
		$name = array();
		$name[] = $this->first_name;
		$name[] = $this->last_name;

		$name = array_filter($name);
		if($name){
			return implode(' ', $name);
		}
		else{
			return '';
		}
	}

	/**
	 * Get the customer for the given ID
	 *
	 * @param int $id the customer ID
	 * @return object
	 */
	public function get_data( $id = null ) {
		global $wpdb;

		if(!$id){
			$id = get_current_user_id();
		}

		if($id){
            $customer = new WP_User( $id );
            // Get info about user's last order
            $last_booking = $wpdb->get_var( "SELECT id
						FROM $wpdb->posts AS posts
						LEFT JOIN {$wpdb->postmeta} AS meta on posts.ID = meta.post_id
						WHERE meta.meta_key = 'intravel_user'
						AND   meta.meta_value = {$customer->ID}
						AND   posts.post_type = 'tour_booking'
						AND   posts.post_status IN ( '" . implode( "','", array('publish', 'trash') )  . "' )
						ORDER BY posts.ID DESC
					" );

            $customer_data = array(
                'id'               => $customer->ID,
                'email'            => get_post_meta($last_booking, 'intravel_email', true) ? get_post_meta($last_booking, 'intravel_email', true) : $customer->user_email,
                'first_name'       => get_post_meta($last_booking, 'intravel_first_name', true) ? get_post_meta($last_booking, 'intravel_first_name', true) : $customer->first_name,
                'last_name'        => get_post_meta($last_booking, 'intravel_last_name', true) ? get_post_meta($last_booking, 'intravel_last_name', true) : $customer->last_name,
                'phone'            => get_post_meta($last_booking, 'intravel_phone', true) ? get_post_meta($last_booking, 'intravel_phone', true) : '',
                //'address'          => get_post_meta($last_booking, 'intravel_address', true) ? get_post_meta($last_booking, 'intravel_address', true) : '',
            );
        }
        else{
            $customer = null;
            $customer_data = array(
                'id'               => 0,
                'email'            => '',
                'first_name'       => '',
                'last_name'        => '',
                'phone'            => '',
                //'address'          => '',
            );
        }

		return apply_filters( 'intravel_get_customer', $customer_data, $customer);
	}

	/**
	 * Update the customer data
	 *
	 * @param array
	 */
	public function update_data($data){

		if(isset($data['first_name'])){
			$this->first_name = $data['first_name'];
		}
		if(isset($data['last_name'])){
			$this->last_name = $data['last_name'];
		}
		if(isset($data['phone']) && $data['phone']){
			$this->phone = $data['phone'];
		}
		if(isset($data['email']) && $data['email']){
			$this->email = $data['email'];
		}
		/*if(isset($data['address']) && $data['address']){
			$this->address = $data['address'];
		}*/

		$this->save_data();
	}
}
