<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
class IT_Service_Post_Type{
    function __construct()
    {
        add_action('init', array($this, 'register'));
        add_action('cmb2_admin_init', array($this, 'custom_taxonomy_metabox'));
    }

    function register(){
        $labels = array(
            'name'              => _x( 'Services', 'intravel' ),
            'singular_name'     => _x( 'Service', 'intravel' ),
            'search_items'      => __( 'Search Services' ),
            'all_items'         => __( 'All Services' ),
            'parent_item'       => __( 'Parent Service' ),
            'parent_item_colon' => __( 'Parent Service:' ),
            'edit_item'         => __( 'Edit Service' ),
            'update_item'       => __( 'Update Service' ),
            'add_new_item'      => __( 'Add New Service' ),
            'new_item_name'     => __( 'New Service Name' ),
            'menu_name'         => __( 'Services' ),
        );

        $args = array(
            'hierarchical'      => true,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_in_menu'      => true,
            'show_admin_column' => true,
            //'query_var'         => true,
            //'rewrite'           => array( 'slug' => it_get_option('service_slug', 'service' )),
        );

        register_taxonomy( 'tour_service', array( 'tour' ), $args );
    }

    function custom_menu_item_redirect() {

        $menu_redirect = isset($_GET['page']) ? $_GET['page'] : false;

        if($menu_redirect == 'tour_service' ) {
            wp_safe_redirect( admin_url( 'edit-tags.php?taxonomy=tour_service' ));
            exit();
        }
    }

    function custom_taxonomy_metabox(){
        $prefix = 'intravel_';

        $cmb_term = new_cmb2_box( array(
            'id'               => $prefix . 'service_metabox',
            'title'            => __('Service Metabox', 'intravel'),
            'object_types'     => array( 'term' ),
            'taxonomies'       => array( 'tour_service'),
            //'new_term_section' => true,
        ) );
        $cmb_term->add_field( array(
            'name'      => __('Adult Price', 'intravel'),
            'desc'      => __('Adult price of service', 'intravel'),
            'id'        => $prefix . 'price',
            'type'      => 'text',
        ) );
        $cmb_term->add_field( array(
            'name'      => __('Children price', 'intravel'),
            'desc'      => __('Children price of service', 'intravel'),
            'id'        => $prefix . 'children_price',
            'type'      => 'text',
        ) );
        $cmb_term->add_field( array(
            'name'      => __('Children select type', 'intravel'),
            'desc'      => __('Children select type', 'intravel'),
            'id'        => $prefix . 'select_type',
            'type'      => 'select',
            'options'   => array(
                'select' => 'Select dropdown',
                'checkbox' => 'Check box'
            )
        ) );
        $cmb_term->add_field( array(
            'name'      => __('Show in detail page', 'intravel'),
            'id'        => $prefix . 'show_in_detail',
            'type'      => 'select',
            'default' => '1',
            'options'   => array(
                '1' => 'Yes',
                '0' => 'No'
            )
        ) );
    }

}

new IT_Service_Post_Type();
?>