<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/*
Plugin Name: InTravel
Plugin URI: http://inwavethemes.com/intravel
Description: InTravel plugin for tours.
Version: 1.2.4
Author: inwavethemes
Author URI: http://inwavethemes.com
License: GPLv2 or later
Text Domain: intravel
*/

class inTravel{

    /**
     * inTravel version.
     *
     * @var string
     */
    public $version = '1.2.4';

    /**
     * The single instance of the class.
     *
     */
    protected static $_instance = null;

    /**
     * Main inTravel Instance.
     *
     * Ensures only one instance of InTravel is loaded or can be loaded.
     *
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * Intravel Constructor.
     */
    public function __construct() {
        $this->define_constants();
        $this->includes();
        $this->init_hooks();

        do_action( 'intravel_loaded' );
    }

    /**
     * Define WC Constants.
     */
    private function define_constants() {
        define( 'INTRAVEL_VERSION', $this->version );
        define( 'INTRAVEL_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
        define( 'INTRAVEL_PLUGIN_URL', plugins_url().'/intravel' );
    }

    public function includes() {
        if(!class_exists('URLify')) {
            include_once INTRAVEL_PLUGIN_DIR . '/libs/URLify.php';
        }
        
        include_once INTRAVEL_PLUGIN_DIR.'/includes/core.functions.php';
        include_once INTRAVEL_PLUGIN_DIR.'/includes/additional-functions.php';

        require_once( INTRAVEL_PLUGIN_DIR. '/libs/cmb2/init.php' );
        if(!class_exists('Cmb2_Metatabs_Options')){
            require_once( INTRAVEL_PLUGIN_DIR. '/libs/cmb2-metatabs-options/cmb2_metatabs_options.php' );
        }

        //require_once( INTRAVEL_PLUGIN_DIR. '/libs/cmb2-gallery/cmb2_gallery.php' );
        require_once( INTRAVEL_PLUGIN_DIR. '/libs/cmb2-group-tabs/cmb2_group_tabs.php' );
        require_once( INTRAVEL_PLUGIN_DIR. '/libs/cmb2-iwmap/cmb2_iwmap.php' );
        require_once( INTRAVEL_PLUGIN_DIR. '/libs/intravel-schedule/intravel-schedule.php' );
        require_once( INTRAVEL_PLUGIN_DIR. '/libs/cmb2-iwperiod/cmb2_iwperiod.php' );
        require_once( INTRAVEL_PLUGIN_DIR. '/libs/cmb2-user-search/cmb2_user_search_field.php' );
        require_once( INTRAVEL_PLUGIN_DIR. '/libs/cmb2-post-search-field/cmb2_post_search_field.php' );

        //include_once INTRAVEL_PLUGIN_DIR.'/includes/post_types/facility.php';
        include_once INTRAVEL_PLUGIN_DIR.'/includes/post_types/destination.php';
        include_once INTRAVEL_PLUGIN_DIR.'/includes/post_types/service.php';
        include_once INTRAVEL_PLUGIN_DIR.'/includes/post_types/tour.php';
        include_once INTRAVEL_PLUGIN_DIR.'/includes/post_types/tour-booking.php';

        include_once INTRAVEL_PLUGIN_DIR.'/includes/install.class.php';
        include_once INTRAVEL_PLUGIN_DIR.'/includes/process.class.php';
        $this->query = include_once INTRAVEL_PLUGIN_DIR.'/includes/query.class.php';
        include_once INTRAVEL_PLUGIN_DIR.'/includes/customer.class.php';
        include_once INTRAVEL_PLUGIN_DIR.'/includes/tour.class.php';
        include_once INTRAVEL_PLUGIN_DIR.'/includes/booking.class.php';
        include_once INTRAVEL_PLUGIN_DIR.'/includes/comment.class.php';
        include_once INTRAVEL_PLUGIN_DIR.'/includes/woocommerce.class.php';
        include_once INTRAVEL_PLUGIN_DIR.'/includes/settings.class.php';
        include_once INTRAVEL_PLUGIN_DIR.'/includes/email.class.php';
        include_once INTRAVEL_PLUGIN_DIR.'/includes/destination.class.php';
        include_once INTRAVEL_PLUGIN_DIR.'/includes/template-loader.class.php';

        include_once INTRAVEL_PLUGIN_DIR.'/includes/widgets/destinations.php';
        include_once INTRAVEL_PLUGIN_DIR.'/includes/widgets/rating-filter.php';
        include_once INTRAVEL_PLUGIN_DIR.'/includes/widgets/reviews.php';
        include_once INTRAVEL_PLUGIN_DIR.'/includes/widgets/search-form.php';
        include_once INTRAVEL_PLUGIN_DIR.'/includes/widgets/tour-tags.php';
        include_once INTRAVEL_PLUGIN_DIR.'/includes/widgets/tour-types.php';
        include_once INTRAVEL_PLUGIN_DIR.'/includes/widgets/tours.php';
        include_once INTRAVEL_PLUGIN_DIR.'/includes/widgets/tours_interested.php';
        include_once INTRAVEL_PLUGIN_DIR.'/includes/widgets/form-booking-tour.php';

    }

    /**
     * Hook into actions and filters.
     */
    private function init_hooks() {

        register_activation_hook( __FILE__, array( 'IT_Install', 'install' ) );
        //register_deactivation_hook( __FILE__, array('IT_Install', 'uninstall') );

        add_action( 'after_setup_theme', array( $this, 'setup_environment' ) );
        add_action( 'init', array( $this, 'init' ), 0 );
        //add_action( 'init', array( 'IT_Shortcodes', 'init' ) );

        if(is_admin()){
            //add_action( 'init', array($this, 'load_cmb_meta_boxes'), 10 );
        }

        add_action('admin_enqueue_scripts',  array($this, 'admin_enqueue_scripts'));
        add_action('wp_enqueue_scripts',  array($this, 'enqueue_scripts'));
        add_action('wp_logout', array($this, 'end_session'));
        add_action('wp_login', array($this, 'end_session'));

        if(!is_admin()){
            add_filter( 'body_class', 'it_body_class' );
            add_filter( 'post_class', 'it_tour_post_class', 20, 3 );
        }
    }

    /**
     * Ensure theme and server variable compatibility and setup image sizes.
     */
    public function setup_environment() {
        /**
         * @deprecated 2.2 Use WC()->template_path()
         */
        define( 'WC_TEMPLATE_PATH', $this->template_path() );

        $this->add_thumbnail_support();
        $this->add_image_sizes();
    }

    /**
     * Ensure post thumbnail support is turned on.
     */
    private function add_thumbnail_support() {
        if ( ! current_theme_supports( 'post-thumbnails' ) ) {
            add_theme_support( 'post-thumbnails' );
        }
        add_post_type_support( 'tour', 'thumbnail' );
    }

    /**
     * Add WC Image sizes to WP.
     *
     * @since 2.3
     */
    private function add_image_sizes() {
        $tour_thumbnail = it_get_image_size( 'tour_thumbnail' );
        $tour_catalog	= it_get_image_size( 'tour_catalog' );
        $tour_single	= it_get_image_size( 'tour_single' );

        add_image_size( 'tour_thumbnail', $tour_thumbnail['width'], $tour_thumbnail['height'], $tour_thumbnail['crop'] );
        add_image_size( 'tour_catalog', $tour_catalog['width'], $tour_catalog['height'], $tour_catalog['crop'] );
        add_image_size( 'tour_single', $tour_single['width'], $tour_single['height'], $tour_single['crop'] );
    }

    /**
     * Load Localisation files.
     *
     */
    public function load_plugin_textdomain() {
        $locale = apply_filters( 'plugin_locale', get_locale(), 'intravel' );

        load_textdomain( 'intravel', WP_LANG_DIR . '/intravel/intravel-' . $locale . '.mo' );
        load_plugin_textdomain( 'intravel', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );
    }

    /**
     * Init InTravel when WordPress Initialises.
     */
    public function init() {
        // Before init action.
        do_action( 'before_intravel_init' );

        // Set up localisation.
        $this->load_plugin_textdomain();
        $this->start_session();

        // Init action.
        do_action( 'intravel_init' );
    }


    function intravel_activate() {
    }

    function intravel_deactivate() {
    }

    function start_session() {
        if(!session_id()) {
            session_start();
        }
    }

    function end_session() {
        $this->empty_cart();
    }

    function enqueue_scripts(){
        wp_enqueue_style('plg-intravel-style', plugins_url('/intravel/assets/css/intravel_style.css'), INTRAVEL_VERSION, true);
        wp_enqueue_script('plg-intravel', plugins_url() . '/intravel/assets/js/intravel.js', array('jquery', 'jquery-ui-core', 'jquery-ui-datepicker'), INTRAVEL_VERSION, true);
        wp_localize_script('plg-intravel', 'PlgIntravelCfg', array(
            'siteUrl' => admin_url(),
            'baseUrl' => site_url(),
            'ajaxUrl' => admin_url('admin-ajax.php'),
        ));
        if(is_single() && get_post_type() == 'tour'){
            $tour = it_get_tour();
            global $inwave_theme_option;
            $google_map_api = it_get_option('google_api') ? it_get_option('google_api') : (isset($inwave_theme_option['google_api']) ? $inwave_theme_option['google_api'] : '');
            wp_enqueue_script('google-maps', 'https://maps.googleapis.com/maps/api/js?key='.$google_map_api.'&libraries=places', array('jquery'), INTRAVEL_VERSION);
            wp_localize_script('plg-intravel', 'PlgIntravelTourMapCfg', array(
                'markers' => $tour->get_schedules(),
                'marker_url' => it_get_marker_url(),
                'lat' => it_get_option('map_lat', -33.8688),
                'lng' => it_get_option('map_lng', 151.2195),
                'zoom' => it_get_option('map_zoom', 15),
                'polyline_color' => it_get_option('map_polyline_color', '#FF0000'),
                'polyline_stroke_opacity' => it_get_option('map_polyline_stroke_opacity', 0.5),
                'polyline_stroke_weight' => it_get_option('map_polyline_stroke_weight', 4),
            ));
        }

		if (!is_post_type_archive( 'tour' ) && is_tax('destination')){
			$term   = get_queried_object();
			$destination = it_get_detination($term);
			$map_data = $destination->get_map();
			global $inwave_theme_option;
			$google_map_api = it_get_option('google_api') ? it_get_option('google_api') : (isset($inwave_theme_option['google_api']) ? $inwave_theme_option['google_api'] : '');
            wp_enqueue_script('google-maps', 'https://maps.googleapis.com/maps/api/js?key='.$google_map_api.'&libraries=places', array('jquery'));
			wp_localize_script('plg-intravel', 'PlgIntravelDestinationMapCfg', array(
                'lat' => it_get_option('map_lat', -33.8688),
                'lng' => it_get_option('map_lng', 151.2195),
                'zoom' => it_get_option('map_zoom', 15),
                'marker' => array(
                    'lat' => $map_data->lat,
                    'lng' => $map_data->lng,
                    'zoom' => $map_data->zoom,
                )
            ));
		}
		
        wp_enqueue_script('plg-intravel-comment', plugins_url() . '/intravel/assets/js/comment.js', array('jquery', 'comment-reply'), INTRAVEL_VERSION, true);

        wp_enqueue_script( 'it-jquery-ui-touchpunch', INTRAVEL_PLUGIN_URL . '/assets/js/jquery-ui-touch-punch.min.js', array( 'jquery-ui-slider' ), INTRAVEL_VERSION, false );
        wp_enqueue_script( 'it-price-slider', INTRAVEL_PLUGIN_URL . '/assets/js/price-slider.js', array( 'jquery-ui-slider', 'wc-jquery-ui-touchpunch' ), INTRAVEL_VERSION, false );
        wp_localize_script( 'it-price-slider', 'intravel_price_slider_params', array(
            'currency_symbol' 	=> it_get_currency_symbol(),
            'currency_pos'      => it_get_option( 'currency_pos' , 'left'),
            'min_price'			=> isset( $_GET['min_price'] ) ? esc_attr( $_GET['min_price'] ) : '',
            'max_price'			=> isset( $_GET['max_price'] ) ? esc_attr( $_GET['max_price'] ) : ''
        ) );

    }

    function admin_enqueue_scripts(){
        wp_enqueue_style('plg-intravel-admin-style', plugins_url('/intravel/assets/css/admin.css'), INTRAVEL_VERSION, true);
        wp_enqueue_script('plg-intravel-admin', plugins_url() . '/intravel/assets/js/admin.js', array('jquery', 'jquery-ui-core', 'jquery-ui-datepicker'), INTRAVEL_VERSION, true);
        wp_localize_script('plg-intravel-admin', 'PlgIntravelCfg', array(
            'siteUrl' => admin_url(),
            'baseUrl' => site_url(),
            'ajaxUrl' => admin_url('admin-ajax.php'),
        ));
    }

    /**
     * Initialize the metabox class.
     */
    function load_cmb_meta_boxes() {
        if ( ! class_exists( 'cmb_Meta_Box' ) )
            require_once INTRAVEL_PLUGIN_DIR.'/libs/metaboxes/init.php';
    }

    /**
     * Get the template path.
     * @return string
     */
    public function template_path() {
        return apply_filters( 'intravel_template_path', 'intravel/' );
    }


    /**
     * Get the plugin path.
     * @return string
     */
    public function plugin_path() {
        return untrailingslashit( INTRAVEL_PLUGIN_DIR );
    }

    public function set_cart($data){
        $data['tour'] = isset($data['tour']) ? (int)$data['tour'] : '';
        $data['start_date'] = isset($data['start_date']) ? $data['start_date'] : '';
        $data['adult_ticket'] = isset($data['adult_ticket']) ? (int)$data['adult_ticket'] : '';
        $data['children_ticket'] = isset($data['children_ticket']) ? (int)$data['children_ticket'] : '';
        $tour = it_get_tour($_POST['tour']);
        if($tour && $data['start_date'] && ($data['adult_ticket'] || $data['children_ticket'])){
            if($tour->get_price_status($data['start_date'], $data['adult_ticket'], $data['children_ticket'], true)){
                $_SESSION['intravel_cart'] = $data;
            }
        }
    }

    public function get_cart(){
        return isset($_SESSION['intravel_cart']) ? $_SESSION['intravel_cart'] : false;
    }

    public function empty_cart(){
        unset($_SESSION['intravel_cart']);
    }
}

if(!function_exists('IT')){
    function IT(){
        return inTravel::instance();
    }
}

// Global for backwards compatibility.
$GLOBALS['intravel'] = IT();
?>