<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
class IT_Booking {

	/**
	 * The booking (post) ID.
	 *
	 * @var int
	 */
	public $id = 0;

	/**
	 * $post Stores post data.
	 *
	 * @var $post WP_Post
	 */
	public $post = null;
	
	/**
	 * Constructor gets the post object and sets the ID for the loaded booking.
	 *
	 * @param int|IT_Tour|object $booking ID, post object, or booking object
	 */
	public function __construct( $booking ) {
		if ( is_numeric( $booking ) ) {
			$this->id   = absint( $booking );
			$this->post = get_post( $this->id );
		} elseif ( $booking instanceof IT_Tour ) {
			$this->id   = absint( $booking->id );
			$this->post = $booking->post;
		} elseif ( isset( $booking->ID ) ) {
			$this->id   = absint( $booking->ID );
			$this->post = $booking;
		}
	}

	/**
	 * __isset function.
	 *
	 * @param mixed $key
	 * @return bool
	 */
	public function __isset( $key ) {
		return metadata_exists( 'post', $this->id, 'intravel_' . $key );
	}

	/**
	 * __get function.
	 *
	 * @param string $key
	 * @return mixed
	 */
	public function __get( $key ) {
		$value = get_post_meta( $this->id, 'intravel_' . $key, true );

		if ( false !== $value ) {
			$this->$key = $value;
		}

		return $value;
	}

	/**
	 * Get the booking's post data.
	 *
	 * @return object
	 */
	public function get_post_data() {
		return $this->post;
	}

	/**
	 * Return the booking ID
	 *
	 * @since 2.5.0
	 * @return int booking (post) ID
	 */
	public function get_id() {

		return $this->id;
	}

	/**
	 * get_booking_number function.
	 *
	 * Gets the booking number for display (by default, booking ID).
	 *
	 * @return string
	 */
	public function get_booking_number() {
		return apply_filters( 'it_booking_number', $this->id, $this );
	}

	public function get_booking_date() {
		return apply_filters( 'it_booking_date', $this->post_date, $this );
	}

	static function get_booking_data_from_request() {
		
		$booking_data = array();

		if ( isset($_POST) ) {
			$booking_data['user'] = get_current_user_id();
			$booking_data['name'] = isset($_POST['name']) ? $_POST['name'] : '';
			$full_name = explode(' ', $booking_data['name']);
			if(isset($_POST['first_name'])){
				$booking_data['first_name'] = $_POST['first_name'];
			}
			elseif (isset($full_name[0])){
				$booking_data['first_name'] = $full_name[0];
			}
			if(isset($_POST['last_name'])){
				$booking_data['last_name'] = $_POST['last_name'];
			}elseif (isset($full_name[1])) {
				$booking_data['last_name'] = $full_name[1];
			}
			$booking_data['email'] = isset($_POST['email']) ? $_POST['email'] : '';
			$booking_data['phone'] = isset($_POST['phone']) ? $_POST['phone'] : '';
			//$booking_data['address'] = isset($_POST['address']) ? $_POST['address'] : '';

			$booking_data['tour'] = isset($_POST['tour']) ? $_POST['tour'] : '';
			$booking_data['start_date'] = isset($_POST['start_date']) ? $_POST['start_date'] : '';
			$booking_data['start_time'] = isset($_POST['start_time']) ? $_POST['start_time'] : '';
			$booking_data['duration'] = isset($_POST['duration']) ? $_POST['duration'] : '';
			$booking_data['adult_ticket'] = isset($_POST['adult_ticket']) ? (int)$_POST['adult_ticket'] : '';
			$booking_data['children_ticket'] = isset($_POST['children_ticket']) ? (int)$_POST['children_ticket'] : '';
			$booking_data['services'] = isset($_POST['intravel_service']) ? array_filter((array)$_POST['intravel_service']) : '';
			$tour = it_get_tour($booking_data['tour']);
            $service_prices = 0;
            if($booking_data['services']){
                $messsage = '';
                $service_prices = $tour->get_services_price($booking_data['services'], $booking_data['adult_ticket'], $booking_data['children_ticket'], $messsage);
            }
			$booking_data['price'] = (float)$tour->get_price_including_tax($service_prices) + (float)$tour->get_price_including_tax(null, $booking_data['start_date'], $booking_data['adult_ticket'], $booking_data['children_ticket']);
			$booking_data['subprice'] = (float)$tour->get_price_excluding_tax($service_prices) + (float)$tour->get_price_excluding_tax(null, $booking_data['start_date'], $booking_data['adult_ticket'], $booking_data['children_ticket']);
			$booking_data['tax'] = it_get_tax();
			$booking_data['currency'] = it_get_currency();
			$booking_data['payment_method'] = isset($_POST['payment_method']) ? $_POST['payment_method'] : '';
			$booking_data['special_requirements'] = isset($_POST['payment_method']) ? $_POST['special_requirements'] : '';
		}

		return $booking_data;
	}

	static function create_booking($booking_data = array()){
		if(!$booking_data){
			$booking_data = self::get_booking_data_from_request();
		}
		$tour_post = get_post($booking_data['tour']);

		$new_post = array(
			'post_title' 		=> esc_html__('Booking for ', 'intravel'). get_the_title($tour_post),
			'post_content' 		=> esc_html__('This is a booking tour for '.get_the_title($tour_post), 'intravel'),
			'post_status' 		=> 'publish',
			'post_name' 		=> $tour_post->post_name.'-booking',
			'post_type' 		=> 'tour_booking',
			'comment_status' 	=> 'closed'
		);

		$booking_id = wp_insert_post($new_post);

		if($booking_id){
			update_post_meta($booking_id, 'intravel_user', $booking_data['user']);
			update_post_meta($booking_id, 'intravel_tour', $booking_data['tour']);
			update_post_meta($booking_id, 'intravel_first_name', $booking_data['first_name']);
			update_post_meta($booking_id, 'intravel_last_name', $booking_data['last_name']);
			update_post_meta($booking_id, 'intravel_email', $booking_data['email']);
			update_post_meta($booking_id, 'intravel_phone', $booking_data['phone']);
			//update_post_meta($booking_id, 'intravel_address', $booking_data['address']);
			update_post_meta($booking_id, 'intravel_start_date', $booking_data['start_date']);
			update_post_meta($booking_id, 'intravel_start_time', $booking_data['start_time']);
			update_post_meta($booking_id, 'intravel_duration', get_post_meta( $tour_post->ID, 'intravel_duration', true ));
			update_post_meta($booking_id, 'intravel_adult_ticket', $booking_data['adult_ticket']);
			update_post_meta($booking_id, 'intravel_children_ticket', $booking_data['children_ticket']);
			update_post_meta($booking_id, 'intravel_price', $booking_data['price']);
			update_post_meta($booking_id, 'intravel_subprice', $booking_data['subprice']);
			update_post_meta($booking_id, 'intravel_tax', $booking_data['tax']);
			update_post_meta($booking_id, 'intravel_currency', $booking_data['currency']);
			update_post_meta($booking_id, 'intravel_payment_method', $booking_data['payment_method']);
			update_post_meta($booking_id, 'intravel_special_requirements', $booking_data['special_requirements']);
			update_post_meta($booking_id, 'intravel_status', 'pending');
			update_post_meta($booking_id, 'intravel_read', '0');
            if($booking_data['services']){
                wp_set_post_terms( $booking_id, $booking_data['services'], 'tour_service');
            }
			//IT()->empty_cart();
		}

		$customer = it_get_customer();
		$customer->phone = $booking_data['phone'];
		$customer->address = $booking_data['address'];

        IT()->empty_cart();

		return $booking_id;
	}

	static function update_booking($booking_id, $booking_data){
		if($booking_id){
			$customer = it_get_customer();
			foreach ($booking_data as $field_id => $value){
				update_post_meta($booking_id, 'intravel_'.$field_id, $value);
				if($field_id == 'phone' || $field_id == 'address'){
					$customer->{$field_id} = $value;
				}
			}
		}
	}

	static function delete_booking($booking_id){
		if($booking_id){
			return wp_delete_post($booking_id);
		}

		return false;
	}

	function completed_status(){
		if($this->post->ID){
			$tour = get_post_meta($this->post->ID, 'intravel_tour', true);
			$_adult = get_post_meta($this->post->ID, 'intravel_adult_ticket', true);
			$_children = get_post_meta($this->post->ID, 'intravel_children_ticket', true);
			$adult_sales = get_post_meta((int)$tour, 'intravel_adult_sales', true);
			$children_sales = get_post_meta((int)$tour, 'intravel_children_sales', true);
			$total_sales = get_post_meta((int)$tour, 'intravel_total_sales', true);
			$adult_sales = $adult_sales + $_adult;
			$children_sales = $children_sales + $_children;
			$total_sales += (int)$_adult + (int)$_children;
			update_post_meta((int)$tour, 'intravel_adult_sales', $adult_sales);
			update_post_meta((int)$tour, 'intravel_children_sales', $children_sales);
			update_post_meta((int)$tour, 'intravel_total_sales', $total_sales);
		}
	}

	function changeStatus($status, $sendmail = true){
		if($this->post->ID){
			$all_status = array_keys(it_get_status());
			if(in_array($status, $all_status)){
				update_post_meta($this->post->ID, 'intravel_status', $status);
				if($status == 'completed'){
					$this->completed_status();
				}
				if($sendmail){
                    IT_Email::sendMail($status, $this->post->ID);
                }
				return true;
			}
		}

		return false;

	}

	function getCancelUrl(){
		if($this->post->ID){
			return admin_url('admin-ajax.php?action=intravel_cancel_booking_tour&order='.$this->post->ID.'&code='.$this->getCancelCode());
		}

		return '';
	}

	function cancelBooking($code){
		if($this->post->ID){
			if($code == $this->getCancelCode()){
				if($this->status != 'cancelled'){
					$this->changeStatus('cancelled');
				}
				else{
					return __("Can not cancel this order because it is in a state of cancelled.", 'intravel');
				}
			}
			else{
				return __('Code invalid.', 'intravel');
			}
		}

		return __("Order invalid.", 'intravel');
	}

	function getCancelCode(){
		return md5($this->post->ID.$this->first_name.$this->last_name.$this->email);
	}
	function getPaypalUrl(){
	    if($this->post->ID){
            $paypal_email = it_get_option('paypal_email');
            $paypal_sanbox_mod = it_get_option('paypal_sanbox_mode');
            $return_url = add_query_arg( 'booking-received', $this->id, it_get_page_permalink( 'checkout' ) );
            $cancel_url = get_permalink($this->tour);
            $notify_url =  admin_url('admin-ajax.php?action=intravel_paypal_received');

            $querystring = '';
            $querystring .= "?business=".urlencode($paypal_email)."&";
            $querystring .= "item_name=".urlencode(get_the_title($this->tour))."&";
            $querystring .= "item_number=".urlencode($this->id)."&";
            $querystring .= "quantity=".urlencode(1)."&";
            $querystring .= "amount=".urlencode($this->price)."&";
            $querystring .= "cmd=".urlencode('_xclick')."&";
            $querystring .= "no_note=".urlencode('1')."&";
            //$querystring .= "lc=".urlencode(it_get_currency())."&";
            $querystring .= "currency_code=".urlencode(it_get_currency())."&";
            $querystring .= "bn=".urlencode(stripslashes('PP-BuyNowBF:btn_buynow_LG.gif:NonHostedGuest'))."&";
            $querystring .= "first_name=".urlencode(stripslashes($this->first_name))."&";
            $querystring .= "last_name=".urlencode(stripslashes($this->last_name))."&";
            $querystring .= "email=".urlencode(stripslashes($this->email))."&";
            $querystring .= "address_override=".urlencode($this->address)."&";
            //$querystring .= "address1=".urlencode(stripslashes($_POST['address']))."&";
            $querystring .= "night_phone_b=".urlencode(stripslashes($this->phone))."&";
            //$querystring .= "custom=".urlencode($this->id)."&";

            $querystring .= "return=".urlencode(stripslashes($return_url))."&";
            $querystring .= "cancel_return=".urlencode(stripslashes($cancel_url))."&";
            $querystring .= "notify_url=".urlencode($notify_url);

            return $paypal_sanbox_mod == '' ? 'https://www.sandbox.paypal.com/cgi-bin/webscr'.$querystring : 'https://www.paypal.com/cgi-bin/webscr'.$querystring;
        }

        return '';
	}

	function getPayUrl(){
		if($this->post->ID){
			return admin_url('admin-ajax.php?action=intravel_pay_booking_tour&order='.$this->post->ID);
		}

		return '';
	}

	function getCheckOrderUrl(){
		$url = it_get_page_permalink('checkorder');
		if($this->post->ID){
			$url = add_query_arg('order', $this->id, $url);
			$url = add_query_arg('email', $this->email, $url);
		}

		return $url;
	}
}
