<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
class IT_Process{

    /**
     * Hook into actions and filters.
     */
    public function init() {

        if(is_admin()){
            add_action( 'wp_ajax_intravel_get_customer_data', array($this, 'intravel_get_customer_data'));
        }

        add_action( 'wp_ajax_intravel_tour_price', array($this, 'tour_price') );
        add_action( 'wp_ajax_nopriv_intravel_tour_price', array($this, 'tour_price') );

        add_action( 'wp_ajax_intravel_change_monthyear', array($this, 'change_monthyear') );
        add_action( 'wp_ajax_nopriv_intravel_change_monthyear', array($this, 'change_monthyear') );


        add_action( 'wp_ajax_intravel_paypal_received', array($this, 'paypal_received') );
        add_action( 'wp_ajax_nopriv_intravel_paypal_received', array($this, 'paypal_received') );

        add_action( 'wp_ajax_intravel_booking_tour', array($this, 'booking_tour') );
        add_action( 'wp_ajax_nopriv_intravel_booking_tour', array($this, 'booking_tour') );

        add_action( 'wp_ajax_intravel_woocommerce_booking_tour', array($this, 'woocommerce_booking_tour') );
        add_action( 'wp_ajax_nopriv_intravel_woocommerce_booking_tour', array($this, 'woocommerce_booking_tour') );

        add_action( 'wp_ajax_intravel_search_tour', array($this, 'intravel_search_tour') );
        add_action( 'wp_ajax_nopriv_intravel_search_tour', array($this, 'intravel_search_tour') );

        add_action( 'wp_ajax_intravel_destination_rating', array($this, 'intravel_destination_rating') );
        add_action( 'wp_ajax_nopriv_intravel_destination_rating', array($this, 'intravel_destination_rating') );

        add_action( 'wp_ajax_intravel_cancel_booking_tour', array($this, 'intravel_cancel_booking_tour') );
        add_action( 'wp_ajax_nopriv_intravel_cancel_booking_tour', array($this, 'intravel_cancel_booking_tour') );

        add_action( 'wp_ajax_intravel_pay_booking_tour', array($this, 'intravel_pay_booking_tour') );
        add_action( 'wp_ajax_nopriv_intravel_pay_booking_tour', array($this, 'intravel_pay_booking_tour') );
    }


    public function set_cart($data){
        $_SESSION['intravel_cart'] = $data;
    }

    public function get_cart(){
        return $_SESSION['intravel_cart'];
    }

    public function empty_cart(){
        unset($_SESSION['intravel_cart']);
    }

    public function tour_price(){
        $return = array();
        $tour_id = $_POST['tour_id'];
        if($tour_id){
            $date = $_POST['date'];
            $adult = $_POST['adult'];
            $children = $_POST['children'];
            $services = $_POST['services'];
            $get_msg_tax = $_POST['get_msg_tax'];
            $tour = it_get_tour($tour_id);
            $return = $tour->get_price_status($date, $adult, $children, $services, false, $get_msg_tax);
        }

        echo json_encode($return);exit;
    }

    public function change_monthyear(){
        $return = array();
        $tour_id = $_POST['tour_id'];
        if($tour_id){
            $from_date = $_POST['from_date'];
            $to_date = $_POST['to_date'];
            $tour = it_get_tour($tour_id);
            $return = $tour->get_booking_days($from_date, $to_date);
        }

        echo json_encode($return);exit;
    }

    public function paypal_received(){

        $test_mode = it_get_option('paypal_sanbox_mode');
        // Get received values from post data
        $validate_ipn = array( 'cmd' => '_notify-validate' );
        $validate_ipn += wp_unslash( $_POST );

        // Send back post vars to paypal
        $params = array(
            'body'        => $validate_ipn,
            'timeout'     => 60,
            'httpversion' => '1.1',
            'compress'    => false,
            'decompress'  => false,
            'user-agent'  => 'InTravel/1.0'
        );

        // Post back to get a response.

        $response = wp_safe_remote_post( $test_mode ? 'https://www.sandbox.paypal.com/cgi-bin/webscr' : 'https://www.paypal.com/cgi-bin/webscr', $params );
        if (! is_wp_error( $response ) && $response['response']['code'] >= 200 && $response['response']['code'] < 300 && strstr( $response['body'], 'VERIFIED' )) {
            $order_id = $_POST['item_number'];
            //$custom = $_POST['custom'];
            $payment_status = $_POST['payment_status'];
           // $paid = $_POST['payment_gross'];
            $booking = new IT_Booking($order_id);
            if($booking->post->ID){
                //order status: 1-pendding, 2-paid, 3-cancel, 4-onhold
                //Paypal status: CANCELED, CREATED, COMPLETED, INCOMPLETE, ERROR, REVERSALERROR, PROCESSING, PENDING
                switch ($payment_status) {
                    case 'Completed':
                        $booking->changeStatus('completed');
                        break;
                    case 'Voided':
                        $booking->changeStatus('cancelled');
                        break;
                    case 'Refunded':
                        break;
                }
            }
        }
    }
    

    public function booking_tour(){
        if(isset($_POST['intravel-action']) && $_POST['intravel-action'] == 'checkout-tour' && wp_verify_nonce($_REQUEST['_wpnonce'], 'intravel-verify' )){
            IT()->set_cart($_POST);
            $customer = it_get_customer();
            $customer->update_data($_POST);
            wp_redirect(it_get_page_permalink('checkout'));
            exit;
        }
        elseif(isset($_POST['intravel-action']) && $_POST['intravel-action'] == 'submit-tour' && wp_verify_nonce($_REQUEST['_wpnonce'], 'intravel-verify' ))
        {
            $customer = it_get_customer();
            $customer->update_data($_POST);
            $data = IT_Booking::get_booking_data_from_request();
            if($data['tour'] && $data['start_date'] && ($data['adult_ticket'] || $data['children_ticket'])){
                $tour = it_get_tour($data['tour']);
                if($tour->get_price_status($data['start_date'], $data['adult_ticket'], $data['children_ticket'], true)){
                    $booking_id = IT_Booking::create_booking();
                    $booking = it_get_booking($booking_id);
                    IT_Email::sendMail('new', $booking);
                    if($_POST['payment_method'] == 'submit_form'){
                        $return_url = it_get_page_permalink( 'checkout' );
                        $return_url = it_add_endpoint_url('booking-received', $booking_id, $return_url);
                        wp_redirect($return_url);
                        exit;
                    }
                    //paypal
                    else{
                        $submit_form_status = it_get_option('submit_form_status', 'pending');
                        if($submit_form_status == 'onhold'){
                            $booking->changeStatus('onhold', false);
                        }
                        $url = $booking->getPaypalUrl();
                        header('location:'.$url);
                        exit();
                    }
                }
            }

            echo __('an error occurs during processing please reprocess', 'intravel');
            wp_die();
        }
    }

    function woocommerce_booking_tour(){
        if(isset($_POST['intravel-action']) && $_POST['intravel-action'] == 'checkout-tour' && wp_verify_nonce($_REQUEST['_wpnonce'], 'intravel-verify' ))
        {
            $booking_data = IT_Booking::get_booking_data_from_request();
            $booking_data['payment_method'] = 'woocommerce';
            $booking_id = IT_Booking::create_booking($booking_data);
            $booking = it_get_booking($booking_id);
            $IT_WC = new IT_Woocommerce();
            $IT_WC->tour_booking($booking);

            global $woocommerce;
            $checkout_url = $woocommerce->cart->get_checkout_url() ;
            wp_redirect($checkout_url);
            exit;
        }
    }

    function intravel_get_customer_data(){
        $user_id = $_POST['user_id'];
        $customer = it_get_customer();

        echo json_encode($customer->get_data($user_id));
        exit;
    }

    function intravel_search_tour(){
        $link = it_get_page_permalink('tours');
        $varibles = array('s', 'tour_type', 'destination', 'start_date', 'min_price', 'max_price', 'order', 'orderby');
        foreach ($varibles as $varible){
            if(isset($_POST[$varible]) && $_POST[$varible]){
                if($varible == 'min_price' || $varible == 'max_price'){
                    $prices = it_get_filtered_price();
                    $min = floor($prices->min_price);
                    $max = ceil($prices->max_price);
                    if($varible == 'min_price' && $_POST[$varible] > $min){
                        $link = add_query_arg($varible, $_POST[$varible], $link);
                    }
                    elseif($varible == 'max_price' && $_POST[$varible] < $max){
                        $link = add_query_arg($varible, $_POST[$varible], $link);
                    }
                }
                else
                {
                    $link = add_query_arg($varible, $_POST[$varible], $link);
                }
            }
        }
        wp_redirect($link);
        exit;
    }

    public function intravel_destination_rating(){
        $rating = $_POST['rating'];
        $destination = $_POST['destination'];
        $return = array('status'=>'', 'message' => '');
        if($rating && $destination){
            if(!it_can_rating_destination($destination)){
                if(it_can_rating_destination($destination) === 0){
                    $return['message'] = __('You have already voted this destination', 'intravel');
                }
                else
                {
                    $return['message'] = __('You not permission vote the destination', 'intravel');
                }
                echo json_encode($return); exit;
            }
            else{
                $average_rating = get_term_meta($destination, 'average_rating', true);
                $total_rating = get_term_meta($destination, 'total_rating', true);
                $average_rating = (($average_rating * $total_rating) + $rating) / ($total_rating + 1);
                update_term_meta($destination, 'average_rating' , round($average_rating, 2));
                update_term_meta($destination, 'total_rating' , ($total_rating + 1));
                $return['status'] = 1;
                $return['message'] = __('Thank you for rating', 'intravel');
                echo  json_encode($return); exit;
            }
        }
    }

    public function intravel_cancel_booking_tour(){
        $order = isset($_GET['order']) ? $_GET['order'] : 0;
        $code = isset($_GET['code']) ? $_GET['code'] : 0;
        $booking = new IT_Booking($order);
        if($booking->post->ID){
            if($code == $booking->getCancelCode()){
                if($booking->status == 'pending'){
                    $booking->changeStatus('cancelled');
                    $message = 4;
                }
                else{
                    $message = 3;
                }
            }
            else{
                $message = 2;
            }
        }
        else{
            $message = 1;
        }

        $checkorder_url = $booking->getCheckOrderUrl();
        $checkorder_url = add_query_arg('message', $message, $checkorder_url);

        wp_redirect($checkorder_url);
        exit;
    }

    public function intravel_pay_booking_tour(){
        $order = isset($_GET['order']) ? $_GET['order'] : 0;
        $booking = new IT_Booking($order);
        if($booking->post->ID){
            if($booking->status == 'pending'){
                $url = $booking->getPaypalUrl();
                wp_redirect($url);
                exit();
            }
            else{
                $message = 5;
            }
        }
        else{
            $message = 1;
        }

        $checkorder_url = $booking->getCheckOrderUrl();
        $checkorder_url = add_query_arg('message', $message, $checkorder_url);

        wp_redirect($checkorder_url);
        exit;
    }
}

$IT_Process = new IT_Process;
$IT_Process->init();

?>