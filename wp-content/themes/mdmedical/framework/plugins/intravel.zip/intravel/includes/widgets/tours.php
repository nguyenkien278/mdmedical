<?php
/**
 * Widget API: Inwave_Intravel_Tour_Tags class
 *
 * @package WordPress
 * @subpackage Widgets
 * @since 4.4.0
 */


class Inwave_Intravel_Tours extends WP_Widget {

    public function __construct() {
        $widget_ops = array(
            'description' => esc_html__( 'Display InTravel tours.' ),
            'customize_selective_refresh' => true,
        );
        parent::__construct( 'intravel_tours', esc_html__( 'InTravel Tours' ), $widget_ops );
    }

    public function widget( $args, $instance ) {

        $tour_type = isset($instance['tour_type']) ? strip_tags($instance['tour_type']) : '';
        $order_by = isset($instance['order_by']) ? strip_tags($instance['order_by']) : 'menu_order';
        $order_dir = isset($instance['order_dir']) ? strip_tags($instance['order_dir']) : 'DESC' ;
        $limit = isset($instance['limit']) ?  strip_tags($instance['limit']) : 3;

        if($order_by == 'popular'){
            $args_post = array(
                'number' => $limit,
                'post_status' => 'publish',
                'order_dir' => $order_dir,
                //	'include' => $include_ids,
                //	'exclude' => $exclude_ids,
                'suppress_filters' => function_exists('icl_object_id') ? false : true
            );
            if($tour_type){
                $args_post['tour_types'] = array($tour_type);
            }
            $tours = it_get_popular_tours($args_post);
        } elseif ($order_by == 'rating_count') {
            $args_post = array(
                'posts_per_page' => $limit,
                'post_status' => 'publish',
                'post_type' => 'tour',
                'meta_key' => '_it_average_rating',
                'orderby' => 'meta_value',
                'order' => $order_dir,
                //	'include' => $include_ids,
                //	'exclude' => $exclude_ids,
                'suppress_filters' => function_exists('icl_object_id') ? false : true
            );
            if($tour_type){
                $args_post['tax_query'] = array(
                    array(
                        'taxonomy' => 'tour_type',
                        'field' => 'slug',
                        'terms' => $tour_type,
                    )
                );
            }
            $tours = get_posts($args_post);
        }
        else {
            $args_post = array(
                'posts_per_page' => $limit,
                'post_status' => 'publish',
                'post_type' => 'tour',
                'orderby' => $order_by,
                'order' => $order_dir,
                //	'include' => $include_ids,
                //	'exclude' => $exclude_ids,
                'suppress_filters' => function_exists('icl_object_id') ? false : true
            );
            if($tour_type){
                $args_post['tax_query'] = array(
                    array(
                        'taxonomy' => 'tour_type',
                        'field' => 'slug',
                        'terms' => $tour_type,
                    )
                );
            }
            $tours = get_posts($args_post);
        }

        /** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
        $title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : __( 'Tours', 'intravel' );
        $title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

        echo $args['before_widget'];
        if ( $title ) {
            echo $args['before_title'] . $title . $args['after_title'];
        }
        ?>
        <div class="iw-travel-tours-widget">
            <?php foreach ($tours as $tour) :
                global $post;
                if(!is_object($tour)){
                    $post = get_post($tour);
                }
                else{
                    $post = $tour;
                }
                $tour = it_get_tour($tour);
                $duration = $tour->duration;
                $price = $tour->price;
                $destinations = $tour->get_destinations();
                ?>
                <div class="iw-tour-item iw-effect-img">
                    <div class="tour-thumnail effect-1">
                        <?php
                        $img = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');
                        $img_src = count($img) ? $img[0] : '';
                        $img_src = inwave_resize($img_src, 600, 600, true);
                        ?>
                        <img src="<?php echo esc_url($img_src); ?>" alt=""/>
                    </div>
                    <div class="tour-info">
                        <h3 class="title"><a class="theme-color" href="<?php echo get_permalink(); ?>"><?php echo get_the_title(); ?></a></h3>
                        <div class="post-meta">
                            <ul>
                                <?php if ($destinations) :
                                    ?>
                                    <li>
                                        <i class="fa fa-map-marker"> </i>
                                        <?php
                                        $destination_html = array();
                                        foreach($destinations as $destination){
                                            $destination_html[] = '<a href="'.esc_url(get_term_link($destination->slug, 'destination')).'" class="destination">'.$destination->name.'</a>';
                                        }
                                        echo implode(' / ', $destination_html);
                                        ?>
                                    </li>
                                <?php endif; ?>
                                <?php if ($duration) : ?>
                                    <li>
                                        <span class="duration"><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo $duration; ?></span>
                                    </li>
                                <?php endif ?>
                            </ul>
                        </div>
                    </div>
                    <div style="clear: both"></div>
                </div>
            <?php endforeach;
            wp_reset_postdata(); ?>
        </div>

        <?php
        echo $args['after_widget'];
    }

    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title'] = strip_tags($new_instance['title']);
//		$instance['title'] = strip_tags($new_instance['title']);
        $instance['tour_type'] = strip_tags($new_instance['tour_type']);
        $instance['order_by'] = strip_tags($new_instance['order_by']);
        $instance['order_dir'] = strip_tags($new_instance['order_dir']);
        $instance['limit'] = strip_tags($new_instance['limit']);
        return $instance;
    }

    public function form( $instance ) {
        $instance = wp_parse_args( (array) $instance, array( 'title' => '', 'tour_type' => __( 'Tours', 'intravel' ), 'order_by' => 'menu_order', 'order_dir' => 'DESC', 'limit' => 3 ) );
        $title = strip_tags($instance['title']);
        $tour_type = esc_attr($instance['tour_type']);
        $order_by = esc_attr($instance['order_by']);
        $order_dir = esc_attr($instance['order_dir']);
        $limit = esc_attr($instance['limit']);

        global $wpdb;
        $tour_types = $wpdb->get_results('SELECT a.name, a.slug FROM ' . $wpdb->prefix . 'terms AS a INNER JOIN ' . $wpdb->prefix . 'term_taxonomy AS b ON a.term_id = b.term_id WHERE b.taxonomy=\'tour_type\'');
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'inevent'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('tour_type')); ?>"><?php esc_html_e('Tour Types:', 'inevent'); ?></label>
            <select class="widefat" id="<?php echo esc_attr($this->get_field_id('tour_type')); ?>" name="<?php echo esc_attr($this->get_field_name('tour_type')); ?>">
                <option value=""><?php echo esc_html(__('All', 'intravel')); ?></option>
                <?php
                foreach($tour_types as $_tour_type){
                    echo '<option value="'.$_tour_type->slug.'" '.($_tour_type->slug == $tour_type ? 'selected' : '').'>'.$_tour_type->name.'</option>';
                }
                ?>
            </select>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('order_by')); ?>"><?php esc_html_e('Order by:', 'inevent'); ?></label>
            <select class="widefat" id="<?php echo esc_attr($this->get_field_id('order_by')); ?>" name="<?php echo esc_attr($this->get_field_name('order_by')); ?>">
                <option value="ID" <?php echo ($order_by == 'ID' ? 'selected' : '')?>><?php echo esc_html(__('Tour ID', 'inevent')); ?></option>
                <option value="date" <?php echo ($order_by == 'date' ? 'selected' : '')?>><?php echo esc_html(__('Date', 'inevent')); ?></option>
                <option value="title" <?php echo ($order_by == 'title' ? 'selected' : '')?>><?php echo esc_html(__('Title', 'inevent')); ?></option>
                <option value="menu_order" <?php echo ($order_by == 'menu_order' ? 'selected' : '')?>><?php echo esc_html(__('Ordering', 'inevent')); ?></option>
                <option value="popular" <?php echo ($order_by == 'popular' ? 'selected' : '')?>><?php echo esc_html(__('Popular', 'inevent')); ?></option>
                <option value="rating_count" <?php echo ($order_by == 'rating_count' ? 'selected' : '')?>><?php echo esc_html(__('Rating Count', 'inevent')); ?></option>
            </select>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('order_dir')); ?>"><?php esc_html_e('Order Direction:', 'inevent'); ?></label>
            <select class="widefat" id="<?php echo esc_attr($this->get_field_id('order_dir')); ?>" name="<?php echo esc_attr($this->get_field_name('order_dir')); ?>">
                <option value="DESC" <?php echo ($order_dir == 'DESC' ? 'selected' : '')?> ><?php echo esc_html(__('Descending', 'inevent')); ?></option>
                <option value="ASC" <?php echo ($order_dir == 'ASC' ? 'selected' : '')?>><?php echo esc_html(__('Ascending', 'inevent')); ?></option>
            </select>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('limit')); ?>"><?php esc_html_e('Limit:', 'inevent'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('limit')); ?>" name="<?php echo esc_attr($this->get_field_name('limit')); ?>" type="text" value="<?php echo esc_attr($limit); ?>" />
        </p>
        <?php
    }

}

function intravel_tours_widget() {
    register_widget('Inwave_Intravel_Tours');
}
add_action('widgets_init', 'intravel_tours_widget');