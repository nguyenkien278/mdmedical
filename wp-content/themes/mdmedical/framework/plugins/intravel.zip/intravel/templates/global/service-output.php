<?php
global $tour_service, $tour_selected_services;
if($tour_service){
    $service = $tour_service;
    $arg = array(
        'taxonomy' => 'tour_service',
        'hide_empty' => false,
        'parent' => $service->term_id
    );
    $child_services = get_terms($arg);
    if($child_services){
        $type = get_term_meta($service->term_id, 'intravel_select_type', true);
        if($type == 'select'){
            $option_html = '';
            $has_price = false;
            foreach ($child_services as $child_service){
                $selected = in_array($child_service->term_id, (array)$tour_selected_services);
                $price = get_term_meta($child_service->term_id, 'intravel_price', true);
                $price = $price ? it_price($price) : '';
                $child_price = get_term_meta($child_service->term_id, 'intravel_children_price', true);
                $child_price = $child_price ? it_price($child_price) : '';
                $string = '';
                if($price && $child_price){
                    $string = sprintf(__('[A:%s,C:%s]', 'inwavethemes'), $price, $child_price);
                }elseif($price){
                    $string = sprintf(__('[A:%s]', 'inwavethemes'), $price);
                }elseif($child_price){
                    $string = sprintf(__('[C:%s]', 'inwavethemes'), $child_price);
                }
                if($string) {
                    $has_price = true;
                }
                $option_html .= '<option value="'.$child_service->term_id.'" title="'.$string.'" '.($selected !== false ? 'selected' : '').'>'.$child_service->name.'</option>';
            }
            echo '<select name="intravel_service[]" class="intravel-select2 '.($has_price ? 'has-price' : '').'">';
            echo '<option value="" >'.$service->name.'</option>';
            echo $option_html;
            echo '</select>';
        }
        else{
            echo '<label class="service-label-title">'.$service->name.'</label>';
            echo '<div class="checkbox-service-group parent">';
            foreach ($child_services as $child_service){
                $selected = in_array($child_service->term_id, (array)$tour_selected_services);
                $price = get_term_meta($child_service->term_id, 'intravel_price', true);
                $child_price = get_term_meta($child_service->term_id, 'intravel_children_price', true);
                $price = $price ? it_price($price) : '';
                $child_price = $child_price ? it_price($child_price) : '';
                $price_right = sprintf(__('Free', 'inwavethemes'));
                if($price) {
                    $price_right = sprintf(__('%s', 'inwavethemes'), $price);
                }
                $string = '';
                if($price && $child_price){
                    $string = sprintf(__('[A:%s,C:%s]', 'inwavethemes'), $price, $child_price);
                }elseif($price){
                    $string = sprintf(__('[A:%s]', 'inwavethemes'), $price);
                }elseif($child_price){
                    $string = sprintf(__('[C:%s]', 'inwavethemes'), $child_price);
                }
                echo '<div class="checkbox-service-item"><div class="input-checkbox title="'.$string.'""><input type="checkbox" name="intravel_service[]" value="'.$child_service->term_id.'" class="'.($string ? 'has-price' : '').'" '.($selected !== false ? 'checked' : '').'><label class="service-child-label">'.$child_service->name.'</label></div><span class="'.sprintf((!$price && !$child_price) ? 'free' : 'none').'">'.$price_right.'</span></div>';
            }
            echo '</div>';
        }
    }else{
        $selected = in_array($service->term_id, (array)$tour_selected_services);
        $price = get_term_meta($service->term_id, 'intravel_price', true);
        $child_price = get_term_meta($service->term_id, 'intravel_children_price', true);
        $price = $price ? it_price($price) : '';
        $child_price = $child_price ? it_price($child_price) : '';
        $price_right = sprintf(__('Free', 'inwavethemes'));
        if($price) {
            $price_right = sprintf(__('%s', 'inwavethemes'), $price);
        }
        $title = '';
        if($price && $child_price){
            $title = sprintf(__('[A:%s,C:%s]', 'inwavethemes'), $price, $child_price);
        }elseif($price){
            $title = sprintf(__('[A:%s]', 'inwavethemes'), $price);
        }elseif($child_price){
            $title = sprintf(__('[C:%s]', 'inwavethemes'), $child_price);
        }
        echo '<div class="checkbox-service-item"><div class="input-checkbox" title="'.$title.'"><input type="checkbox" name="intravel_service[]" value="'.$service->term_id.'" class="'.($title ? 'has-price' : '').'" '.($selected !== false ? 'checked' : '').'><label class="service-label service-input-label-title checkbox-label">'.$service->name.'</label></div><span class="'.sprintf((!$price && !$child_price) ? 'free' : 'none').'">'.$price_right.'</span></div>';
    }

    $tour_service = null;
}