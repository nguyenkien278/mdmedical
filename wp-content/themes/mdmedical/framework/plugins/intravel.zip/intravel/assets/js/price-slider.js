/* global intravel_price_slider_params */
jQuery( function( $ ) {

	$.fn.itpriceslider = function(){
		$(this).each(function(){
			var self = $(this);
			// intravel_price_slider_params is required to continue, ensure the object exists
			if ( typeof intravel_price_slider_params === 'undefined' ) {
				return false;
			}

			// Get markup ready for slider
			self.find( 'input.tour_min_price, input.tour_max_price' ).hide();
			self.find( '.tour_price_slider, .price_label' ).show();

			// Price slider uses jquery ui
			var min_price = self.find( '.tour_min_price' ).data( 'min' ),
				max_price = self.find('.tour_max_price' ).data( 'max' ),
				current_min_price = parseInt( min_price, 10 ),
				current_max_price = parseInt( max_price, 10 );

			if ( intravel_price_slider_params.min_price ) {
				current_min_price = parseInt( intravel_price_slider_params.min_price, 10 );
			}
			if ( intravel_price_slider_params.max_price ) {
				current_max_price = parseInt( intravel_price_slider_params.max_price, 10 );
			}

			$( document.body ).bind( 'tour_price_slider_create tour_price_slider_slide', function( event, min, max, self ) {
				var style = self.data('style') ? self.data('style') : 'default';
				if ( intravel_price_slider_params.currency_pos === 'left' ) {
					if(style == 'style2'){
						self.find('.ui-slider-handle:eq(0)').html('<span>'+intravel_price_slider_params.currency_symbol + min+'</span>');
						self.find('.ui-slider-handle:eq(1)').html('<span>'+intravel_price_slider_params.currency_symbol + max+'</span>');
					}else{
						self.find( 'span.from' ).html( intravel_price_slider_params.currency_symbol + min );
						self.find( 'span.to' ).html( intravel_price_slider_params.currency_symbol + max );
					}
				} else if ( intravel_price_slider_params.currency_pos === 'left_space' ) {
					if(style == 'style2'){
						self.find('.ui-slider-handle:eq(0)').html('<span>'+intravel_price_slider_params.currency_symbol + ' ' + min+'</span>');
						self.find('.ui-slider-handle:eq(1)').html('<span>'+intravel_price_slider_params.currency_symbol + ' ' + max+'</span>');
					}else{
						self.find( 'span.from' ).html( intravel_price_slider_params.currency_symbol + ' ' + min );
						self.find( 'span.to' ).html( intravel_price_slider_params.currency_symbol + ' ' + max );
					}
				} else if ( intravel_price_slider_params.currency_pos === 'right' ) {
					if(style == 'style2'){
						self.find('.ui-slider-handle:eq(0)').html('<span>'+min + intravel_price_slider_params.currency_symbol+'</span>');
						self.find('.ui-slider-handle:eq(1)').html('<span>'+max + intravel_price_slider_params.currency_symbol+'</span>');
					}else{
						self.find( 'span.from' ).html( min + intravel_price_slider_params.currency_symbol );
						self.find( 'span.to' ).html( max + intravel_price_slider_params.currency_symbol );
					}
				} else if ( intravel_price_slider_params.currency_pos === 'right_space' ) {
					if(style == 'style2'){
						self.find('.ui-slider-handle:eq(0)').html('<span>'+min + ' ' + intravel_price_slider_params.currency_symbol+'</span>');
						self.find('.ui-slider-handle:eq(1)').html('<span>'+max + ' ' + intravel_price_slider_params.currency_symbol+'</span>');
					}else{
						self.find( 'span.from' ).html( min + ' ' + intravel_price_slider_params.currency_symbol );
						self.find( 'span.to' ).html( max + ' ' + intravel_price_slider_params.currency_symbol );
					}
				}

				$( document.body ).trigger( 'tour_price_slider_updated', [ min, max ] );
			});

			self.find( '.tour_price_slider' ).slider({
				range: true,
				animate: true,
				min: min_price,
				max: max_price,
				values: [ current_min_price, current_max_price ],
				create: function() {

					self.find( '.tour_min_price' ).val( current_min_price );
					self.find( '.tour_max_price' ).val( current_max_price );

					$( document.body ).trigger( 'tour_price_slider_create', [ current_min_price, current_max_price, self ] );
				},
				slide: function( event, ui ) {

					$( 'input.tour_min_price' ).val( ui.values[0] );
					$( 'input.tour_max_price' ).val( ui.values[1] );

					$( document.body ).trigger( 'tour_price_slider_slide', [ ui.values[0], ui.values[1], self ] );
				},
				change: function( event, ui ) {

					$( document.body ).trigger( 'tour_price_slider_change', [ ui.values[0], ui.values[1] ], self );
				}
			});
		});
	};

	$(document).ready(function(){
		$('.tour_price_slider_wrapper').itpriceslider();
	});
});
