<?php
/**
 * The template for displaying pages
 * @package intravel
 */
get_header();

$inwave_post_option = Inwave_Helper::getConfig();

$booking = it_get_booking();
$tour = it_get_tour($booking->tour);
?>
<div class="contents-main thankyou-page" id="contents-main">
    <div class="page-content">
        <div class="main-content">
            <div class="container">
                <?php
                if (!$booking ){ ?>
                    <p class="thankyou-booking-failed"><?php _e( 'Unfortunately your booking cannot be processed as the originating bank/merchant has declined your transaction. Please attempt your purchase again.', 'intravel' ); ?></p>
                    <p class="booking-failed-actions">
                        <a href="<?php echo esc_url( it_get_page_permalink('checkout') ); ?>" class="button pay"><?php _e( 'Pay', 'intravel' ) ?></a>
                    </p>

                <?php }else{ ?>
                    <div class="icon-check theme-bg"><i class="icon ion-ios-checkmark-empty"></i></div>
                    <h3 class="thankyou-order-received theme-color"><?php echo it_get_option( 'thankyou_page_title', 'Congratulation! Your order has been confirmed!'); ?></h3>
                    <div class="thankyou-booking"><?php echo it_get_option( 'thankyou_page_description', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras sollicitudin, tellus vitae condimentum egestas, libero dolor auctor tellus, eu consectetur neque elit quis nunc. Cras elementum pretium est.' ); ?></div>
                <?php } ?>
                <?php do_action( 'intravel_thankyou', $booking->id ); ?>
                <div class="back-homepage"><a class="theme-bg" href="<?php echo esc_url(get_home_url()); ?>"><?php _e( 'Home page', 'intravel'); ?></a></div>
            </div>
        </div>
    </div>
</div>
<?php get_footer(); ?>
