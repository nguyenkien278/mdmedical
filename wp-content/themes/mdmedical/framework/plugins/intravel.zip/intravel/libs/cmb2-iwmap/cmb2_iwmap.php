<?php
/*
Plugin Name: CMB2 Metatabs Options
Plugin URI:  https://github.com/rogerlos/cmb2-metatabs-options
Description: Add admin option pages with multiple metaboxes--and place those metaboxes into optional tabs. Requires CMB2.
Version:     1.0.1
Author:      Roger Los
Author URI:  https://github.com/rogerlos
Text Domain: cmb2
License:     GPLv2 or later
 */

if ( ! defined( 'WPINC' ) ) die;

if(!function_exists('cmb2_render_iwmap')){
    function cmb2_render_iwmap($field, $escaped_value, $object_id, $object_type, $field_type_object ){
        global $inwave_theme_option;
        $google_map_api = it_get_option('google_api') ? it_get_option('google_api') : (isset($inwave_theme_option['google_api']) ? $inwave_theme_option['google_api'] : '');
        wp_enqueue_script('googlemap-api', 'https://maps.googleapis.com/maps/api/js?key='.$google_map_api.'&libraries=places', array('jquery'), INTRAVEL_VERSION);        wp_enqueue_style( 'iwmap' , INTRAVEL_PLUGIN_URL .'/libs/cmb2-iwmap/css/iwmap.css');

        $value = array( 'lat' => '', 'lng' => '', 'zoom' => '');
        $meta_value = $field->value;
        $value = array_merge($value, (array)json_decode($meta_value, true));
        $name = $field->args['id'];
        echo '<div id="'.$field->args['id'].'" class="cmb_map">';
        echo '<input id="'.$field->args['id'].'_pac_input" class="controls" type="text" placeholder="Search Box">';
        echo '<div id="'.$field->args['id'].'_map" class="map" style="height: 300px;">';

        echo '</div>';
        echo '<div class="cmb_map_info">';
        echo '<label>Latitude </label>';
        echo '<input type="text" id="'.$field->args['id'].'_lat"  class="cmb2-text-small" name="'.$name.'[lat]" value="'.$value['lat'].'">';
        echo '<label>Logitude </label>';
        echo '<input type="text" id="'.$field->args['id'].'_lng"  class="cmb2-text-small" name="'.$name.'[lng]" value="'.$value['lng'].'">';
        echo '<label>Zoom </label>';
        echo '<input type="text" id="'.$field->args['id'].'_zoom"  class="cmb2-text-small" name="'.$name.'[zoom]" value="'.$value['zoom'].'">';
        echo '</div>';
        ob_start();
        ?>
        <script>
            jQuery(document).ready(function($){
                function initMap<?php echo $field->args['id']; ?>() {
                    var map = new google.maps.Map(document.getElementById('<?php echo $field->args['id'].'_map'; ?>'), {
                        center: {lat: -33.8688, lng: 151.2195},
                        zoom: 13,
                        mapTypeId: google.maps.MapTypeId.ROADMAP,
                        scrollwheel: false,
                    });

                    // Create the search box and link it to the UI element.
                    var input = document.getElementById('<?php echo $field->args['id'].'_pac_input'; ?>');

                    input.addEventListener("keypress", function(e) {
                        if( (e.keyCode == 13)) {
                            e.preventDefault();
                        }
                    });

                    var searchBox = new google.maps.places.SearchBox(input);

                    map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

                    // Bias the SearchBox results towards current map's viewport.
                    map.addListener('bounds_changed', function() {
                        searchBox.setBounds(map.getBounds());
                    });

                    var markers = [];
                    // Listen for the event fired when the user selects a prediction and retrieve
                    // more details for that place.

                    var map_data = '<?php echo $meta_value; ?>';
                    if(map_data){
                        map_data = JSON.parse(map_data);
                        var destination = new google.maps.LatLng(map_data.lat,map_data.lng);
                        var marker = new google.maps.Marker({
                            map: map,
                            title: '',
                            position:  destination,
                            draggable : true
                        });

                        markers.push(marker);

                        marker.addListener('drag',function(event) {
                            document.getElementById('<?php echo $field->args['id'].'_lat'; ?>').value = event.latLng.lat();
                            document.getElementById('<?php echo $field->args['id'].'_lng'; ?>').value = event.latLng.lng();
                        });

                        marker.addListener('dragend',function(event) {
                            document.getElementById('<?php echo $field->args['id'].'_lat'; ?>').value = event.latLng.lat();
                            document.getElementById('<?php echo $field->args['id'].'_lng'; ?>').value = event.latLng.lng();
                        });
                        if(map_data.zoom){
                            map.setZoom(parseInt(map_data.zoom));
                        }
                        map.setCenter(destination);
                    }

                    searchBox.addListener('places_changed', function() {
                        var places = searchBox.getPlaces();

                        if (places.length == 0) {
                            return;
                        }

                        // Clear out the old markers.
                        markers.forEach(function(marker) {
                            marker.setMap(null);
                        });
                        markers = [];

                        // For each place, get the icon, name and destination.
                        var bounds = new google.maps.LatLngBounds();
                        places.forEach(function(place) {
                            // Create a marker for each place.
                            var marker = new google.maps.Marker({
                                map: map,
                                title: place.name,
                                position: place.geometry.location,
                                draggable : true
                            });
                            markers.push(marker);

                            if (place.geometry.viewport) {
                                // Only geocodes have viewport.
                                bounds.union(place.geometry.viewport);
                            } else {
                                bounds.extend(place.geometry.location);
                            }
                            document.getElementById('<?php echo $field->args['id'].'_lat'; ?>').value = place.geometry.location.lat();
                            document.getElementById('<?php echo $field->args['id'].'_lng'; ?>').value = place.geometry.location.lng();
                            document.getElementById('<?php echo $field->args['id'].'_zoom'; ?>').value = 13;

                            marker.addListener('drag',function(event) {
                                document.getElementById('<?php echo $field->args['id'].'_lat'; ?>').value = event.latLng.lat();
                                document.getElementById('<?php echo $field->args['id'].'_lng'; ?>').value = event.latLng.lng();
                            });

                            marker.addListener('dragend',function(event) {
                                document.getElementById('<?php echo $field->args['id'].'_lat'; ?>').value = event.latLng.lat();
                                document.getElementById('<?php echo $field->args['id'].'_lng'; ?>').value = event.latLng.lng();
                            });
                        });

                        map.fitBounds(bounds);
                    });
                    map.addListener('zoom_changed', function() {
                        document.getElementById('<?php echo $field->args['id'].'_zoom'; ?>').value = map.getZoom();
                    });
                }
                google.maps.event.addDomListener(window, 'load', initMap<?php echo $field->args['id']; ?>);
            });
        </script>
        <?php
        $html = ob_get_contents();
        ob_end_clean();
        echo $html;
        echo '</div>';
    }

    add_action( 'cmb2_render_iwmap', 'cmb2_render_iwmap', 10, 5 );

    function cmb2_sanitize_iwmap( $override_value, $value ) {
        // not an email?
        return json_encode($value);
    }

    add_filter( 'cmb2_sanitize_iwmap', 'cmb2_sanitize_iwmap', 10, 2 );
}
