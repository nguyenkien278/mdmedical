<?php
get_header('tour');
global $inwave_theme_option;
$sidebar_position = Inwave_Helper::getPostOption('sidebar_position', 'sidebar_position');

$term   = get_queried_object();
$destination = it_get_detination($term);
if ($term->parent){
	$destination_parent = it_get_detination($term->parent);
}
$destination->map = $destination->get_map();
$destination->image = get_term_meta($destination->term_id, 'intravel_image', true);
$destination->info = $destination->get_info();
$destination->rating = $destination->get_average_rating();
$destination->desc = $term->description;

?>
<div class="page-content destination-detail">
	<div class="destination-cover<?php echo $destination->image ? '' : ' no-image-post' ?>">
		<div class="destination-image" style="background: url('<?php echo $destination->image; ?>')  no-repeat scroll center center / cover"></div>
		
		<div class="destination-cover-info">
			<div class="container">
				<div class="destination-cover-content">
					<h3 class="destination-name"><?php echo $term->name; ?></h3>
					<?php if ($term->parent){ ?>
						<div class="destination-parent"><?php echo isset($destination_parent) ? $destination_parent->term->name : ''; ?></div>
					<?php } ?>
					
					<div class="rate-and-total">
						<div class="number-tours"><i class="ion-ios-location"></i><?php echo '<span>'.$term->count.'</span>'; echo $term->count > 1 ? 'tours' : 'tour'; ?></div>
						<div class="destination-rate"><?php echo $destination->get_rating_html(true); ?></div>
					</div>
					<a class="view-all-tours" href="<?php echo add_query_arg('destination',$term->slug, it_get_page_permalink('tours')) ?>"><?php echo esc_html__('View all tours', 'intravel') ?> <i class="ion-arrow-right-c"></i></a>
				</div>
			</div>
		</div>
	</div>
	<div class="main-content">
		<div class="container">
			<div class="row">
				<div class="<?php echo esc_attr(inwave_get_classes('container', $sidebar_position))?> destination-content">
					
					<div class="destination-social-share">
						<h3 class="title-block"><?php echo esc_html__('Your need to know', 'intravel') ?></h3>
						<?php if($inwave_theme_option['social_sharing_box_category']): ?>
							<div class="post-share-buttons">
								<div class="post-share-buttons-inner">
										<?php
										inwave_social_sharing_category_listing(get_permalink(), Inwave_Helper::substrword(get_the_excerpt(), 10), get_the_title());
										?>
								</div>
							</div>
						<?php endif; ?>
					</div>
					<div class="destination-info-map<?php echo $destination->info ? '' : ' no-info' ?>">
						<?php if ($destination->info){ ?>
							<div class="destination-info">
								<?php foreach ($destination->info as $info) { ?>
									<div class="destination-info-item">
										<?php echo '<label>'.$info[0].'</label> : <span>'.$info[1].'</span>'; ?>
									</div>
								<?php } ?>
							</div>
						<?php } ?>
						<div id="destination-map" class="destination-map"></div>
						<div class="clear"></div>
					</div>
						
						<div class="destination-intro">
							<h3 class="title-block"><?php echo esc_html__('About '.$term->name, 'intravel') ?></h3>
							<div class="desc"><?php echo $destination->desc; ?></div>
						</div>
						
						
						<?php 
							$tour_related_args = array(
								'post_type' => 'tour',
								'tax_query' => array(
									array(
										'taxonomy' => 'destination',
										'field' => 'slug',
										'terms' => $term->slug,
									),
								),
							);
							$destination_tours = get_posts($tour_related_args);
							?>
						<?php if (count($destination_tours)>0){ ?>
						<div class="related_destination_tours iw-tour-listing">
							
							<h3 class="title-block"><?php echo $term->name; echo esc_html__(count($destination_tours) > 1 ? ' tours' : ' tour', 'intravel') ?></h3>
							<div class="destination_content">
								<div class="row">
									<?php foreach ($destination_tours as $tour){
										global $post;
										if(!is_object($tour)){
											$post = get_post($tour);
										}
										else{
											$post = $tour;
										}
										$tour = it_get_tour($tour);
										$duration = $tour->duration;
										$price = $tour->price;
										$destinations = $tour->get_destinations();
										$total_reviews = $tour->get_review_count();
										$rating = $tour->get_rating_html();
									?>
									
										<div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 item-clear">
											<div class="tour-item">
													<?php 
														$img = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full'); 
														$img_src = count($img) ? $img[0] : '';
														$img_src = inwave_resize($img_src, 270, 255, true);
														?>
														
													<?php if ($img){ ?>
														<div class="image-wrap">
															<img src="<?php echo esc_url($img_src); ?>" alt=""/>
														</div>
													<?php } ?>
													<div class="tour-info-wrap">
														<div class="info-top">
															<h3 class="title"><a class="theme-color-hover" href="<?php echo get_permalink(); ?>"><?php echo the_title(); ?></a></h3>
															<div class="post-meta">
																<ul>
                                                                    <?php if ($destinations) :
                                                                        ?>
                                                                        <li class="destinations">
                                                                            <i class="fa fa-map-marker"> </i>
                                                                            <?php
                                                                            $destination_html = array();
                                                                            foreach($destinations as $destination){
                                                                                $destination_html[] = '<a href="'.esc_url(get_term_link($destination->slug, 'destination')).'" class="destination">'.$destination->name.'</a>';
                                                                            }
                                                                            echo implode(' / ', $destination_html);
                                                                            ?>
                                                                        </li>
                                                                    <?php endif; ?>
																	<?php if ($tour ->get_duration()) : ?>
																		<li>
																			<span class="duration"><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo $tour ->get_duration(); ?></span>
																		</li>
																	<?php endif ?>
																</ul>
															</div>
														</div>
														<div class="tour-price-vote">
															<?php if ($price){ ?>
																	<span class="price-tour theme-bg"><?php echo it_price($price); ?></span>
															<?php } ?>
																<div class="iwt-rating">
																	<?php echo $rating; ?>
																</div>
																<div class="clear"></div>
														</div>
													</div>
											</div>
										</div>
									
									<?php } ?>
								</div>
							</div>
						</div>
						<?php } ?>
				</div>
				<?php if ($sidebar_position && $sidebar_position != 'none') { ?>
                    <div class="<?php echo esc_attr(inwave_get_classes('sidebar', $sidebar_position))?> destination-sidebar">
							<?php get_sidebar('tours'); ?>
					</div>
				<?php } ?>
			</div>
		</div>
	</div>
</div>
<?php get_footer(); ?>