<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Comment
 * Handle comment (reviews and order notes).
 *
 */
class IT_Comment {

	/**
	 * Hook in methods.
	 */
	public static function init() {

		add_action( 'wp_update_comment_count', array( __CLASS__, 'clear_transients' ) );

		// Add fields after default fields above the comment box, always visible
		add_action( 'comment_form_top', array( __CLASS__, 'custom_fields' ) );

		// Save the comment meta data along with comment
		add_action( 'comment_post', array( __CLASS__, 'save_comment_meta_data' ));

		// Add the filter to check if the comment meta data has been filled or not
		add_filter( 'preprocess_comment', array( __CLASS__, 'verify_comment_meta_data'));

		//Add an edit option in comment edit screen
		add_action( 'add_meta_boxes_comment', array( __CLASS__, 'extend_comment_add_meta_box'));

		// Update comment meta data from comment edit screen
		//add_action( 'edit_comment', array( __CLASS__, 'extend_comment_edit_metafields'));

		// Add the comment meta (saved earlier) to the comment text
		// You can also output the comment meta values directly in comments template
		add_filter( 'comment_text', array( __CLASS__, 'modify_comment'), 99 ,1);
	}

	/**
	 * Ensure product average rating and review count is kept up to date.
	 * @param int $post_id
	 */
	public static function clear_transients( $post_id ) {
		if(get_post_type($post_id) == 'tour'){
			if((isset( $_POST['rating']) && isset($_POST['comment_ID'])) || (isset( $_POST['rating']) && !isset($_POST['comment_ID'])) || (!isset( $_POST['rating']) && !isset($_POST['comment_ID'])) ){
				if(isset( $_POST['rating']) && isset($_POST['comment_ID'])){
					update_comment_meta($_POST['comment_ID'], 'rating', $_POST['rating']);
				}

				delete_post_meta( $post_id, '_it_average_rating' );
				delete_post_meta( $post_id, '_it_rating_count' );
				delete_post_meta( $post_id, '_it_review_count' );

				IT_Tour::sync_average_rating( $post_id);
			}
		}
	}

	static function custom_fields () {
		global $post;
        $tour = it_get_tour();
        $html = '';
		if('tour' === get_post_type( $post)){
			$html .= '<div class="comment-form-rating">';
				$html .= '<label> '. __('Rating ') . '</label>';
                $html .= '<div class="rating-vote">';
                    $html .= $tour->get_rating_html(true);
			    $html .= '</div>';
			$html .= '</div>';
		}

		echo $html;
	}

	static function save_comment_meta_data( $comment_id ) {
		if ( ( isset( $_POST['rating'] ) ) && ( $_POST['rating'] != '') && 'tour' === get_post_type( $_POST['comment_post_ID']) && (!isset($_POST['comment_parent']) || $_POST['comment_parent'] == 0)){
			$rating = wp_filter_nohtml_kses($_POST['rating']);
			update_comment_meta( $comment_id, 'rating', $rating );
			self::clear_transients($_POST['comment_post_ID']);
		}
	}

	static function verify_comment_meta_data( $commentdata ) {
        if(!is_admin() && isset($_POST['comment_post_ID']) && get_post_type($_POST['comment_post_ID']) == 'tour'){

			if(!it_can_rating_tour($_POST['comment_post_ID'])){
				wp_die( __( 'you have not permission to review this tour.', 'intravel' ) );
				exit;
			}

			if(is_user_logged_in()){
				$current_user = wp_get_current_user();
				$author_email = $current_user->user_email;
			}
			else{
				$author_email = $_POST['email'];
			}
			if($_POST['comment_parent'] == '0'){

				$args = array(
					'author_email' => $author_email,
					'post_id' => $_POST['comment_post_ID'],
					'count' => true,
					'parent' => 0,
				);

				if(get_comments($args)){
					wp_die( __( 'Can not review. You have reviewed this tour.', 'intravel' ) );
					exit;
				}

				if ( !isset($_POST['rating']) ||
					empty( $_POST['rating'] )
				) {
					wp_die( __( 'Please rate the tour.', 'intravel' ) );
					exit;
				}
			}
        }

		return $commentdata;
	}

	static function extend_comment_add_meta_box() {
		add_meta_box( 'title', __( 'Comment Metadata - Extend Comment' ), array(__CLASS__, 'extend_comment_meta_box'), 'comment', 'normal', 'high' );
	}

	static function extend_comment_meta_box ( $comment ) {
		$rating = get_comment_meta( $comment->comment_ID, 'rating', true );
		wp_nonce_field( 'extend_comment_update', 'extend_comment_update', false );
		?>
		<div>
			<label><?php _e( 'Please rate: ' ); ?></label>
			<span class="commentratingbox">
			<?php for( $i=1; $i <= 5; $i++ ) {
				echo '<span class="commentrating"><input type="radio" name="rating" id="rating" value="'. $i .'"';
				if ( $rating == $i ) echo ' checked="checked"';
				echo ' />'. $i .' </span>';
			}
			?>
			</span>
		</div>
		<?php
	}

	static function extend_comment_edit_metafields( $comment_id ) {
		if( ! isset( $_POST['extend_comment_update'] ) || ! wp_verify_nonce( $_POST['extend_comment_update'], 'extend_comment_update' ) ) return;

		if ( ( isset( $_POST['rating'] ) ) && ( $_POST['rating'] != '') ):
			$rating = wp_filter_nohtml_kses($_POST['rating']);
			update_comment_meta( $comment_id, 'rating', $rating );
		else :
			delete_comment_meta( $comment_id, 'rating');
		endif;
	}

	static function modify_comment( $text ){
		if( is_single() && get_post_type() == 'tour' && $commentrating = get_comment_meta( get_comment_ID(), 'rating', true ) ) {
            $commentrating = '<div class="iwt-rating">
                                    <div class="iw-star-rating">
                                        <span class="rating" style="width: ' .esc_attr(($commentrating / 5) * 100). '%"></span>
                                    </div>
                                </div>';
            $text = '<div class="comment-text">'.$text.'</div>' .$commentrating;
            return $text;
		} else {
			return $text;
		}
	}
}

IT_Comment::init();
