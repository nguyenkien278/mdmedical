<?php
/** Widget Tour Search **/
class IT_Widget_Search_Form extends WP_Widget {

    function __construct() {
        $widget_ops = array('classname' => 'widget_tour_search_form', 'description' => esc_html__('Display InTravel search form.', 'intravel'));
        $control_ops = array('width' => 400, 'height' => 350);

        parent::__construct('it-search-form', esc_html__('InTravel Search Form', 'intravel'), $widget_ops, $control_ops);
    }

    function widget( $args, $instance ) {
        $show_search_input = isset($instance['show_search_input']) ? esc_attr($instance['show_search_input']) : 1;
        $show_tour_types = isset($instance['show_tour_types']) ?  esc_attr($instance['show_tour_types']) : 1;
        $show_tour_destinations = isset($instance['show_tour_destinations']) ?  esc_attr($instance['show_tour_destinations']) : 1;
        $show_tour_start_date = isset($instance['show_tour_start_date']) ?  esc_attr($instance['show_tour_start_date']) : 1;
        $show_tour_price_slider = isset($instance['show_tour_price_slider']) ?  esc_attr($instance['show_tour_price_slider']) : 1;
        echo $args['before_widget'];
        $title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : __( 'Search Form', 'intravel' );
        $title = apply_filters( 'widget_title', $title, $instance, $this->id_base );
        if ( !empty( $title ) ) { echo $args['before_title'] . $title . $args['after_title']; }
        ?>
        <div class="tour-search-form-wrap">
            <form action="<?php echo esc_url(it_get_search_form_url()); ?>" method="post">
                <?php
                    if($show_search_input){
                        $s_value = isset($_GET['s']) ? esc_attr($_GET['s']) : '';
                        echo '<div class="form-group search-tour">';
                        echo '<i class="icon ion-android-search"></i>';
                        echo '<input type="text" name="s" placeholder="'.__('Enter your keywords').'" value="'.$s_value.'" class="form-control">';
                        echo '</div>';
                    }
                    elseif(isset($_GET['s']) && $_GET['s']){
                        echo '<input type="hidden" name="s" value="'.esc_attr($_GET['s']).'">';
                    }

                    if($show_tour_start_date){
                        $start_date_value = isset($_GET['start_date']) ? esc_attr($_GET['start_date']) : '';
                        echo '<div class="form-group search-tour">';
                        echo '<i class="icon ion-calendar"></i>';
                        echo '<input type="text" name="start_date" placeholder="'.__('Tour start date').'" value="'.$start_date_value.'" class="form-control has-date-picker">';
                        echo '</div>';
                    }
                    elseif(isset($_GET['start_date']) && $_GET['start_date']){
                        echo '<input type="hidden" name="destination" value="'.esc_attr($_GET['start_date']).'">';
                    }

                    if($show_tour_types){
                        $tour_types = get_terms( array(
                            'taxonomy' => 'tour_type',
                            'hide_empty' => false,
                        ) );
                        echo '<div class="form-group">';
                            echo '<select name="tour_type" class="form-control tour-select-search">';
                            echo '<option value="">'.__('All types', 'intravel').'</option>';
                            if($tour_types){
                                $tour_type_value = isset($_GET['tour_type']) ? esc_attr($_GET['tour_type']) : '';
                                foreach ($tour_types as $tour_type){
                                    echo '<option value="'.$tour_type->slug.'" '.($tour_type_value == $tour_type->slug ? 'selected' : '').'>'.$tour_type->name.'</option>';
                                }
                            }
                            echo '</select>';
                        echo '</div>';
                    }
                    elseif(isset($_GET['tour_type']) && $_GET['tour_type']){
                        echo '<input type="hidden" name="tour_type" value="'.esc_attr($_GET['tour_type']).'">';
                    }

                    if($show_tour_destinations){
                        $destinations = get_terms( array(
                            'taxonomy' => 'destination',
                            'hide_empty' => false,
                        ) );
                        echo '<div class="form-group">';
                            echo '<select name="destination" class="form-control tour-select-search">';
                            echo '<option value="">'.__('All destinations', 'intravel').'</option>';
                            if($destinations){
                                $destination_value = isset($_GET['destination']) ? esc_attr($_GET['destination']) : '';
                                foreach ($destinations as $destination){
                                    echo '<option value="'.$destination->slug.'" '.($destination_value == $destination->slug ? 'selected' : '').'>'.$destination->name.'</option>';
                                }
                            }
                            echo '</select>';
                        echo '</div>';
                    }
                    elseif(isset($_GET['destination']) && $_GET['destination']){
                        echo '<input type="hidden" name="destination" value="'.esc_attr($_GET['destination']).'">';
                    }
                ?>
                <?php
                if($show_tour_price_slider) {
                    /*wp_enqueue_script( 'wc-jquery-ui-touchpunch', INTRAVEL_PLUGIN_URL . '/assets/js/jquery-ui-touch-punch.min.js', array( 'jquery-ui-slider' ), INTRAVEL_VERSION, false );
                    wp_enqueue_script( 'it-price-slider', INTRAVEL_PLUGIN_URL . '/assets/js/price-slider.js', array( 'jquery-ui-slider', 'wc-jquery-ui-touchpunch' ), INTRAVEL_VERSION, false );
                    wp_localize_script( 'it-price-slider', 'intravel_price_slider_params', array(
                        'currency_symbol' 	=> it_get_currency_symbol(),
                        'currency_pos'      => it_get_option( 'currency_pos' ),
                        'min_price'			=> isset( $_GET['min_price'] ) ? esc_attr( $_GET['min_price'] ) : '',
                        'max_price'			=> isset( $_GET['max_price'] ) ? esc_attr( $_GET['max_price'] ) : ''
                    ) );*/

                    $min_price = isset($_GET['min_price']) ? esc_attr($_GET['min_price']) : '';
                    $max_price = isset($_GET['max_price']) ? esc_attr($_GET['max_price']) : '';

                    // Find min and max price in current result set
                    $prices = it_get_filtered_price();
                    $min = floor($prices->min_price);
                    $max = ceil($prices->max_price);
                    if ($min !== $max) {
                        if (it_is_taxable() && 'incl' === it_get_option('tax_display_tours', 'excl') && it_get_option('prices_include_tax', 'no') === 'no') {
                            $tax = it_get_tax();
                            $max = $max + $tax;
                        }
                        ?>
                        <div class="form-group">
                            <div class="tour_price_slider_wrapper">
                                <div class="tour_price_slider" style="display:none;"></div>
                                <div class="tour_price_slider_amount">
                                    <input type="text" class="tour_min_price" name="min_price"
                                           value="<?php echo esc_attr($min_price); ?>"
                                           data-min="<?php echo esc_attr(apply_filters('it_price_filter_widget_min_amount', $min)); ?>"
                                           placeholder="<?php echo esc_attr__('Min price', 'intravel'); ?>"/>
                                    <input type="text" class="tour_max_price" name="max_price"
                                           value="<?php echo esc_attr($max_price); ?>"
                                           data-max="<?php echo esc_attr(apply_filters('it_price_filter_widget_max_amount', $max)); ?>"
                                           placeholder="<?php echo esc_attr__('Max price', 'intravel'); ?>"/>
                                    <div class="price_label" style="display:none;">
                                        <?php echo __('Price:', 'intravel'); ?> <span class="from"></span> &mdash;
                                        <span class="to"></span>
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            </div>
                        </div>
                    <?php }
                }
                elseif(isset($_GET['min_price']) || isset($_GET['max_price'])){
                    if(isset($_GET['min_price']) && $_GET['min_price']){
                        echo '<input type="hidden" name="min_price" value="'.esc_attr($_GET['min_price']).'">';
                    }
                    if(isset($_GET['max_price']) && $_GET['max_price']){
                        echo '<input type="hidden" name="max_price" value="'.esc_attr($_GET['max_price']).'">';
                    }
                }
                ?>
                <div class="bt-submit"><button type="submit" class="btn"><?php echo __('Search', 'intravel'); ?></button></div>
            </form>
        </div>
        <?php
        echo $args['after_widget'];
    }

    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;
        $instance['title'] = strip_tags($new_instance['title']);
        $instance['show_search_input'] = strip_tags($new_instance['show_search_input']);
        $instance['show_tour_types'] = strip_tags($new_instance['show_tour_types']);
        $instance['show_tour_destinations'] = strip_tags($new_instance['show_tour_destinations']);
        $instance['show_tour_start_date'] = strip_tags($new_instance['show_tour_start_date']);
        $instance['show_tour_price_slider'] = strip_tags($new_instance['show_tour_price_slider']);

        return $instance;
    }

    function form( $instance ) {
        $instance = wp_parse_args( (array) $instance, array( 'title' => __( 'Search Form', 'intravel' ), 'show_search_input' => '1', 'show_tour_types' => '1', 'show_tour_destinations' => '1', 'show_tour_start_date' => '1', 'show_tour_price_slider' => '1') );
        $title = strip_tags($instance['title']);
        $show_search_input = esc_attr($instance['show_search_input']);
        $show_tour_types = esc_attr($instance['show_tour_types']);
        $show_tour_destinations = esc_attr($instance['show_tour_destinations']);
        $show_tour_start_date = esc_attr($instance['show_tour_start_date']);
        $show_tour_price_slider = esc_attr($instance['show_tour_price_slider']);
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'intravel'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('show_search_input')); ?>"><?php esc_html_e('Show search input:', 'intravel'); ?></label>
            <select class="widefat" id="<?php echo esc_attr($this->get_field_id('show_search_input')); ?>" name="<?php echo esc_attr($this->get_field_name('show_search_input')); ?>">
                <option value="1" <?php echo ($show_search_input == '1' ? 'selected' : '')?>><?php echo esc_html(__('Yes', 'intravel')); ?></option>
                <option value="0" <?php echo ($show_search_input == '0' ? 'selected' : '')?>><?php echo esc_html(__('No', 'intravel')); ?></option>
            </select>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('show_tour_types')); ?>"><?php esc_html_e('Show tour types:', 'intravel'); ?></label>
            <select class="widefat" id="<?php echo esc_attr($this->get_field_id('show_tour_types')); ?>" name="<?php echo esc_attr($this->get_field_name('show_tour_types')); ?>">
                <option value="1" <?php echo ($show_tour_types == '1' ? 'selected' : '')?>><?php echo esc_html(__('Yes', 'intravel')); ?></option>
                <option value="0" <?php echo ($show_tour_types == '0' ? 'selected' : '')?>><?php echo esc_html(__('No', 'intravel')); ?></option>
            </select>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('show_tour_destinations')); ?>"><?php esc_html_e('Show tour destinations:', 'intravel'); ?></label>
            <select class="widefat" id="<?php echo esc_attr($this->get_field_id('show_tour_destinations')); ?>" name="<?php echo esc_attr($this->get_field_name('show_tour_destinations')); ?>">
                <option value="1" <?php echo ($show_tour_destinations == '1' ? 'selected' : '')?>><?php echo esc_html(__('Yes', 'intravel')); ?></option>
                <option value="0" <?php echo ($show_tour_destinations == '0' ? 'selected' : '')?>><?php echo esc_html(__('No', 'intravel')); ?></option>
            </select>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('show_tour_start_date')); ?>"><?php esc_html_e('Show start date:', 'intravel'); ?></label>
            <select class="widefat" id="<?php echo esc_attr($this->get_field_id('show_tour_destinations')); ?>" name="<?php echo esc_attr($this->get_field_name('show_tour_start_date')); ?>">
                <option value="1" <?php echo ($show_tour_start_date == '1' ? 'selected' : '')?>><?php echo esc_html(__('Yes', 'intravel')); ?></option>
                <option value="0" <?php echo ($show_tour_start_date == '0' ? 'selected' : '')?>><?php echo esc_html(__('No', 'intravel')); ?></option>
            </select>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('show_tour_price_slider')); ?>"><?php esc_html_e('Show price slider:', 'intravel'); ?></label>
            <select class="widefat" id="<?php echo esc_attr($this->get_field_id('show_tour_price_slider')); ?>" name="<?php echo esc_attr($this->get_field_name('show_tour_price_slider')); ?>">
                <option value="1" <?php echo ($show_tour_price_slider == '1' ? 'selected' : '')?>><?php echo esc_html(__('Yes', 'intravel')); ?></option>
                <option value="0" <?php echo ($show_tour_price_slider == '0' ? 'selected' : '')?>><?php echo esc_html(__('No', 'intravel')); ?></option>
            </select>
        </p>
        <?php
    }
}

function it_seach_form_widget() {
    register_widget('IT_Widget_Search_Form');
}
add_action('widgets_init', 'it_seach_form_widget');