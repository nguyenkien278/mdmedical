<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

function it_get_option($key = '', $default = ''){
    $options = get_option('plg-intravel-options');
    if($key){
        if(isset($options[$key])){
            return $options[$key];
        }else{
            return $default;
        }
    }else{
        return $options;
    }
}

/**
 * Enables template debug mode.
 */
function it_template_debug_mode() {
    if ( ! defined( 'IT_TEMPLATE_DEBUG_MODE' ) ) {
        $status_options = it_get_option('status_options', array() );
        if ( ! empty( $status_options['template_debug_mode'] ) && current_user_can( 'manage_options' ) ) {
            define( 'IT_TEMPLATE_DEBUG_MODE', true );
        } else {
            define( 'IT_TEMPLATE_DEBUG_MODE', false );
        }
    }
}
add_action( 'after_setup_theme', 'it_template_debug_mode', 20 );

/**
 * Get template part
 *
 * IT_TEMPLATE_DEBUG_MODE will prevent overrides in themes from taking priority.
 *
 * @access public
 * @param mixed $slug
 * @param string $name (default: '')
 */
function it_get_template_part( $slug, $name = '' ) {
    $template = '';
    // Look in yourtheme/slug-name.php and yourtheme/intravel/slug-name.php
    if ( $name && ! IT_TEMPLATE_DEBUG_MODE ) {
        $template = locate_template( array( "{$slug}-{$name}.php", IT()->template_path() . "{$slug}-{$name}.php" ) );
    }

    // Get default slug-name.php
    if ( ! $template && $name && file_exists( IT()->plugin_path() . "/templates/{$slug}-{$name}.php" ) ) {
        $template = IT()->plugin_path() . "/templates/{$slug}-{$name}.php";
    }

    // Get default slug-name.php
    if ( ! $template && !$name && file_exists( IT()->plugin_path() . "/templates/{$slug}.php" ) ) {
        $template = IT()->plugin_path() . "/templates/{$slug}.php";
    }

    // If template file doesn't exist, look in yourtheme/slug.php and yourtheme/intravel/slug.php
    if ( ! $template && ! IT_TEMPLATE_DEBUG_MODE ) {
        $template = locate_template( array( "{$slug}.php", IT()->template_path() . "{$slug}.php") );
    }

    // Allow 3rd party plugins to filter template file from their plugin.
    $template = apply_filters( 'IT_get_template_part', $template, $slug, $name );
    if ( $template ) {
        load_template( $template, false );
    }
}


function is_it_endpoint_url( $endpoint = false ) {
    global $wp;

    $it_endpoints = IT()->query->get_query_vars();

    if ( $endpoint !== false ) {
        if ( ! isset( $it_endpoints[ $endpoint ] ) ) {
            return false;
        } else {
            $endpoint_var = $it_endpoints[ $endpoint ];
        }

        return isset( $wp->query_vars[ $endpoint_var ] );
    } else {
        foreach ( $it_endpoints as $key => $value ) {
            if ( isset( $wp->query_vars[ $key ] ) ) {
                return true;
            }
        }

        return false;
    }
}

/**
 * Add body classes for IT pages.
 *
 * @param  array $classes
 * @return array
 */
function it_body_class( $classes ) {
    $classes = (array) $classes;

    if ( is_intravel() ) {
        $classes[] = 'intravel';
        $classes[] = 'intravel-page';
    }

    foreach ( IT()->query->query_vars as $key => $value ) {
        if ( is_it_endpoint_url( $key ) ) {
            $classes[] = 'intravel-' . sanitize_html_class( $key );
        }
    }

    return array_unique( $classes );
}

/**
 * Adds extra post classes for tour.
 *
 * @since 1.0
 * @param array $classes
 * @param string|array $class
 * @param int $post_id
 * @return array
 */
function it_tour_post_class( $classes, $class = '', $post_id = '' ) {
    if ( ! $post_id || 'tour' !== get_post_type( $post_id ) ) {
        return $classes;
    }

    $tour = it_get_tour( $post_id );

    if ( $tour ) {
        if ( $tour->is_on_sale() ) {
            $classes[] = 'sale';
        }
        if ( $tour->is_featured() ) {
            $classes[] = 'featured';
        }
        if ($type = $tour->get_type() ) {
            $classes[] = "tour-type-" . $type->slug;
        }

        // add tag slugs
        $tags = get_the_terms( $tour->id, 'tour_tag' );
        if ( ! empty( $tags ) ) {
            foreach ( $tags as $key => $value ) {
                $classes[] = 'tour-tag-' . $value->slug;
            }
        }
    }

    if ( false !== ( $key = array_search( 'hentry', $classes ) ) ) {
        unset( $classes[ $key ] );
    }

    return $classes;
}

/**
 * Main function for returning tours
 *
 * @param mixed $the_tour Post object or post ID of the tour.
 * @param array $args (default: array()) Contains all arguments to be used to get this tour.
 * @return IT_Tour
 */
function it_get_tour( $the_tour = false, $args = array() ) {
    if ( false === $the_tour ) {
        $the_tour = $GLOBALS['post'];
    } elseif ( is_numeric( $the_tour ) ) {
        $the_tour = get_post( $the_tour );
    } elseif ( $the_tour instanceof IT_Tour ) {
        $the_tour = get_post( $the_tour->id );
    } elseif ( ! ( $the_tour instanceof WP_Post ) ) {
        $the_tour = false;
    }

    $the_tour = apply_filters( 'it_tour_object', $the_tour );

    return new IT_Tour( $the_tour, $args );
}

/**
 * Main function for returning tours
 *
 * @param mixed $the_tour Post object or post ID of the tour.
 * @param array $args (default: array()) Contains all arguments to be used to get this tour.
 * @return IT_Tour
 */
function it_get_detination($the_destination) {

    return new IT_Destination( $the_destination );
}

/**
 * Main function for returning order
 *
 * @param mixed $the_tour Post object or post ID of the order.
 * @param array $args (default: array()) Contains all arguments to be used to get this order.
 * @return IT_Booking
 */
function it_get_booking( $the_order = false, $args = array() ) {
    global $wp;
    if ( false === $the_order ) {
        $the_order = $wp->query_vars['booking-received'];
    } elseif ( is_numeric( $the_order ) ) {
        $the_order = get_post( $the_order );
    } elseif ( $the_order instanceof IT_Booking ) {
        $the_order = get_post( $the_order->id );
    } elseif ( ! ( $the_order instanceof WP_Post ) ) {
        $the_order = false;
    }

    $the_tour = apply_filters( 'it_booking_object', $the_order );

    return new IT_Booking( $the_tour, $args );
}

/**
 * When the_post is called, put tour data into a global.
 *
 * @param mixed $post
 * @return IT_Product
 */
function it_setup_tour_data( $post ) {
    unset( $GLOBALS['tour'] );

    if ( is_int( $post ) )
        $post = get_post( $post );

    if ( empty( $post->post_type ) || ! in_array( $post->post_type, array( 'tour') ) )
        return;

    $GLOBALS['tour'] = it_get_tour( $post );

    return $GLOBALS['tour'];
}
add_action( 'the_post', 'it_setup_tour_data' );


/**
 * Retrieve page ids - used for myaccount, edit_address, toour, cart, checkout, pay, view_order, terms. returns -1 if no page is found.
 *
 * @param string $page
 * @return int
 */
function it_get_page_id( $page ) {

    $page = apply_filters( 'intravel_get_' . $page . '_page_id', it_get_option($page . '_page_id' ) );

    return $page ? absint( $page ) : -1;
}

function it_get_page_permalink($page){
    $page_id   = it_get_page_id( $page );
    $permalink = $page_id ? get_permalink( $page_id ) : get_home_url();
    return apply_filters( 'intravel_get_' . $page . '_page_permalink', $permalink );
}

function it_get_booking_form_url(){
    if(it_use_woocommerce_payment()){
        return admin_url('admin-ajax.php?action=intravel_woocommerce_booking_tour');
    }
    else{
        return admin_url('admin-ajax.php?action=intravel_booking_tour');
    }
}

function it_get_checkout_form_url(){
    return admin_url('admin-ajax.php?action=intravel_booking_tour');
}

function it_get_search_form_url(){
    return admin_url('admin-ajax.php?action=intravel_search_tour');
}

/**
 * Get Base Currency Code.
 *
 * @return string
 */
function it_get_currency() {
    return apply_filters( 'intravel_currency', it_get_option('currency', 'USD') );
}

/**
 * Get full list of currency codes.
 *
 * @return array
 */
function it_get_currencies() {
    return array_unique(
        apply_filters( 'intravel_currencies',
            array(
                'AED' => __( 'United Arab Emirates Dirham', 'intravel' ),
                'ARS' => __( 'Argentine Peso', 'intravel' ),
                'AUD' => __( 'Australian Dollars', 'intravel' ),
                'BDT' => __( 'Bangladeshi Taka', 'intravel' ),
                'BGN' => __( 'Bulgarian Lev', 'intravel' ),
                'BRL' => __( 'Brazilian Real', 'intravel' ),
                'CAD' => __( 'Canadian Dollars', 'intravel' ),
                'CHF' => __( 'Swiss Franc', 'intravel' ),
                'CLP' => __( 'Chilean Peso', 'intravel' ),
                'CNY' => __( 'Chinese Yuan', 'intravel' ),
                'COP' => __( 'Colombian Peso', 'intravel' ),
                'CZK' => __( 'Czech Koruna', 'intravel' ),
                'DKK' => __( 'Danish Krone', 'intravel' ),
                'DOP' => __( 'Dominican Peso', 'intravel' ),
                'EGP' => __( 'Egyptian Pound', 'intravel' ),
                'EUR' => __( 'Euros', 'intravel' ),
                'GBP' => __( 'Pounds Sterling', 'intravel' ),
                'HKD' => __( 'Hong Kong Dollar', 'intravel' ),
                'HRK' => __( 'Croatia kuna', 'intravel' ),
                'HUF' => __( 'Hungarian Forint', 'intravel' ),
                'IDR' => __( 'Indonesia Rupiah', 'intravel' ),
                'ILS' => __( 'Israeli Shekel', 'intravel' ),
                'INR' => __( 'Indian Rupee', 'intravel' ),
                'ISK' => __( 'Icelandic krona', 'intravel' ),
                'JPY' => __( 'Japanese Yen', 'intravel' ),
                'KES' => __( 'Kenyan shilling', 'intravel' ),
                'KRW' => __( 'South Korean Won', 'intravel' ),
                'LAK' => __( 'Lao Kip', 'intravel' ),
                'MXN' => __( 'Mexican Peso', 'intravel' ),
                'MYR' => __( 'Malaysian Ringgits', 'intravel' ),
                'NGN' => __( 'Nigerian Naira', 'intravel' ),
                'NOK' => __( 'Norwegian Krone', 'intravel' ),
                'NPR' => __( 'Nepali Rupee', 'intravel' ),
                'NZD' => __( 'New Zealand Dollar', 'intravel' ),
                'PHP' => __( 'Philippine Pesos', 'intravel' ),
                'PKR' => __( 'Pakistani Rupee', 'intravel' ),
                'PLN' => __( 'Polish Zloty', 'intravel' ),
                'PYG' => __( 'Paraguayan Guaraní', 'intravel' ),
                'RON' => __( 'Romanian Leu', 'intravel' ),
                'RUB' => __( 'Russian Ruble', 'intravel' ),
                'SAR' => __( 'Saudi Riyal', 'intravel' ),
                'SEK' => __( 'Swedish Krona', 'intravel' ),
                'SGD' => __( 'Singapore Dollar', 'intravel' ),
                'THB' => __( 'Thai Baht', 'intravel' ),
                'TRY' => __( 'Turkish Lira', 'intravel' ),
                'TWD' => __( 'Taiwan New Dollars', 'intravel' ),
                'UAH' => __( 'Ukrainian Hryvnia', 'intravel' ),
                'USD' => __( 'US Dollars', 'intravel' ),
                'VND' => __( 'Vietnamese Dong', 'intravel' ),
                'ZAR' => __( 'South African rand', 'intravel' ),
                'PEN' => __( 'Peruvian Nuevo Sol', 'intravel' ),
            )
        )
    );
}

/**
 * Get Currency symbol.
 *
 * @param string $currency (default: '')
 * @return string
 */
function it_get_currency_symbol( $currency = '' ) {
    if ( ! $currency ) {
        $currency = it_get_currency();
    }

    $symbols = apply_filters( 'intravel_currency_symbols', array(
        'AED' => 'د.إ',
        'ARS' => '&#36;',
        'AUD' => '&#36;',
        'BDT' => '&#2547;&nbsp;',
        'BGN' => '&#1083;&#1074;.',
        'BRL' => '&#82;&#36;',
        'CAD' => '&#36;',
        'CHF' => '&#67;&#72;&#70;',
        'CLP' => '&#36;',
        'CNY' => '&yen;',
        'COP' => '&#36;',
        'CZK' => '&#75;&#269;',
        'DKK' => 'DKK',
        'DOP' => 'RD&#36;',
        'EGP' => 'EGP',
        'EUR' => '&euro;',
        'GBP' => '&pound;',
        'HKD' => '&#36;',
        'HRK' => 'Kn',
        'HUF' => '&#70;&#116;',
        'IDR' => 'Rp',
        'ILS' => '&#8362;',
        'INR' => '&#8377;',
        'ISK' => 'Kr.',
        'JPY' => '&yen;',
        'KES' => 'KSh',
        'KRW' => '&#8361;',
        'LAK' => '&#8365;',
        'MXN' => '&#36;',
        'MYR' => '&#82;&#77;',
        'NGN' => '&#8358;',
        'NOK' => '&#107;&#114;',
        'NPR' => '&#8360;',
        'NZD' => '&#36;',
        'PHP' => '&#8369;',
        'PKR' => '&#8360;',
        'PLN' => '&#122;&#322;',
        'PYG' => '&#8370;',
        'RMB' => '&yen;',
        'RON' => 'lei',
        'RUB' => '&#8381;',
        'SAR' => '&#x631;.&#x633;',
        'SEK' => '&#107;&#114;',
        'SGD' => '&#36;',
        'THB' => '&#3647;',
        'TRY' => '&#8378;',
        'TWD' => '&#78;&#84;&#36;',
        'UAH' => '&#8372;',
        'USD' => '&#36;',
        'VND' => '&#8363;',
        'ZAR' => '&#82;',
        'PEN' => 'S/',
    ) );

    $currency_symbol = isset( $symbols[ $currency ] ) ? $symbols[ $currency ] : '';

    return apply_filters( 'intravel_currency_symbol', $currency_symbol, $currency );
}


/**
 * Get the price format depending on the currency position.
 *
 * @return string
 */
function it_get_price_format() {
   $currency_pos = it_get_option('currency_pos' , 'left' );
    $format = '%1$s%2$s';
    switch ( $currency_pos ) {
        case 'left' :
            $format = '%1$s%2$s';
            break;
        case 'right' :
            $format = '%2$s%1$s';
            break;
        case 'left_space' :
            $format = '%1$s&nbsp;%2$s';
            break;
        case 'right_space' :
            $format = '%2$s&nbsp;%1$s';
            break;
    }

    return apply_filters( 'intravel_price_format', $format, $currency_pos );
}

/**
 * Return the thousand separator for prices.
 * @return string
 */
function it_get_price_thousand_separator() {
    $separator = stripslashes( it_get_option('price_thousand_sep', '.' ) );
    return $separator;
}

/**
 * Return the decimal separator for prices.
 * @return string
 */
function it_get_price_decimal_separator() {
    $separator = stripslashes( it_get_option('price_decimal_sep', ',' ) );
    return $separator ? $separator : '.';
}

/**
 * Return the number of decimals after the decimal point.
 * @return int
 */
function it_get_price_decimals() {
    return absint( it_get_option('price_num_decimals', 2 ) );
}

/**
 * Merge user defined arguments into defaults array.
 *
 * This function is used throughout WordPress to allow for both string or array
 * to be merged into another array.
 *
 * @since 2.2.0
 *
 * @param string|array $args     Value to merge with $defaults
 * @param array        $defaults Optional. Array that serves as the defaults. Default empty.
 * @return array Merged user defined values with defaults.
 */
function it_parse_args( $args, $defaults = '' ) {
    if ( is_object( $args ) )
        $r = get_object_vars( $args );
    elseif ( is_array( $args ) )
        $r =& $args;
    else
        wp_parse_str( $args, $r );

    if ( is_array( $defaults ) )
        return array_merge( $defaults, $r );
    return $r;
}

function it_price($price, $args = array()){
    extract( apply_filters( 'it_price_args', it_parse_args( $args, array(
        'ex_tax_label'       => false,
        'currency'           => '',
        'decimal_separator'  => it_get_price_decimal_separator(),
        'thousand_separator' => it_get_price_thousand_separator(),
        'decimals'           => it_get_price_decimals(),
        'price_format'       => it_get_price_format()
    ) ) ) );

    $negative        = $price < 0;
    $ori_price = $price;
    $price           = apply_filters( 'raw_intravel_price', floatval( $negative ? $price * -1 : $price ) );
    $price           = apply_filters( 'formatted_intravel_price', number_format( $price, $decimals, $decimal_separator, $thousand_separator ), $price, $decimals, $decimal_separator, $thousand_separator );

    if ( apply_filters( 'intravel_price_trim_zeros', false ) && $decimals > 0 ) {
        $price = it_trim_zeros( $price );
    }

    $return = ( $negative ? '-' : '' ) . sprintf( $price_format, it_get_currency_symbol( $currency ), $price );
    $return = ($ori_price == 0 || $ori_price == '' || $ori_price == '-') ? __('Free', 'indirectory'): $return;
    return apply_filters( 'it_price', $return, $price, $args );
}

/**
 * Trim trailing zeros off prices.
 *
 * @param mixed $price
 * @return string
 */
function it_trim_zeros( $price ) {
    return preg_replace( '/' . preg_quote( it_get_price_decimal_separator(), '/' ) . '0++$/', '', $price );
}

function it_get_payment_methods(){
    $payment_method = array(
        'submit_form' => __('Submit Form', 'intravel'),
        'paypal' => __('PayPal', 'intravel'),
    );

    if(it_use_woocommerce_payment()){
        $payment_method['woocommerce'] = __('Payment by Woocommerce', 'intravel');
    }

    return $payment_method;
}

function it_get_payment_method_title($payment_method){
    $payment_methods = it_get_payment_methods();
    if(isset($payment_methods[$payment_method])){
        return $payment_methods[$payment_method];
    }
    else{
        return '';
    }
}

function it_get_date_format(){
    return get_option('date_format');
}

function it_date($date){
    return date(it_get_date_format(), strtotime($date));
}

function it_get_placeholder_image(){
    return INTRAVEL_PLUGIN_URL.'/assets/img/placehold-image.png';
}

function it_get_completed_order_woocommerce_statuses(){
    $completed_order_woocommerce_statuses = (array)it_get_option('completed_order_woocommerce_statuses', array('completed'));
    return apply_filters( 'intravel_completed_order_woocommerce_statuses', $completed_order_woocommerce_statuses );
}

function it_get_cancelled_order_woocommerce_statuses(){
    $cancelled_order_woocommerce_statuses = (array)it_get_option('cancelled_order_woocommerce_statuses', array('cancelled'));

    return apply_filters( 'intravel_cancelled_order_woocommerce_statuses', $cancelled_order_woocommerce_statuses );
}

function it_get_onhold_order_woocommerce_statuses(){
    $onhold_order_woocommerce_statuses = (array)it_get_option('onhold_order_woocommerce_statuses', array('on-hold'));
    
    return apply_filters( 'intravel_onhold_order_woocommerce_statuses', $onhold_order_woocommerce_statuses );
}

function it_use_woocommerce_payment(){
    
    $use_woocommerce_payment = it_get_option('use_woocommerce_for_checkout');
    $use_woocommerce_payment = ($use_woocommerce_payment === 'on') ? true : false;
    return apply_filters( 'intravel_use_woocommerce_payment',  ($use_woocommerce_payment && class_exists('WooCommerce')));
}

/**
 * Get an image size.
 *
 * Variable is filtered by it_get_image_size_{image_size}.
 *
 * @param mixed $image_size
 * @return array
 */
function it_get_image_size( $image_size ) {
    if ( is_array( $image_size ) ) {
        $width  = isset( $image_size[0] ) ? $image_size[0] : '300';
        $height = isset( $image_size[1] ) ? $image_size[1] : '300';
        $crop   = isset( $image_size[2] ) ? $image_size[2] : 1;

        $size = array(
            'width'  => $width,
            'height' => $height,
            'crop'   => $crop
        );

        $image_size = $width . '_' . $height;

    } elseif ( in_array( $image_size, array( 'tour_thumbnail', 'tour_catalog', 'tour_single' ) ) ) {
        $size           = get_option( $image_size . '_image_size', array() );
        $size['width']  = isset( $size['width'] ) ? $size['width'] : '300';
        $size['height'] = isset( $size['height'] ) ? $size['height'] : '300';
        $size['crop']   = isset( $size['crop'] ) ? $size['crop'] : 0;

    } else {
        $size = array(
            'width'  => '300',
            'height' => '300',
            'crop'   => 1
        );
    }

    return apply_filters( 'intravel_get_image_size_' . $image_size, $size );
}

/**
 * Main function for returning customer
 *
 * @param $user_id.
 *
 * @return IT_Customer.
 */
function it_get_customer( $user_id = null ) {

    return new IT_Customer( $user_id );
}


function it_is_taxable(){
    return (!it_use_woocommerce_payment() && it_get_tax() > 0);
}

function it_get_tax($number = false){
    if($number){
        return (float)'0';
    }

    return (float)it_get_option('taxes');
}

function it_display_tax($number = false){
    if(!$number){
        $number = it_get_tax();
    }

    return $number.'%';
}

function it_get_destinations($args = array()){
    $default_args = array(
        'taxonomy' => 'destination',
        'orderby' => 'term_group',
        'hide_empty' => false,
        'number' => 0,
        'parent' => '',
    );

    $args = array_merge($default_args, $args);

    $destinations = get_terms($args);

    if(is_wp_error($destinations)){
        return array();
    }
    else
    {
        return $destinations;
    }
}

function it_get_tour_types($args = array()){
    $default_args = array(
        'taxonomy' => 'tour_type',
        'hide_empty' => false,
        'number' => 0,
        'parent' => '',
    );

    $args = array_merge($default_args, $args);

    $destinations = get_terms($args);

    if(is_wp_error($destinations)){
        return array();
    }
    else
    {
        return $destinations;
    }
}

function it_get_popular_tours($args = array()){

    global $wpdb;

    $default_args = array(
        'number' => 20,
        'offset' => 0,
        'destinations' => array(),
        'tour_types' => array(),
        'order_dir' => 'DESC',
        'include' => array(),
        'exclude' => array(),
    );

    $args = array_merge($default_args, $args);
    if(!$args['offset']){
        $args['offset'] = 0;
    }

    if(!$args['number']){
        $args['number'] = 20;
    }

    $where = array();

    $sql = "SELECT tour.ID FROM $wpdb->posts AS tour LEFT JOIN ";
    $sql .= "(SELECT meta.* FROM $wpdb->posts AS booking JOIN $wpdb->postmeta AS meta ON (meta.meta_key = 'intravel_tour' AND booking.ID = meta.post_id) ";
    $sql .= "JOIN $wpdb->postmeta AS meta1 ON (meta1.meta_key = 'intravel_status' AND (meta1.meta_value = 'pending' || meta1.meta_value = 'completed') AND booking.ID = meta.post_id) ";
    $sql .= "GROUP BY meta.`meta_id`) as booking ";
    $sql .= "ON (booking.meta_value = tour.ID) ";

    if($args['destinations'] || $args['tour_types']){
        $sql .= "JOIN $wpdb->term_relationships AS term_relationships ON term_relationships.object_id = tour.ID ";
        $sql .= "JOIN $wpdb->term_taxonomy AS term ON term.term_id = term_relationships.term_taxonomy_id ";
        $where[] = "term.term_ID IN (".implode(",", array_merge($args['destinations'], $args['tour_types'])).")";
    }

    $where[] = "(tour.post_status = 'publish' || tour.post_status = 'private')";
    $where[] = "tour.post_type = 'tour'";
    if($args['include']){
        $where[] = "tour.ID IN (".implode(",", $args['include']).")";
    }
    if($args['exclude']){
        $where[] = "tour.ID NOT IN (".implode(",", $args['exclude']).")";
    }
    $sql .= "WHERE (".implode(" AND ", $where).") ";
    $sql .= "GROUP BY tour.ID ";
    $sql .= "ORDER BY COUNT(booking.meta_id) ".$args['order_dir']." ";
    $sql .= "LIMIT {$args['offset']},{$args['number']}";
    $tours = $wpdb->get_results($sql);

    $tour_ids = array();
    foreach ($tours as $tour){
        $tour_ids[] = $tour->ID;
    }

    return $tour_ids;
}

function it_get_popular_destinations($args = array()){
    global $wpdb;

    $default_args = array(
        'number' => 20,
        'offset' => 0,
        'parent' => 0,
        'hide_empty' => true,
        'order_dir' => 'DESC',
        'include' => array(),
        'exclude' => array(),
    );

    $args = array_merge($default_args, $args);

    if(!$args['offset']){
        $args['offset'] = 0;
    }

    if(!$args['number']){
        $args['number'] = 20;
    }

    $sql = "SELECT term_taxonomy.term_id, SUM(meta1.meta_value) as total_sales FROM $wpdb->term_taxonomy AS term_taxonomy ";
    $sql .= (!$args['hide_empty'] ? "LEFT " : ""). "JOIN $wpdb->term_relationships AS term_relationships ON term_relationships.term_taxonomy_id = term_taxonomy.term_id ";
    $sql .= (!$args['hide_empty'] ? "LEFT " : ""). "JOIN $wpdb->posts AS tour ON (term_relationships.object_id = tour.ID AND (tour.post_status = 'publish' || tour.post_status = 'private' ) AND tour.post_type = 'tour') ";
    $sql .= (!$args['hide_empty'] ? "LEFT " : "")."JOIN $wpdb->postmeta AS meta1 ON meta1.meta_key = 'intravel_total_sales' AND tour.ID = meta1.post_id ";
    $where = array();
    $where[] = "term_taxonomy.taxonomy = 'destination'";
    if($args['parent']){
        $where[] = "term_taxonomy.parent = '".(int)$args['parent']."'";
    }
    if($args['include']){
        $where[] = "term_taxonomy.term_id IN (".implode(",", $args['include']).")";
    }
    if($args['exclude']){
        $where[] = "term_taxonomy.term_id NOT IN (".implode(",", $args['exclude']).")";
    }
    $sql .= "WHERE ".implode(" AND ", $where)." ";
    $sql .= "GROUP BY term_taxonomy.term_id ";
    $sql .= "ORDER BY total_sales ".$args['order_dir']." ";
    $sql .= "LIMIT {$args['offset']},{$args['number']}";
    $destinations = $wpdb->get_results($wpdb->prepare($sql, array()));
    $destination_ids = array();
    foreach ($destinations as $destination){
        $destination_ids[] = $destination->term_id;
    }

    return $destination_ids;
}

/**
 * Format decimal numbers ready for DB storage.
 *
 * Sanitize, remove locale formatting, and optionally round + trim off zeros.
 *
 * @param  float|string $number Expects either a float or a string with a decimal separator only (no thousands)
 * @param  mixed $dp number of decimal points to use, blank to use it_price_num_decimals, or false to avoid all rounding.
 * @param  bool $trim_zeros from end of string
 * @return string
 */
function it_format_decimal( $number, $dp = false, $trim_zeros = false ) {
    $locale   = localeconv();
    $decimals = array( it_get_price_decimal_separator(), $locale['decimal_point'], $locale['mon_decimal_point'] );

    // Remove locale from string
    if ( ! is_float( $number ) ) {
        $number = sanitize_text_field( str_replace( $decimals, '.', $number ) );
    }

    if ( $dp !== false ) {
        $dp     = intval( $dp == "" ? it_get_price_decimals() : $dp );
        $number = number_format( floatval( $number ), $dp, '.', '' );

        // DP is false - don't use number format, just return a string in our format
    } elseif ( is_float( $number ) ) {
        $number = sanitize_text_field( str_replace( $decimals, '.', strval( $number ) ) );
    }

    if ( $trim_zeros && strstr( $number, '.' ) ) {
        $number = rtrim( rtrim( $number, '0' ), '.' );
    }

    return $number;
}

/**
 * Function which handles the start and end of scheduled sales via cron.
 *
 * @access public
 */
function it_scheduled_sales() {
    global $wpdb;

    // Sales which are due to start
    $tour_ids = $wpdb->get_col( $wpdb->prepare( "
		SELECT postmeta.post_id FROM {$wpdb->postmeta} as postmeta
		LEFT JOIN {$wpdb->postmeta} as postmeta_2 ON postmeta.post_id = postmeta_2.post_id
		LEFT JOIN {$wpdb->postmeta} as postmeta_3 ON postmeta.post_id = postmeta_3.post_id
		WHERE postmeta.post_type = 'tour'
		AND postmeta.meta_key = 'intravel_discount_from'
		AND postmeta_2.meta_key = 'intravel_discount'
		AND postmeta.meta_value > 0
		AND postmeta.meta_value < %s
		AND postmeta_2.meta_value != ''
	", current_time( 'timestamp' ) ) );

    if ( $tour_ids ) {
        foreach ( $tour_ids as $tour_id ) {
            $regular_price = get_post_meta( $tour_id, 'intravel_regular_price', true );
            $children_regular_price = get_post_meta( $tour_id, 'intravel_children_regular_price', true );
            $discount = get_post_meta( $tour_id, 'intravel_discount', true );
            $sale_price = $regular_price - ($regular_price * (int)$discount /100);
            $children_sale_price = $regular_price - ($children_regular_price * (int)$discount /100);

            update_post_meta( $tour_id, 'intravel_price', $sale_price );
            update_post_meta( $tour_id, 'intravel_children_price', $children_sale_price );
            update_post_meta( $tour_id, 'intravel_discount', round( ( ( $regular_price - $sale_price ) / $regular_price ) * 100 ) );
        }

        delete_transient( 'it_tours_onsale' );
    }

    // Sales which are due to end
    $tour_ids = $wpdb->get_col( $wpdb->prepare( "
		SELECT postmeta.post_id FROM {$wpdb->postmeta} as postmeta
		LEFT JOIN {$wpdb->postmeta} as postmeta_2 ON postmeta.post_id = postmeta_2.post_id
		LEFT JOIN {$wpdb->postmeta} as postmeta_3 ON postmeta.post_id = postmeta_3.post_id
		WHERE postmeta.post_type = 'tour'
		AND postmeta.meta_key = 'intravel_discount_to'
		AND postmeta_2.meta_key = 'intravel_discount'
		AND postmeta.meta_value > 0
		AND postmeta.meta_value < %s
		AND postmeta_2.meta_value != ''
	", current_time( 'timestamp' ) ) );

    if ( $tour_ids ) {
        foreach ( $tour_ids as $tour_id ) {
            $regular_price = get_post_meta( $tour_id, 'intravel_regular_price', true );
            $children_regular_price = get_post_meta( $tour_id, 'intravel_children_regular_price', true );

            update_post_meta( $tour_id, 'intravel_price', $regular_price );
            update_post_meta( $tour_id, 'intravel_children_price', $children_regular_price );
            update_post_meta( $tour_id, 'intravel_discount_from', '' );
            update_post_meta( $tour_id, 'intravel_discount_to', '' );
            update_post_meta( $tour_id, 'intravel_discount', '' );
        }

        delete_transient( 'it_tours_onsale' );
    }
}
add_action( 'intravel_scheduled_sales', 'it_scheduled_sales' );


/**
 * Cancel all unpaid orders after held duration to prevent stock lock for those tours.
 *
 * @access public
 */
function it_cancel_unpaid_orders() {
    global $wpdb;

    $held_duration = it_get_option( 'hold_stock_hours', '50' );

    if ( $held_duration < 1)
        return;

    $date = date( "Y-m-d H:i:s", strtotime( '-' . absint( $held_duration ) . ' MINUTES', current_time( 'timestamp' ) ) );
    $unpaid_orders = $wpdb->get_col( $wpdb->prepare( "
		SELECT posts.ID
		FROM {$wpdb->posts} AS posts
		JOIN {$wpdb->postmeta} AS postmeta ON postmeta.post_id = posts.ID
		JOIN {$wpdb->postmeta} AS postmeta2 ON postmeta2.post_id = posts.ID
		WHERE 	posts.post_type = 'tour_booking'
		AND 	postmeta.meta_key = 'intravel_status'
		AND 	postmeta.meta_value = 'pending'
		AND 	postmeta2.meta_key = 'intravel_payment_method'
		AND 	postmeta2.meta_value = 'submit_form'
		AND 	posts.post_date < %s
	", $date ) );

    if ( $unpaid_orders ) {
        foreach ( $unpaid_orders as $unpaid_order ) {
            $booking = new IT_Booking($unpaid_order);
            $booking->changeStatus('cancelled');
            update_post_meta($unpaid_order , 'intravel_status', 'cancelled');
        }
    }

    wp_clear_scheduled_hook( 'intravel_cancel_unpaid_orders' );
    wp_schedule_single_event( time() + ( absint( $held_duration * 60 * 60 ) ), 'intravel_cancel_unpaid_orders' );
}
add_action( 'intravel_cancel_unpaid_orders', 'it_cancel_unpaid_orders' );

/**
 * Cancel all unpaid orders after held duration to prevent stock lock for those tours.
 *
 * @access public
 */
function it_paypal_cancel_unpaid_orders() {
    global $wpdb;

    $held_duration = it_get_option( 'paypal_hold_stock_hours', 1 );

    if ( $held_duration < 0.1)
        return;

    $date = date( "Y-m-d H:i:s", strtotime( '-' . absint( $held_duration ) . ' MINUTES', current_time( 'timestamp' ) ) );

    $unpaid_orders = $wpdb->get_col( $wpdb->prepare( "
		SELECT posts.ID
		FROM {$wpdb->posts} AS posts
		JOIN {$wpdb->postmeta} AS postmeta ON postmeta.post_id = posts.ID
		JOIN {$wpdb->postmeta} AS postmeta2 ON postmeta2.post_id = posts.ID
		WHERE 	posts.post_type = 'tour_booking'
		AND 	postmeta.meta_key = 'intravel_status'
		AND 	postmeta.meta_value = 'pending'
		AND 	postmeta2.meta_key = 'intravel_payment_method'
		AND 	postmeta2.meta_value = 'paypal'
		AND 	posts.post_date < %s
	", $date ) );

    if ( $unpaid_orders ) {
        foreach ( $unpaid_orders as $unpaid_order ) {
            $booking = new IT_Booking($unpaid_order);
            $booking->changeStatus('cancelled');
            update_post_meta($unpaid_order , 'intravel_status', 'cancelled');
        }
    }

    wp_clear_scheduled_hook( 'intravel_paypal_cancel_unpaid_orders' );
    wp_schedule_single_event( time() + ( absint( $held_duration * 60 * 60) ), 'intravel_paypal_cancel_unpaid_orders' );
}
add_action( 'intravel_paypal_cancel_unpaid_orders', 'it_paypal_cancel_unpaid_orders' );

/**
 * Create a page and store the ID in an option.
 *
 * @param mixed $slug Slug for the new page
 * @param string $option Option name to store the page's ID
 * @param string $page_title (default: '') Title for the new page
 * @param string $page_content (default: '') Content for the new page
 * @param int $post_parent (default: 0) Parent for the new page
 * @return int page ID
 */
function it_create_page( $slug, $option = '', $page_title = '', $page_content = '', $post_parent = 0 ) {
    global $wpdb;

    $option_value     = it_get_option( $option );

    if ( $option_value > 0 ) {
        $page_object = get_post( $option_value );

        if ( 'page' === $page_object->post_type && ! in_array( $page_object->post_status, array( 'pending', 'trash', 'future', 'auto-draft' ) ) ) {
            // Valid page is already in place
            return $page_object->ID;
        }
    }

    if ( strlen( $page_content ) > 0 ) {
        // Search for an existing page with the specified page content (typically a shortcode)
        $valid_page_found = $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE post_type='page' AND post_status NOT IN ( 'pending', 'trash', 'future', 'auto-draft' ) AND post_content LIKE %s LIMIT 1;", "%{$page_content}%" ) );
    } else {
        // Search for an existing page with the specified page slug
        $valid_page_found = $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE post_type='page' AND post_status NOT IN ( 'pending', 'trash', 'future', 'auto-draft' )  AND post_name = %s LIMIT 1;", $slug ) );
    }

    $valid_page_found = apply_filters( 'intravel_create_page_id', $valid_page_found, $slug, $page_content );

    if ( $valid_page_found ) {
        if ( $option ) {
            $intravel_options = get_option('plg-intravel-options');
            $intravel_options[$option] = $valid_page_found;
            update_option( 'plg-intravel-options', $intravel_options );
        }
        return $valid_page_found;
    }

    // Search for a matching valid trashed page
    if ( strlen( $page_content ) > 0 ) {
        // Search for an existing page with the specified page content (typically a shortcode)
        $trashed_page_found = $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE post_type='page' AND post_status = 'trash' AND post_content LIKE %s LIMIT 1;", "%{$page_content}%" ) );
    } else {
        // Search for an existing page with the specified page slug
        $trashed_page_found = $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE post_type='page' AND post_status = 'trash' AND post_name = %s LIMIT 1;", $slug ) );
    }

    if ( $trashed_page_found ) {
        $page_id   = $trashed_page_found;
        $page_data = array(
            'ID'             => $page_id,
            'post_status'    => 'publish',
        );
        wp_update_post( $page_data );
    } else {
        $page_data = array(
            'post_status'    => 'publish',
            'post_type'      => 'page',
            'post_author'    => 1,
            'post_name'      => $slug,
            'post_title'     => $page_title,
            'post_content'   => $page_content,
            'post_parent'    => $post_parent,
            'comment_status' => 'closed'
        );
        $page_id = wp_insert_post( $page_data );
    }

    if ( $option ) {
        $intravel_options = get_option('plg-intravel-options');
        $intravel_options[$option] = $page_id;
        update_option( 'plg-intravel-options', $intravel_options );
    }

    return $page_id;
}


/**
 * Function that returns an array containing the IDs of the tours that are on sale.
 *
 * @since 1.0
 * @access public
 * @return array
 */
function it_get_tour_ids_on_sale() {
    global $wpdb;

    // Load from cache
    $tour_ids_on_sale = get_transient( 'it_tours_onsale' );

    // Valid cache found
    if ( false !== $tour_ids_on_sale ) {
        return $tour_ids_on_sale;
    }

    $on_sale_posts = $wpdb->get_results( "
		SELECT post.ID, post.post_parent FROM `$wpdb->posts` AS post
		LEFT JOIN `$wpdb->postmeta` AS meta ON post.ID = meta.post_id
		LEFT JOIN `$wpdb->postmeta` AS meta2 ON post.ID = meta2.post_id
		WHERE post.post_type IN ( 'tour' )
			AND post.post_status = 'publish'
			AND meta.meta_key = 'intravel_sale_price'
			AND meta2.meta_key = 'intravel_price'
			AND CAST( meta.meta_value AS DECIMAL ) >= 0
			AND CAST( meta.meta_value AS CHAR ) != ''
			AND CAST( meta.meta_value AS DECIMAL ) = CAST( meta2.meta_value AS DECIMAL )
		GROUP BY post.ID;
	" );

    $tour_ids_on_sale = array_unique( array_map( 'absint', array_merge( wp_list_pluck( $on_sale_posts, 'ID' ), array_diff( wp_list_pluck( $on_sale_posts, 'post_parent' ), array( 0 ) ) ) ) );

    set_transient( 'it_tours_onsale', $tour_ids_on_sale, DAY_IN_SECONDS * 30 );

    return $tour_ids_on_sale;
}

/**
 * Function that returns an array containing the IDs of the featured tours.
 *
 * @since 1.0
 * @access public
 * @return array
 */
function it_get_featured_tour_ids() {

    // Load from cache
    $featured_tour_ids = get_transient( 'it_featured_tours' );

    // Valid cache found
    if ( false !== $featured_tour_ids )
        return $featured_tour_ids;

    $featured = get_posts( array(
        'post_type'      => array( 'tour'),
        'posts_per_page' => -1,
        'post_status'    => 'publish',
        'meta_query'     => array(
            /*array(
                'key' 		=> '_visibility',
                'value' 	=> array('catalog', 'visible'),
                'compare' 	=> 'IN'
            ),*/
            array(
                'key' 	=> 'intravel_featured',
                'value' => 'yes'
            )
        ),
        'fields' => 'id=>parent'
    ) );

    $tour_ids          = array_keys( $featured );
    $parent_ids           = array_values( array_filter( $featured ) );
    $featured_tour_ids = array_unique( array_merge( $tour_ids, $parent_ids ) );

    set_transient( 'it_featured_tours', $featured_tour_ids, DAY_IN_SECONDS * 30 );

    return $featured_tour_ids;
}

function it_get_status($key = null){
    $status = array(
        'pending' => __('Pending', 'intravel'),
        'onhold' => __('On hold', 'intravel'),
        'cancelled' => __('Cancelled', 'intravel'),
        'completed' => __('Completed', 'intravel'),
    );

    if($key){
        if(isset($status[$key])){
            return $status[$key];
        }
        return '' ;
    }

    return $status;
}

/**
 * Get filtered min price for current products.
 * @return int
 */
function it_get_filtered_price() {
    static $value = false;
    
    if($value === false){
        global $wpdb, $wp_the_query;

        $args       = $wp_the_query->query_vars;
        $tax_query  = isset( $args['tax_query'] ) ? $args['tax_query'] : array();
        $meta_query = isset( $args['meta_query'] ) ? $args['meta_query'] : array();

        if ( ! empty( $args['taxonomy'] ) && ! empty( $args['term'] ) ) {
            $tax_query[] = array(
                'taxonomy' => $args['taxonomy'],
                'terms'    => array( $args['term'] ),
                'field'    => 'slug',
            );
        }

        foreach ( $meta_query as $key => $query ) {
            if ( ! empty( $query['price_filter'] ) || ! empty( $query['rating_filter'] ) ) {
                unset( $meta_query[ $key ] );
            }
        }

        //$meta_query = new WP_Meta_Query( $meta_query );
        //$tax_query  = new WP_Tax_Query( $tax_query );

        //$meta_query_sql = $meta_query->get_sql( 'post', $wpdb->posts, 'ID' );
        //$tax_query_sql  = $tax_query->get_sql( $wpdb->posts, 'ID' );

        $sql  = "SELECT min( CAST( price_meta.meta_value AS UNSIGNED ) ) as min_price, max( CAST( price_meta.meta_value AS UNSIGNED ) ) as max_price FROM {$wpdb->posts} ";
        //$sql .= " LEFT JOIN {$wpdb->postmeta} as price_meta ON {$wpdb->posts}.ID = price_meta.post_id " . $tax_query_sql['join'] . $meta_query_sql['join'];
        $sql .= " LEFT JOIN {$wpdb->postmeta} as price_meta ON {$wpdb->posts}.ID = price_meta.post_id ";
        $sql .= " 	WHERE {$wpdb->posts}.post_type = 'tour'
					AND {$wpdb->posts}.post_status = 'publish'
					AND price_meta.meta_key IN ('" . implode( "','", array_map( 'esc_sql', apply_filters( 'it_price_filter_meta_keys', array( 'intravel_price' ) ) ) ) . "')
					AND price_meta.meta_value > '' ";
        //$sql .= $tax_query_sql['where'] . $meta_query_sql['where'];

        $value = $wpdb->get_row( $sql );
    }

    return $value;
}

function it_can_rating_destination($destination_id = null){
    $can_rating = it_get_option('who_can_rating_destination');
    $return = true;
    if($can_rating == 'register' && !is_user_logged_in()){
        $return = false;
    }
    if($return && $destination_id){
        if(isset($_COOKIE['rating_destination_53']) && $_COOKIE['rating_destination_'.$destination_id]){
            return 0;
        }
    }
    return $return;
}

function it_can_rating_tour($tour_id){
    $can_rating = it_get_option('who_can_review_tour');
    if(!$can_rating){
        if ( get_option( 'comment_registration' ) && !is_user_logged_in() ){
            return false;
        }
        else
        {
            return true;
        }
    }elseif($can_rating == 'register'){
        if (!is_user_logged_in()) {
            return false;
        }
        else{
            return true;
        }
    }elseif($can_rating == 'anyone'){
        return true;
    }
    elseif($can_rating == 'paid'){
        if(!is_user_logged_in()){
            return false;
        }
        else{
            $user_id = get_current_user_id();
            global $wpdb;
            $paid = $wpdb->get_var($wpdb->prepare("SELECT count(*) FROM $wpdb->posts as p 
                                            JOIN $wpdb->postmeta as mt1 ON (mt1.post_id = p.ID)
                                            JOIN $wpdb->postmeta as mt2 ON (mt2.post_id = p.ID)
                                            JOIN $wpdb->postmeta as mt3 ON (mt3.post_id = p.ID)
                                            WHERE p.post_type='tour_booking'
                                            AND p.post_status='publish'
                                            AND mt1.meta_key = 'intravel_user'
                                            AND mt2.meta_key = 'intravel_tour'
                                            AND mt3.meta_key = 'intravel_status'
                                            AND mt1.meta_value = %d
                                            AND mt2.meta_value = %d
                                            AND mt3.meta_value = %s"
            , $user_id, $tour_id, 'completed'));

            return $paid ? true : false;
        }
    }

    return false;
}

function it_add_endpoint_url($endpoint, $value , $permalink){
    if ( strstr( $permalink, '?' ) ) {
        $query_string = '?' . parse_url( $permalink, PHP_URL_QUERY );
        $permalink    = current( explode( '?', $permalink ) );
    } else {
        $query_string = '';
    }

    return trailingslashit( $permalink ) . $endpoint . '/' . $value . $query_string;
}



/**
 * Fix active class in nav for tours page.
 *
 * @param array $menu_items
 * @return array
 */
function it_nav_menu_item_classes( $menu_items ) {
    if ( ! is_tours() ) {
        return $menu_items;
    }

    $shop_page 		= (int) it_get_page_id('tours');
    $page_for_posts = (int) get_option( 'page_for_posts' );

    foreach ( (array) $menu_items as $key => $menu_item ) {
        $classes = (array) $menu_item->classes;

        // Unset active class for blog page
        if ( $page_for_posts == $menu_item->object_id ) {
            $menu_items[$key]->current = false;

            if ( in_array( 'current_page_parent', $classes ) ) {
                unset( $classes[ array_search('current_page_parent', $classes) ] );
            }

            if ( in_array( 'current-menu-item', $classes ) ) {
                unset( $classes[ array_search('current-menu-item', $classes) ] );
            }

            // Set active state if this is the shop page link
        } elseif ( is_tours() && $shop_page == $menu_item->object_id && 'page' === $menu_item->object ) {
            $menu_items[ $key ]->current = true;
            $classes[] = 'current-menu-item';
            $classes[] = 'current_page_item';

            // Set parent state if this is a product page
        } elseif ( is_singular( 'tour' ) && $shop_page == $menu_item->object_id ) {
            $classes[] = 'current_page_parent';
        }

        $menu_items[ $key ]->classes = array_unique( $classes );

    }

    return $menu_items;
}
add_filter( 'wp_nav_menu_objects', 'it_nav_menu_item_classes', 2 );

function it_get_marker_icons(){
    static $files = array();
    if(!$files){
        $marker_path = INTRAVEL_PLUGIN_DIR.'/assets/img/marker/';
        $_files = glob($marker_path.'*.{jpg,png}', GLOB_BRACE);
        foreach ($_files as $file){
            $files[] = basename($file);
        }
    }

    return $files;
}

function it_get_marker_url($icon = false){
    if(!$icon){
        return INTRAVEL_PLUGIN_URL.'/assets/img/marker/';
    }
    else{
        return INTRAVEL_PLUGIN_URL.'/assets/img/marker/'.$icon;
    }
}