<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! defined( 'INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID' ) )
	define( 'INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID', 'intravel_tour_booking_id' );

if ( ! defined( 'INTRAVEL_WOOCOMMERCE_BOOKING_SESSION_KEY' ) )
	define( 'INTRAVEL_WOOCOMMERCE_BOOKING_SESSION_KEY', 'intravel_booking_session_key' );

class IT_Woocommerce {

	private $tour_product_slug = 'intravel-tour-product';

	function init(){
		add_action('init', array( $this, 'setup'));
	}

	function setup(){

		add_filter('woocommerce_variation_is_purchasable', array($this, 'variation_is_purchasable'), 20, 2);
		add_action('woocommerce_before_calculate_totals', array( $this, 'add_custom_total_price'), 20, 1);
		add_action('woocommerce_before_order_itemmeta', array($this, 'before_order_itemmeta'), 20, 3);
		add_filter('woocommerce_cart_item_name', array( $this, 'cart_item_name'), 20, 3);
		//add_filter('woocommerce_order_item_name', array( $this, 'order_item_name'), 20, 3);
		//add_filter('woocommerce_cart_item_quantity', array( $this, 'cart_item_quantity'), 20, 3);
		//add_filter('woocommerce_checkout_cart_item_quantity', array( $this, 'checkout_item_quantity'), 20, 3);
		add_filter('woocommerce_cart_item_thumbnail', array($this, 'cart_item_thumbnail'), 20, 3);
		add_action('woocommerce_add_order_item_meta', array( $this, 'add_order_item_meta'), 10, 3);
		//add_action('woocommerce_checkout_order_processed', array( $this, 'checkout_order_processed'), 10, 2);
		add_filter( 'woocommerce_checkout_fields' , array($this, 'override_checkout_fields' ));
		//add_filter( 'woocommerce_countries_tax_or_vat' , array($this, 'countries_tax_or_vat' ));
		//add_filter( 'woocommerce_cart_tax_totals' , array($this, 'cart_tax_totals' ), 10, 2);
		//add_filter( 'woocommerce_cart_subtotal', array($this, 'cart_subtotal' ), 10, 3);
		//add_filter( 'woocommerce_cart_item_subtotal', array($this, 'cart_item_subtotal' ), 10, 3);
		//add_filter( 'woocommerce_cart_totals_order_total_html', array($this, 'cart_totals_order_total_html' ));

		//add_filter( 'woocommerce_product_is_taxable', array($this, 'product_is_taxable' ), 10, 2);
		//add_filter( 'woocommerce_get_order_item_totals', array($this, 'get_order_item_totals' ), 10, 2);
		//add_filter( 'woocommerce_order_amount_item_total', array($this, 'order_amount_item_total' ), 10, 3);


		add_action('woocommerce_checkout_order_processed', array( $this, 'checkout_order_processed'), 10, 2);
		add_action('woocommerce_order_status_changed', array( $this, 'order_status_changed'), 10, 3 );
		add_action('woocommerce_delete_order_items', array( $this, 'delete_order_items'), 10, 1);
		add_action('woocommerce_cart_updated', array( $this, 'cart_updated') );

	}

	function random_sku($prefix, $len = 6) {

		$str = '';

		for ($i = 0; $i < $len; $i++) {
			$str .= substr('0123456789', mt_rand(0, strlen('0123456789') - 1), 1);
		}

		return $prefix . $str;
	}

	function build_tour_variation_title($tour_title) {

		$variation_title = sprintf(__('Tour %s', 'intravel'), $tour_title);
		$variation_title .= __('booking', 'intravel');

		return $variation_title;
	}

	function build_tour_product_slug($tour_title) {

		$slug = sprintf($this->tour_product_slug . "-v-%s", URLify::filter($tour_title));

		return $slug;
	}

	function variation_is_purchasable($purchasable, $product_variation) {
		$object_class = get_class($product_variation);
		if ($object_class == 'WC_Product_Variation' && $product_variation->get_parent_id()) {
		    $parent = get_post($product_variation->get_parent_id());
		    if($parent->post_name == $this->tour_product_slug) {
                // mark purchasable as true even though we have not specified product price when creating product and variation, which allows us to set the price at the time product is added to cart.
                $purchasable = true;
            }
		}

		return $purchasable;
	}

	function create_tours_product() {

		$new_post = array(
			'post_title' 		=> esc_html__('InTravel Tours Product', 'intravel'),
			'post_content' 		=> esc_html__('This is a variable product used for intravel theme tour bookings processed with WooCommerce', 'intravel'),
			'post_status' 		=> 'publish',
			'post_name' 		=> $this->tour_product_slug,
			'post_type' 		=> 'product',
			'comment_status' 	=> 'closed'
		);

		$product_id 			= wp_insert_post($new_post);
		$skuu 					= $this->random_sku('intravel_tour_booking_', 6);

		update_post_meta($product_id, '_sku', $skuu );
        update_post_meta( $product_id, '_visibility', 'hidden');

		wp_set_object_terms($product_id, 'variable', 'product_type');

		$product_attributes = array(
			'intravel_tour' => array(
				'name'			=> 'intravel_tour',
				'value'			=> '',
				'is_visible' 	=> '1',
				'is_variation' 	=> '1',
				'is_taxonomy' 	=> '0'
			),
		);

		update_post_meta( $product_id, '_product_attributes', $product_attributes);

		return $product_id;
	}

	function get_tours_product_id() {

		global $wpdb;

		$sql = "SELECT Id FROM $wpdb->posts WHERE post_type='product' AND post_name = '%s' AND post_status='publish'";

		$id = $wpdb->get_var($wpdb->prepare($sql, $this->tour_product_slug));

		return intval($id);
	}

	function get_tours_product_variation_id($product_id, $tour_title) {

		global $wpdb;

		$product_name = $this->build_tour_product_slug($tour_title);

		$sql = "SELECT ID FROM $wpdb->posts WHERE post_type='product_variation' AND post_parent = %d AND post_name = '%s' AND post_status='publish'";

		$sql = $wpdb->prepare($sql, $product_id, $product_name);

		return $wpdb->get_var($sql);
	}

	function create_tour_product_variation($product_id, $tour_title, $tour_id) {

		$variation_title = $this->build_tour_variation_title($tour_title);

		$new_post = array(
			'post_title' 		=> $variation_title,
			'post_content' 		=> __('This is a intravel tour product variation', 'intravel'),
			'post_status' 		=> 'publish',
			'post_type' 		=> 'product_variation',
			'post_parent'		=> $product_id,
			'post_name' 		=> $this->build_tour_product_slug($tour_title),
			'comment_status' 	=> 'closed'
		);

		$variation_id 			= wp_insert_post($new_post);

		update_post_meta($variation_id, '_stock_status', 		'instock');
		update_post_meta($variation_id, '_sold_individually', 	'yes');
		update_post_meta($variation_id, '_virtual', 			'yes');
		update_post_meta($variation_id, '_manage_stock', 'no' );
		update_post_meta($variation_id, '_downloadable', 'no' );
		update_post_meta($variation_id, 'attribute_intravel_tour' , $tour_id);

		return $variation_id;
	}

	public function tour_booking($booking) {

		global $woocommerce;

		$tour = it_get_tour($booking->tour);
		$tour_title = $tour->get_title();

		$product_id = $this->get_tours_product_id();

		if (!isset($product_id) || empty($product_id)) {
			$product_id 			= $this->create_tours_product();
		}

		$variation_id 				= $this->get_tours_product_variation_id($product_id, $tour_title);

		if (!isset($variation_id) || empty($variation_id)) {
			$variation_id 			= $this->create_tour_product_variation($product_id, $tour_title, $tour->id);
		}

		if ($product_id > 0 && $variation_id > 0) {

			$cart_item_key 			= $woocommerce->cart->add_to_cart( $product_id, 1, $variation_id, null, null); // $cart_item_data);

			if (!is_user_logged_in()) {
				$woocommerce->session->set_customer_session_cookie(true);
			}
			$woocommerce->session->set(INTRAVEL_WOOCOMMERCE_BOOKING_SESSION_KEY . $cart_item_key, array(INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID => $booking->id));

			//$cart_item_meta = $woocommerce->session->get(INTRAVEL_WOOCOMMERCE_BOOKING_SESSION_KEY . $cart_item_key);
		}

		$booking->id;
	}

	function add_custom_total_price($cart_object) {
		// this is where we access our booking object, get price, and update cart with it to have things synced.
		global $woocommerce, $intravel_accommodation_helper, $intravel_tour_helper, $intravel_cruise_helper, $intravel_car_rental_helper;

		foreach ( $cart_object->cart_contents as $key => $value ) {
			$cart_item_meta = $woocommerce->session->get(INTRAVEL_WOOCOMMERCE_BOOKING_SESSION_KEY . $key);

			if ($cart_item_meta != null) {

				if (isset($cart_item_meta[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID])) {
					$tour_booking_id = intval($cart_item_meta[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID]);
					if ($tour_booking_id > 0) {
						$booking = it_get_booking($tour_booking_id);
						if ($booking != null) {
							$value['data']->set_price($booking->subprice);
						}
					}
				}
			}
		}
	}

	function cart_item_name($product_title, $cart_item, $cart_item_key){
		global $woocommerce;
		$item_data = $cart_item['data'];
		$object_class = get_class($item_data);

		if ( !$item_data || $item_data->get_slug() != $this->tour_product_slug || $object_class != 'WC_Product_Variation') {
			return $product_title;
		}

		$attributes = $item_data->get_variation_attributes();
		if ( ! $attributes ) {
			return $product_title;
		}

		$cart_item_meta = $woocommerce->session->get(INTRAVEL_WOOCOMMERCE_BOOKING_SESSION_KEY . $cart_item_key);

		if (isset($cart_item_meta[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID])) {

			$booking_id = $cart_item_meta[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID];
			$booking = it_get_booking($booking_id);

			if ($booking != null) {
				$tour = it_get_tour($booking->tour);
				$tour_date = it_date($booking->start_date);

				$product_title = '';
				$product_title .= sprintf(esc_html__('%s', 'intravel'), $tour->get_title()) . '<br />';
				$product_title .= sprintf(esc_html__('Tour date: %s', 'intravel'), $tour_date) . '<br />';
				$product_title .= sprintf(esc_html__('People: %d adults, %d children', 'intravel'), $booking->adult_ticket, $booking->children_ticket) . '<br />';

				return $product_title;
			}
		}
	}


	function order_item_name($product_title, $item) {
		$product_id   	= $item['product_id'];
		$variation_id   = $item['variation_id'];

		$variation = new WC_Product_Variation($variation_id);

		if (isset($item[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID])) {

			$booking_id = (int)$item[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID];
			$booking = it_get_booking($booking_id);

			if ($booking != null && $variation != null) {

				$tour = it_get_tour($booking->tour);
				$tour_date = it_date($booking->start_date);

				$product_title = '';
				$product_title .= sprintf(esc_html__('%s', 'intravel'), $tour->get_title()) . '<br />';
				$product_title .= sprintf(esc_html__('Tour date: %s', 'intravel'), $tour_date) . '<br />';
				$product_title .= sprintf(esc_html__('People: %d adults, %d children', 'intravel'), $booking->adult_ticket, $booking->children_ticket) . '<br />';
			}
		}

		return $product_title;
	}

	function checkout_item_quantity($quantity, $cart_item, $cart_item_key) {
		$quantity = $this->cart_item_quantity($quantity, $cart_item_key, $cart_item);
		return ' <strong class="product-quantity">' . sprintf( '&times; %s', $quantity ) . '</strong>';
	}

	function cart_item_quantity($quantity, $cart_item_key, $cart_item) {
		global $woocommerce;
		$item_data = $cart_item['data'];

		$object_class = get_class($item_data);

		if ( !$item_data || $item_data->get_slug() != $this->tour_product_slug || $object_class != 'WC_Product_Variation') {
			return $quantity;
		}

		$attributes = $item_data->get_variation_attributes();
		if ( ! $attributes ) {
			return $quantity;
		}

		$cart_item_meta = $woocommerce->session->get(INTRAVEL_WOOCOMMERCE_BOOKING_SESSION_KEY . $cart_item_key);

		if (isset($cart_item_meta[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID])) {

			$booking_id = $cart_item_meta[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID];
			$booking = it_get_booking($booking_id);

			if ($booking != null) {
				return $booking->quantity;
			}
		}

		return $quantity;
	}

	function cart_item_thumbnail($image, $cart_item, $cart_item_key) {

		if (isset($cart_item['data'])) {

			$object_class = get_class($cart_item['data']);

			if ($object_class == 'WC_Product_Variation' && isset($cart_item['data']) && $cart_item['data']->get_slug() != null) {

				global $woocommerce;

				if ($cart_item['data']->get_slug() == $this->tour_product_slug) {

					$cart_item_meta = $woocommerce->session->get(INTRAVEL_WOOCOMMERCE_BOOKING_SESSION_KEY . $cart_item_key);

					if ($cart_item_meta != null) {

						$tour_booking_id = intval($cart_item_meta[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID]);

						if ($tour_booking_id > 0) {

							$booking = it_get_booking($tour_booking_id);

							if ($booking != null) {
								$tour = it_get_tour($booking->tour);
								$image_title = $tour->get_title();
								$image_src = $tour->get_featured_image();
								if (empty($image_src)) {
									//$image_src = it_get_placeholder_image();
								}

								if (!empty($image_src)) {
									$image = "<img src='$image_src' alt='$image_title' />";
								}
							}
						}
					}
				}
			}
		}

		return $image;
	}


	function add_order_item_meta($item_id, $values, $cart_item_key ) {

		global $woocommerce;
		$cart_item_meta = $woocommerce->session->get(INTRAVEL_WOOCOMMERCE_BOOKING_SESSION_KEY . $cart_item_key);

		if ($cart_item_meta != null) {

			if (isset($cart_item_meta[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID])) {
				$tour_booking_id = intval($cart_item_meta[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID]);
				if ($tour_booking_id) {
					wc_add_order_item_meta($item_id, INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID, $tour_booking_id, true);
				}
			};
		}
	}

	function override_checkout_fields($fields) {
		global $woocommerce;
		if ($woocommerce->cart != null) {

			foreach ( $woocommerce->cart->cart_contents as $key => $value ) {
				$cart_item_meta = $woocommerce->session->get(INTRAVEL_WOOCOMMERCE_BOOKING_SESSION_KEY . $key);
				if ($cart_item_meta != null) {
					if (isset($cart_item_meta[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID])) {
						$tour_booking_id = $cart_item_meta[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID];
						$tour = it_get_tour($tour_booking_id);
						if($tour){
							$fields['billing']['billing_first_name']['default'] = $tour->first_name;
							$fields['billing']['billing_last_name']['default'] = $tour->last_name;
							$fields['billing']['billing_email']['default'] = $tour->email;
							$fields['billing']['billing_phone']['default'] = $tour->phone;
							//$fields['billing']['billing_address_1']['default'] = $tour->address;
						}

						break;
					}
				}
			}
		}

		return $fields;
	}


	// Show order details (from, to, transport type, dates etc) in order admin when viewing individual orders.
	function before_order_itemmeta($item_id, $item, $_product) {
        if(isset($item['product_id']) && $item['variation_id']){
            $product_id   	= $item['product_id'];
            $variation_id   = $item['variation_id'];
            $variation = new WC_Product_Variation($variation_id, array('parent_id' => $product_id));

            $tour_booking_id = wc_get_order_item_meta($item_id, INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID, true);
            if ($tour_booking_id) {

                $booking = it_get_tour($tour_booking_id);

                if ($booking != null && $variation != null) {
                    $tour = it_get_tour($booking->tour);
                    $tour_date = it_date($booking->start_date);
                    $item_text = '<br />';
                    $item_text .= sprintf(esc_html__('%s', 'intravel'), $tour->get_title()) . '<br />';
                    $item_text .= sprintf(esc_html__('Tour date: %s', 'intravel'), $tour_date) . '<br />';
                    $item_text .= sprintf(esc_html__('People: %d adults, %d children', 'intravel'), $booking->adult_ticket, $booking->children_ticket) . '<br />';

                    echo $item_text;
                }
            }
        }
	}

	function checkout_order_processed( $order_id, $posted ) {

		global $woocommerce;

		$order = new WC_Order( $order_id );

		if ($order != null) {

			$status = $order->get_status();

			if ($woocommerce->cart != null) {

				foreach ( $woocommerce->cart->cart_contents as $key => $value ) {

					$cart_item_meta = $woocommerce->session->get(INTRAVEL_WOOCOMMERCE_BOOKING_SESSION_KEY . $key);

					if ($cart_item_meta != null) {

						$booking_data = array();

						$booking_data['user'] = get_current_user_id();
						$booking_data['first_name'] = (isset($posted['billing_first_name']) ? sanitize_text_field($posted['billing_first_name']) : '');
						$booking_data['last_name'] = (isset($posted['billing_last_name']) ? sanitize_text_field($posted['billing_last_name']) : '');
						$booking_data['company'] = (isset($posted['billing_company']) ? sanitize_text_field($posted['billing_company']) : '');
						$booking_data['phone'] = (isset($posted['billing_phone']) ? sanitize_text_field($posted['billing_phone']) : '');
						$booking_data['email'] = (isset($posted['billing_email']) ? sanitize_text_field($posted['billing_email']) : '');
						$booking_data['address'] = (isset($posted['billing_address_1']) ? sanitize_text_field($posted['billing_address_1']) : '');
						$booking_data['address_2'] = (isset($posted['billing_address_2']) ? sanitize_text_field($posted['billing_address_2']) : '');
						$booking_data['town'] = (isset($posted['billing_city']) ? sanitize_text_field($posted['billing_city']) : '');
						$booking_data['zip'] = (isset($posted['billing_postcode']) ? sanitize_text_field($posted['billing_postcode']) : '');
						$booking_data['state'] = (isset($posted['billing_state']) ? sanitize_text_field($posted['billing_state']) : '');
						$booking_data['country'] = (isset($posted['billing_country']) ? sanitize_text_field($posted['billing_country']) : '');
						$booking_data['special_requirements'] = (isset($posted['special_requirements']) ? sanitize_text_field($posted['special_requirements']) : '');
						$booking_data['price'] = $order->get_total();
						$booking_data['woocommerce_order'] = $order_id;

						if (isset($cart_item_meta[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID])) {
							$tour_booking_id = intval($cart_item_meta[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID]);
							if ($tour_booking_id > 0) {
								IT_Booking::update_booking($tour_booking_id, $booking_data);
							}
						}
					}
				}
			}
		}
	}

	function order_status_changed( $order_id, $old_status, $new_status ) {

		$order = new WC_Order( $order_id );

		$items = $order->get_items();
		if ($items != null) {
			foreach ($items as $item_id => $item) {
				$tour_booking_id = wc_get_order_item_meta($item_id, INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID, true);
				if ($tour_booking_id) {
					$completed_order_woocommerce_statuses = it_get_completed_order_woocommerce_statuses();
					if(in_array($new_status, $completed_order_woocommerce_statuses)){
						$boooking = new IT_Booking($tour_booking_id);
						$boooking->changeStatus('completed');
					}

					$cancelled_order_woocommerce_statuses = it_get_cancelled_order_woocommerce_statuses();
					if(in_array($new_status, $cancelled_order_woocommerce_statuses)){
						$boooking = new IT_Booking($tour_booking_id);
						$boooking->changeStatus('cancelled');
					}

					$onhold_order_woocommerce_statuses = it_get_onhold_order_woocommerce_statuses();
					if(in_array($new_status, $onhold_order_woocommerce_statuses)){
						$boooking = new IT_Booking($tour_booking_id);
						$boooking->changeStatus('onhold');
					}
				}
			}
		}
	}

	function delete_order_items( $order_id ) {

		$order = new WC_Order( $order_id );

		if ($order != null) {

			$items = $order->get_items();

			foreach ($items as $item_id => $item) {

				$tour_booking_id = wc_get_order_item_meta($item_id, INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID, true);
				if ($tour_booking_id) {
					IT_Booking::delete_booking($tour_booking_id);
				}
			}
		}
	}

	function cart_updated() {
		global $woocommerce ;

		if ( isset( $_GET[ 'remove_item' ] ) ){

			$cart_item_key = $_GET[ 'remove_item' ];

			$cart_item_meta = $woocommerce->session->get(INTRAVEL_WOOCOMMERCE_BOOKING_SESSION_KEY . $cart_item_key);

			if ($cart_item_meta != null) {

				if (isset($cart_item_meta[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID])) {
					$tour_booking_id = intval($cart_item_meta[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID]);
					if ($tour_booking_id > 0) {
						IT_Booking::delete_booking($tour_booking_id);
					}
				}
			}
		}
	}

	function dynamically_create_tour_woo_order($booking_id) {

		$product_id 				= $this->get_tours_product_id();

		if (!isset($product_id) || empty($product_id)) {
			$product_id 			= $this->create_tours_product();
		}

		$booking = it_get_booking($booking_id);
		$tour = it_get_tour($booking->tour);
		$tour_title = $tour->get_title();

		$variation_id 				= $this->get_tours_product_variation_id($product_id, $tour_title);

		if (!isset($variation_id) || empty($variation_id)) {
			$variation_id 			= $this->create_tour_product_variation($product_id, $tour_title, $tour->id);
		}

		return $this->create_tour_woo_order($variation_id, $booking);
	}

	private function create_tour_woo_order($variation_id, $booking) {

		global $woocommerce;

		$order = wc_create_order();

		$product_variation = new WC_Product_Variation($variation_id);
		$product_variation->tax_status = false;

		$args = array();
		$args['totals']['total'] = $booking->price;
		$args['totals']['subtotal'] = $booking->subprice;
		$args['totals']['subtotal_tax'] = 0;
		$args['totals']['tax'] = 0;

		$item_id = $order->add_product($product_variation, 1, $args);

		if ($item_id > 0) {
			wc_add_order_item_meta($item_id, INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID, $booking->id, true);
		}

		$address_array = array(
			'first_name' => $booking->first_name,
			'last_name'  => $booking->last_name,
			'email'      => $booking->email,
			'phone'      => $booking->phone,
			'address_1'  => $booking->address,
		);

		$order->set_address( $address_array, 'billing' );
		$order->calculate_totals();
		$order->set_total($booking->price);
		//$order->payment_complete();

		if($booking->status == 'completed'){
			$order->update_status( 'completed' );
		}

		if ($woocommerce && $woocommerce->cart) {
			$woocommerce->cart->empty_cart();
		}

		update_post_meta($booking->id, 'intravel_woocommerce_order', $order->get_id());

		return $order->get_id();
	}

	function countries_tax_or_vat($return){
		global $woocommerce;

/*		$cart_item_meta = $woocommerce->session->get(INTRAVEL_WOOCOMMERCE_BOOKING_SESSION_KEY . $cart_item_key);
		if ($cart_item_meta != null) {

			if (isset($cart_item_meta[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID])) {
				$tour_booking_id = intval($cart_item_meta[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID]);
				if ($tour_booking_id > 0) {
					IT_Booking::delete_booking($tour_booking_id);
				}
			}
		}*/

		if(it_is_taxable()){
			return true;
		}

		return $return;
	}

	/**
	 * Get taxes, merged by code, formatted ready for output.
	 *
	 * @return array
	 */
	public function cart_tax_totals($tax_totals, $cart) {
		global $woocommerce;
		$carts = $cart->get_cart();
		foreach ( $carts as $cart_item_key => $cart_item ) {
			$cart_item_meta = $woocommerce->session->get(INTRAVEL_WOOCOMMERCE_BOOKING_SESSION_KEY . $cart_item_key);
			if ($cart_item_meta != null) {
				if (isset($cart_item_meta[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID])) {
					$tour_booking_id = intval($cart_item_meta[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID]);
					$tour_booking = it_get_booking($tour_booking_id);
					$tax_totals = array();
					$tax_totals[ '_standard' ] = new stdClass();
					$tax_totals[ '_standard' ]->tax_rate_id       = '';
					$tax_totals[ '_standard' ]->is_compound       = false;
					$tax_totals[ '_standard' ]->label             = __('Tax '.it_display_tax($tour_booking->tax), 'intravel');
					$tax_totals[ '_standard' ]->amount            = $tour_booking->tax;
					$tax_totals[ '_standard' ]->formatted_amount  = it_price($tour_booking->price - $tour_booking->subprice);

					return $tax_totals;
				}
			}
		}

		return $tax_totals;
	}

	public function cart_subtotal($cart_subtotal, $compound, $cart){
		global $woocommerce;
		$carts = $cart->get_cart();
		foreach ( $carts as $cart_item_key => $cart_item ) {
			$cart_item_meta = $woocommerce->session->get(INTRAVEL_WOOCOMMERCE_BOOKING_SESSION_KEY . $cart_item_key);
			if ($cart_item_meta != null) {
				if (isset($cart_item_meta[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID])) {
					$tour_booking_id = intval($cart_item_meta[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID]);
					$tour_booking = it_get_booking($tour_booking_id);

					return it_price($tour_booking->subprice);
				}
			}
		}

		return $cart_subtotal;
	}

	public function cart_item_subtotal($subtotal, $cart_item, $cart_item_key){
		global $woocommerce;
		$cart_item_meta = $woocommerce->session->get(INTRAVEL_WOOCOMMERCE_BOOKING_SESSION_KEY . $cart_item_key);

		if ($cart_item_meta != null) {

			if (isset($cart_item_meta[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID])) {
				$tour_booking_id = intval($cart_item_meta[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID]);
				$tour_booking = it_get_booking($tour_booking_id);
				return it_price($tour_booking->subprice);
			};
		}

		return $subtotal;
	}

	public function cart_totals_order_total_html($total){
		global $woocommerce;
		$carts = $woocommerce->cart->get_cart();
		foreach ( $carts as $cart_item_key => $cart_item ) {
			$cart_item_meta = $woocommerce->session->get(INTRAVEL_WOOCOMMERCE_BOOKING_SESSION_KEY . $cart_item_key);
			if ($cart_item_meta != null) {
				if (isset($cart_item_meta[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID])) {
					$tour_booking_id = intval($cart_item_meta[INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID]);
					$tour_booking = it_get_booking($tour_booking_id);
					return '<strong>'.it_price($tour_booking->price).'</strong>';
				}
			}
		}

		return $total;
	}

	public function product_is_taxable($taxable, $product){
		$tour_product_id = $this->get_tours_product_id();
		if ($tour_product_id == $product->get_id()) {
			return false;
		}

		return $taxable;
	}

	public function get_order_item_totals($total_rows, $order){
		$items = $order->get_items();
		if ($items != null) {
			foreach ($items as $item_id => $item) {
				$tour_booking_id = wc_get_order_item_meta($item_id, INTRAVEL_WOOCOMMERCE_TOUR_BOOKING_ID, true);
				if ($tour_booking_id) {
					$tour_booking = it_get_booking($tour_booking_id);
					$total_rows = array();
					$total_rows['cart_subtotal'] = array(
						'label' => __( 'Subtotal:', 'intravel' ),
						'value'	=> it_price($tour_booking->subprice)
					);

					$total_rows['tax'] = array(
						'label' => __('Tax '.it_display_tax($tour_booking->tax), 'intravel'),
						'value' => it_price($tour_booking->price - $tour_booking->subprice)
					);

					if ( $order->get_total() > 0 && $order->payment_method_title ) {
						$total_rows['payment_method'] = array(
							'label' => __( 'Payment Method:', 'intravel' ),
							'value' => $order->payment_method_title
						);
					}

					$total_rows['order_total'] = array(
						'label' => __( 'Total:', 'intravel' ),
						'value'	=> it_price($tour_booking->price)
					);

					return $total_rows;
				}
			}
		}

		return $total_rows;
	}
}

$IT_WC = new IT_Woocommerce();
$IT_WC->init();