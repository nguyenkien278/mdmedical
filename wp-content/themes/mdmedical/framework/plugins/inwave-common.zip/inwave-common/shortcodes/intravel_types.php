<?php

/*
 * Inwave_Heading for Visual Composer
 */
if (!class_exists('InTravel_Types')) {

    class InTravel_Types extends Inwave_Shortcode{

		protected $name = 'intravel_types';

		function init_params() {
            return array(
                'name' => __('Tour Types', 'inwavethemes'),
                'description' => __('Types of intravel', 'inwavethemes'),
                'base' => $this->name,
                'icon' => 'iw-default',
                'category' => 'Custom',
				'params' => array(
					array(
						"type" => "textfield",
						"heading" => __("Limit", "inwavethemes"),
						"param_name" => "limit",
						"value" => '6',
					),
					array(
						"type" => "textfield",
						"heading" => __("Offset", "inwavethemes"),
						"param_name" => "offset",
						"value" => '',
					),
					array(
						"type" => "textfield",
						"heading" => __("Include Type IDs", "inwavethemes"),
						"param_name" => "include_ids",
						"value" => '',
					),
					array(
						"type" => "textfield",
						"heading" => __("Exclude Type IDs", "inwavethemes"),
						"param_name" => "exclude_ids",
						"value" => '',
					),
					array(
						"type" => "textfield",
						"heading" => __("External link", "inwavethemes"),
						"param_name" => "ext_link",
						"value" => '',
					),
					array(
						"type" => "textfield",
						"heading" => __("External link text", "inwavethemes"),
						"param_name" => "ext_link_text",
						"value" => '',
					),
					array(
						"type" => "dropdown",
						"heading" => __("Hide Empty", 'inwavethemes'),
						"param_name" => "hide_empty",
						"value" => array(
							"0" => "No",
							"1" => "Yes",
						),
					),
					array(
						"type" => "dropdown",
						"heading" => __("Order By", 'inwavethemes'),
						"param_name" => "order_by",
						"value" => array(
							"No" => "none",
							"ID" => "id",
							"Name" => "name",
							"Count" => "count",
						),
					),
					array(
						"type" => "dropdown",
						"heading" => __("Order Direction", 'inwavethemes'),
						"param_name" => "order_dir",
						"value" => array(
							"Descending" => "DESC",
							"Ascending" => "ASC",
						),
					),
				)
            );
        }

        // Shortcode handler function for list Icon
        function init_shortcode($atts, $content = null) {

			if(!class_exists('inTravel')){
				return __('Please active the plugin inTravel', 'inwavethemes');
			}

			$atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( $this->name, $atts ) : $atts;

			$output = '';
            extract(shortcode_atts(array(
				//'title' => '',
				'limit' => '',
				'offset' => '',
				'hide_empty' => '',
				'include_ids' => '',
				'exclude_ids' => '',
				'order_by' => '',
				'order_dir' => '',
				'ext_link_text' => '',
				'ext_link' => '',
			), $atts));

			$args = array(
				'taxonomy' => 'tour_type',
				'orderby' => $order_by,
				'order' => $order_dir,
				'hide_empty' => (int)$hide_empty,
				'include' => ($include_ids ? explode(',', $include_ids) : array()),
				'exclude' => ($exclude_ids ? explode(',', $exclude_ids) : array()),
				'number' => ($limit ? $limit : 0),
				'offset' => ($offset ? $offset : ''),
			);

			$types = get_terms($args);
			$output .= '<div class="intravel-types">';
			$output .= '<ul class="intravel-types-list">';
			foreach ($types as $type){
				$icon_image = get_term_meta($type->term_id, 'intravel_icon_image', true);
				$output .= '<li><a href="'.get_term_link($type).'"><img src="'.esc_url($icon_image).'" alt=""></a></li>';
			}
			$output .= '</ul>';
			if ($ext_link){
				$output .= '<div class="ext-link"><a href="'.esc_url($ext_link).'">'.$ext_link_text.'</i></a></div>';
			}
			$output .= '</div>';

			return $output;
        }
	}
}

new InTravel_Types;
