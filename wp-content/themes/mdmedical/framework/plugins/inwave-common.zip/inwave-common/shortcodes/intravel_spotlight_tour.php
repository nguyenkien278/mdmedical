<?php

/*
 * Inwave_Heading for Visual Composer
 */
if (!class_exists('InTravel_Spotlight_Tour')) {

    class InTravel_Spotlight_Tour extends Inwave_Shortcode{

        protected $name = 'intravel_spotlight_tour';

        function init_params() {

            return array(
                'name' => __('Spotlight Tour', 'inwavethemes'),
                'description' => '',
                'base' => $this->name,
                'icon' => 'iw-default',
                'category' => 'Custom',
                'params' => array(
                    array(
                        'type' => 'textfield',
                        "holder" => "div",
                        "heading" => __("Video URL", "inwavethemes"),
                        "value" => "",
                        "param_name" => "url",
                    ),
                    array(
                        'type' => 'attach_image',
                        "heading" => __("Poster image", "inwavethemes"),
                        "param_name" => "poster",
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Chose ID Tour", 'inwavethemes'),
                        "description" => __("Example: 1,2,3,4,5,6", "inwavethemes"),
                        "param_name" => "id_tours",
                        "value" => '',
                    ),
                    array(
                        "type" => "textfield",
                        "class" => "",
                        "heading" => "Number of description words",
                        "param_name" => "desc_text_limit",
                        "value" => '6'
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Extra Class", "inwavethemes"),
                        "param_name" => "class",
                        "value" => "",
                        "description" => __("Write your own CSS and mention the class name here.", "inwavethemes"),
                    )
                )
            );
        }

        // Shortcode handler function for list Icon
        function init_shortcode($atts, $content = null) {

            if(!class_exists('inTravel')){
                return __('Please active the plugin inTravel', 'inwavethemes');
            }

            $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( $this->name, $atts ) : $atts;

            $output = '';
            extract(shortcode_atts(array(
                'url' => '',
                'poster' => '',
                'id_tours' => '',
                'desc_text_limit' => '',
                'class' => '',
            ), $atts));

            $id_tours = explode(',', $id_tours);

            $args = array(
                'numberposts' => '-1',
                'post__in' => $id_tours,
                'post_type' => 'tour',
                'public' => true,
            );

            $tours = get_posts($args);

            ob_start();
            ?>


            <div class="intravel-spotlight-tour <?php echo esc_attr($class ? ' '.$class : '')?>">
                <div class="row">
                    <div class="col-md-4 col-sm-12 col-xs-12 iw-video">
                        <?php if ($url) : ?>
                            <?php if($poster){
                                $poster = wp_get_attachment_image_src($poster, 'full');
                                $poster = $poster[0];
                                $poster = inwave_resize($poster, 600, 800, true);
                                echo '<div class="tour-type-item iw-effect-1"><img src="'.esc_url($poster).'" alt=""></div>';
                            } ?>
                            <button type="button" class="btn btn-info btn-lg open-popup" data-toggle="modal" data-target="#myModal"><i class="icon ion-ios-play-outline"></i></button>
                            <div class="iw-video-player modal fade" id="myModal" role="dialog">
                                <div class="modal-dialog">
                                    <div class="play-button"><i class="icon ion-ios-play-outline"></i></div>
                                    <?php if($url) : ?>
                                        <div class="video"><video src="<?php echo $url ?>"></video></div>
                                        <button type="button" class="btn btn-default close-popup" data-dismiss="modal"><i class="icon ion-close"></i></button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-8 col-sm-12 col-xs-12 spotlight-tours">
                        <div class="row">
                            <?php if($id_tours) : ?>
                                <?php
                                $i = 0;
                                foreach ($id_tours as $id_tour) :
                                    $tour = it_get_tour($id_tour);
                                    $get_the_excerpt = get_the_excerpt($tour->post);
                                    $content_parts = get_extended($tour->post->post_content);
                                    $content_main = isset($content_parts['main']) ? $content_parts['main'] : '';
                                    if(!empty($get_the_excerpt)) {
                                        $desc_tour = $get_the_excerpt;
                                    }
                                    else {
                                        $desc_tour = $content_main;
                                    }
                                    if($i > 0 && count($tours) > $i && $i % 3 == 0){
                                        echo  '</div>
                                         <div class="row">';
                                    }
                                    ?>
                                    <div class="col-md-4 col-sm-4 col-xs-12 tour-item iw-effect-img">
                                        <?php $image = wp_get_attachment_image_src(get_post_thumbnail_id($tour->post), 'full');
                                        if(!$image){
                                            $image_url = it_get_placeholder_image();

                                        }
                                        if($image){
                                            $image_url = $image[0];
                                            $image_url = inwave_resize($image_url, 900, 900, true);
                                        }
                                        ?>
                                        <div class="tour-info-wrap">
                                            <div class="tour-img effect-1"><img src="<?php echo esc_url($image_url); ?>" alt=""></div>
                                            <div class="tour-info">
                                                <h3><?php echo get_the_title($tour->post); ?></h3>
                                                <?php if($desc_tour) : ?>
                                                    <div class="tour-description"><?php echo wp_trim_words($desc_tour, $desc_text_limit) ?></div>
                                                <?php endif; ?>
                                                <div class="tour-detail"><a href="<?php echo esc_url(get_permalink()); ?>"><?php echo __("Discover ", "inwavethemes"); ?><i class="icon ion-arrow-right-c"></i></a></div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $i++;
                                endforeach;
                                wp_reset_postdata();?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php

            $html = ob_get_contents();
            ob_end_clean();

            return $html;
        }
    }
}

new InTravel_Spotlight_Tour;
