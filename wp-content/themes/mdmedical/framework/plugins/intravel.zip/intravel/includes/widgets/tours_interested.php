<?php
/**
 * Widget API: Inwave_Intravel_Tours_Interested class
 *
 * @package WordPress
 * @subpackage Widgets
 * @since 4.4.0
 */


class Inwave_Intravel_Tours_Interested extends WP_Widget {

    public function __construct() {
        $widget_ops = array(
            'description' => esc_html__( 'Display InTravel tours interested.' ),
            'customize_selective_refresh' => true,
        );
        parent::__construct( 'intravel_tours_interested', esc_html__( 'InTravel Tours Interested' ), $widget_ops );
    }

    public function widget( $args, $instance ) {

        $limit = isset($instance['limit']) ?  strip_tags($instance['limit']) : 3;
        $order = isset($instance['order']) ? strip_tags($instance['order']) : 'tour_type';
        global $post;
        $id = $post->ID;
        $tag_slug = array();
        $type_slug = array();

        $tour_types = wp_get_post_terms($post->ID, 'tour_type');
        if($tour_types){
            foreach($tour_types as $tour_type){
                $type_slug[] = $tour_type->slug;
            }
        }
        $tour_tags = wp_get_post_terms($post->ID, 'tour_tag');
        if($tour_tags) {
            foreach($tour_tags as $tour_tag){
                $tag_slug[] = $tour_tag->slug;
            }
        }
        $args_post = array(
            'posts_per_page' => $limit,
            'post_status' => 'publish',
            'post_type' => 'tour',
            'post__not_in' => array($id),
            'suppress_filters' => function_exists('icl_object_id') ? false : true
        );

        if(!empty($type_slug) && $order == 'all'){
            $args_post['tax_query'] = array(
                'relation' => 'AND',
            );
            $args_post['tax_query'] = array(
                'taxonomy' => 'tour_type',
                'field' => 'slug',
                'terms' => $type_slug
            );
            $args_post['tax_query'] = array(
                'taxonomy' => 'tour_tag',
                'field' => 'slug',
                'terms' => $tag_slug
            );
        }
        if(!empty($type_slug) && $order == 'tour_type'){
            $args_post['tax_query'] = array(
                'taxonomy' => 'tour_type',
                'field' => 'slug',
                'terms' => $type_slug
            );
        }
        if(!empty($tag_slug)  && $order == 'tour_tag'){
            $args_post['tax_query'] = array(
                'taxonomy' => 'tour_tag',
                'field' => 'slug',
                'terms' => $tag_slug
            );
        }

        $tours = get_posts($args_post);

        /** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
        $title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : __( 'You may also interested', 'intravel' );
        $title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

        echo $args['before_widget'];
        if ( $title ) {
            echo $args['before_title'] . $title . $args['after_title'];
        }
        ?>
        <div class="iw-travel-tours-interested-widget iwtravel-detail-sidebar">
            <div class="iw-interested">
                <?php foreach ($tours as $tour) :
                    global $post;
                    if(!is_object($tour)){
                        $post = get_post($tour);
                    }
                    else{
                        $post = $tour;
                    }
                    $tour = it_get_tour($tour);
                    $destinations = $tour->get_destinations();
                    $tour_type = $tour->get_types();
                    $tour_tag = $tour->get_tour_tag();
                    ?>
                    <div class="iw-tour-item iw-effect-img">
                        <?php
                        $img = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');
                        $img_src = count($img) ? $img[0] : '';
                        $img_src = inwave_resize($img_src, 370, 255, true);
                        ?>
                        <?php if ($img){ ?>
                            <div class="image-wrap effect-1">
                                <img src="<?php echo esc_url($img_src); ?>" alt=""/>
                                <div class="icon-action">
                                    <!--	<a class="iw-to-detail theme-bg" href="<?php echo get_permalink(); ?>">
                                                            <?php esc_html_e('Book now', 'inevent'); ?>
                                                        </a> -->
                                    <a href="<?php echo get_permalink(); ?>" class="button-booking-tour theme-bg"><?php echo esc_html__('Book now', 'intravel') ?></a>
                                </div>
                            </div>
                        <?php } ?>
                        <div class="info-wrap">
                            <div class="info-left">
                                <h3 class="title"><a class="theme-color-hover" href="<?php echo get_permalink(); ?>"><?php echo get_the_title(); ?></a></h3>
                                <div class="post-meta">
                                    <ul>
                                        <?php if ($destinations) : ?>
                                            <li class="destinations">
                                                <i class="fa fa-map-marker" aria-hidden="true"> </i>
                                                <?php
                                                if ($destinations){
                                                    $destination_html = array();
                                                    foreach($destinations as $destination){
                                                        $destination_html[] = '<a href="'.esc_url(get_term_link($destination->slug, 'destination')).'" class="destination">'.$destination->name.'</a>';
                                                    }
                                                    echo implode(' / ', $destination_html);
                                                }
                                                ?>
                                            </li>
                                        <?php endif ?>
                                        <?php if ($tour ->get_duration()) : ?>
                                            <li>
                                                <span class="duration"><i class="fa fa-clock-o"></i> <?php echo $tour ->get_duration(); ?></span>
                                            </li>
                                        <?php endif ?>
                                    </ul>
                                </div>
                            </div>
                            <div class="tour-info-footer">
                                <?php if ($tour->get_price()) : ?>
                                    <div class="tour-price">
                                        <span class="theme-bg"><?php echo it_price($tour->get_price()); ?></span>
                                    </div>
                                <?php endif; ?>
                                <?php if ($tour->get_rating_html()){
                                    echo '<div class="tour-rate">'.$tour->get_rating_html().'</div>';
                                } ?>
                                <div style="clear: both"></div>
                            </div>
                            <div style="clear: both"></div>
                        </div>
                    </div>
                <?php endforeach;
                wp_reset_postdata(); ?>
            </div>
        </div>

        <?php
        echo $args['after_widget'];
    }

    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title'] = strip_tags($new_instance['title']);
        $instance['limit'] = strip_tags($new_instance['limit']);
        $instance['order'] = strip_tags($new_instance['order']);
        return $instance;
    }

    public function form( $instance ) {
        $instance = wp_parse_args( (array) $instance, array( 'title' => '', 'limit' => 3 ) );
        $order = isset($instance['order']) ? strip_tags($instance['order']) : 'tour_type';
        $title = strip_tags($instance['title']);
        $limit = esc_attr($instance['limit']);
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'inevent'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('limit')); ?>"><?php esc_html_e('Limit:', 'inevent'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('limit')); ?>" name="<?php echo esc_attr($this->get_field_name('limit')); ?>" type="text" value="<?php echo esc_attr($limit); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('order')); ?>"><?php esc_html_e('Order:', 'inevent'); ?></label>
            <select class="widefat" id="<?php echo esc_attr($this->get_field_id('order')); ?>" name="<?php echo esc_attr($this->get_field_name('order')); ?>">
                <option value="all" <?php echo ($order == 'all' ? 'selected' : '')?>><?php echo esc_html(__('All', 'inevent')); ?></option>
                <option value="tour_type" <?php echo ($order == 'tour_type' ? 'selected' : '')?>><?php echo esc_html(__('Tour Type', 'inevent')); ?></option>
                <option value="tour_tag" <?php echo ($order == 'tour_tag' ? 'selected' : '')?>><?php echo esc_html(__('Tour Tag', 'inevent')); ?></option>
            </select>
        </p>
        <?php
    }

}

function intravel_tours_widget_interested() {
    register_widget('Inwave_Intravel_Tours_Interested');
}
add_action('widgets_init', 'intravel_tours_widget_interested');