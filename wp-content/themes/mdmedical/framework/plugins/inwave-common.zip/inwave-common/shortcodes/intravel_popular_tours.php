<?php

/*
 * Travel Tours for Visual Composer
 */
if (!class_exists('inTravel_Popular_Tours')) {

    class inTravel_Popular_Tours extends Inwave_Shortcode{

        protected $name = 'intravel_popular_tours';
        protected $count;

        function init_params() {

            $this->count = 0;

            return array(
                "name" => __('Travel Popular Tours', 'inwavethemes'),
                "base" => $this->name,
                'category' => 'Custom',
                "description" => '',
                'icon' => 'iw-default',
                "params" => array(
					array(
						"type" => "textfield",
						"heading" => __("Limit", "inwavethemes"),
						"param_name" => "limit",
						"value" => '5',
					),
                    array(
                        "type" => "textfield",
                        "heading" => __("Extra Class", "inwavethemes"),
                        "param_name" => "class",
                        "value" => "",
                        "description" => __("Write your own CSS and mention the class name here.", "inwavethemes"),
                    )
                )
            );
        }

        // Shortcode handler function for item
        function init_shortcode($atts, $content = null) {

			if(!class_exists('inTravel')){
				return __('Please active the plugin inTravel', 'inwavethemes');
			}

            $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( $this->name, $atts ) : $atts;

            extract(shortcode_atts(array(
                'limit' => '',
                'class' => '',
            ), $atts));

			$tours = it_get_popular_tours(array(
				'number' => ($limit ? $limit : 3),
			));
			?>
			<div class="intravel-popular-tours">
			<div class="row">
				<?php
				$i = 0;
				foreach ($tours as $tour) {
				global $post;
				if(!is_object($tour)){
					$post = get_post($tour);
				}
				else{
					$post = $tour;
				}

				$tour = it_get_tour($tour);
				$price = $tour->price;
				$tour_type = $tour->get_type();
				?>
				<?php if ($i==0){ ?>
				<div class="col-md-6 col-sm-12 col-xs-12 large">
					<?php } else { ?>
					<div class="col-md-3 col-sm-6 col-xs-12 small">
						<?php } ?>
						<div class="iw-tour-item">
							<div class="image-wrap">
								<?php
								$large_image_url = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');
								$tour_image = count($large_image_url) ? $large_image_url[0] : '';
								$tour_image = inwave_resize($tour_image, 600, 600, true);
								?>
								<!--<img src="<?php //echo esc_url($large_image_url[0]); ?>" alt=""/>-->
								<a class="iw-to-detail" href="<?php echo get_permalink(); ?>">
                                    <div class="img-tour" style="background: url('<?php echo esc_url($tour_image) ?>') no-repeat center center / cover "></div>
								</a>
							</div>
							<div class="info-wrap">
								<div class="info-tour">
									<div class="post-meta">
										<div class="tour-type">
											<?php echo $tour_type->name; ?>
										</div>
									</div>
									<h3 class="title"><a class="" href="<?php echo get_permalink(); ?>"><?php echo the_title(); ?></a></h3>
								</div>
								<!--
											<div class="discount">
												<?php echo $tour->discount; ?>
											</div>
											<?php if ($price) : ?>
												<div class="tour-price right theme-bg">
													<span><?php echo $price; ?></span>
												</div>
											<?php endif; ?>

										-->
								<div style="clear: both"></div>
							</div>
						</div>
					</div>
					<?php
					$i++;
					}
					?>
				</div>
			</div>
			<?php
        }
    }
}

new inTravel_Popular_Tours;