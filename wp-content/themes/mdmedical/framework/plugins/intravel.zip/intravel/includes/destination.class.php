<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
class IT_Destination {

	/**
	 * The destination (term) term_id.
	 *
	 * @var int
	 */
	public $term_id = 0;

	/**
	 * $term Stores term data.
	 *
	 * @var $post WP_Term
	 */
	public $term = null;

	/**
	 * Constructor gets the post object and sets the ID for the loaded tour.
	 *
	 * @param int|IT_Destination|object $term_id, term object
	 */
	public function __construct( $destination ) {
		if ( is_numeric( $destination ) ) {
			$this->term_id   = absint( $destination );
			$this->term = get_term( $destination, 'destination' );
		} elseif ( $destination instanceof IT_Destination ) {
			$this->id   = absint( $destination->ter_id );
			$this->term = $destination->term;
		} elseif ( isset( $destination->term_id ) ) {
			$this->term_id   = absint( $destination->term_id );
			$this->term = $destination;
		}
	}


	/**
	 * __isset function.
	 *
	 * @param mixed $key
	 * @return bool
	 */
	public function __isset( $key ) {
		return metadata_exists( 'destination', $this->term_id, 'intravel_' . $key );
	}

	/**
	 * __get function.
	 *
	 * @param string $key
	 * @return mixed
	 */
	public function __get( $key ) {
		$value = get_term_meta( $this->term_id, 'intravel_' . $key, true );

		if ( false !== $value ) {
			$this->$key = $value;
		}

		return $value;
	}

	/**
	 * Get the tour's post data.
	 *
	 * @return object
	 */
	public function get_term_data() {
		return $this->term;
	}

	/**
	 * Return the tour ID
	 * @return int tour (post) ID
	 */
	public function get_term_id() {

		return $this->term_id;
	}
	
	

	public function get_info(){
		$info = array();
		if($this->info){
			$info = (array)$this->info;
			foreach ($info as $key=>$info_item){
				$info[$key] = explode("|", $info_item);
			}
		}
		
		return $info;
	}

	public function get_map(){
		$map = $this->map;
		if($map){
			$map = json_decode($map);
		}

		return $map;
	}

	public function get_average_rating() {

		$average_rating = get_term_meta($this->term_id, 'average_rating', true);
		if($average_rating){
			return $average_rating;
		}
		else{
			return 0;
		}
	}

	public function get_rating_html( $check_can_rating = false, $rating = null ) {
		$rating_html = '';

		if ( ! is_numeric( $rating ) ) {
			$rating = $this->get_average_rating();
		}
		$rating = floor($rating);
		//$rating = 7;
		if($check_can_rating && it_can_rating_destination($this->term_id)){
			wp_enqueue_style('barrating-fontawesome-stars');
			wp_enqueue_script('barrating');
			$rating_html .= '<select id="destination-rating" name="rating" autocomplete="off" data-destination="'.esc_attr($this->term_id).'" data-rating="'.esc_attr($rating).'">
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
        	</select>';
			$total_rating = get_term_meta($this->term_id, 'total_rating', true);
			$rating_html .= '<span>'.sprintf(_n('(%d rating)', '(%d ratings)', $total_rating, 'intravel'), $total_rating).'</span>';
		}
		else
		{
            $total_rating = get_term_meta($this->term_id, 'total_rating', true);
			$rating_html  = '<div class="star-rating">';
			$rating_html .= '<span class="rating" style="width:' . ( ( $rating / 5 ) * 100 ) . '%"></span>';
			$rating_html .= '</div>';
            $rating_html .= '<span>'.sprintf(_n('(%d rating)', '(%d ratings)', $total_rating, 'intravel'), $total_rating).'</span>';
			$rating_html .= '<div class="clear"></div>';
		}
		return apply_filters( 'intravel_destination_get_rating_html', $rating_html, $rating );
	}

	public function _get_rating_html( $rating = null ) {
		$rating_html = '';

		if ( ! is_numeric( $rating ) ) {
			$rating = $this->get_average_rating();
		}
		if ( $rating > 0 ) {
			$rating_html  = '<div class="star-rating">';
			$rating_html .= '<span class="rating" style="width:' . ( ( $rating / 5 ) * 100 ) . '%"></span>';
			$rating_html .= '</div>';
			$rating_html .= '<div class="clear"></div>';
		}else{
			$rating_html  = '<div class="star-rating">';
			$rating_html .= '<span class="rating"></span>';
			$rating_html .= '</div>';
			$rating_html .= '<div class="clear"></div>';
		}
		return apply_filters( 'intravel_destination_get_rating_html', $rating_html, $rating );
	}

    function get_ancestors($destination){
        $html = array();
        $parents = get_ancestors($destination->term_id, 'destination');
        if($parents){
            foreach ($parents as $destination_id){
                $destination = get_term( $destination_id, 'destination' );
                $html[] = '<a href="'.get_term_link($destination, 'destination').'">'.$destination->name.'</a>';
            }
        }

        if($html){
            $html = array_reverse($html);
            return $html[0];
        }

        return '';
    }
	
}
