<?php

if(!function_exists('cmb2_group_tabs')) {
    function cmb2_group_tabs()
    {
        wp_enqueue_script('cmb2-group-tab', INTRAVEL_PLUGIN_URL . '/libs/cmb2-group-tabs/js/script.js', INTRAVEL_VERSION);
        wp_enqueue_style('cmb2-group-tab', INTRAVEL_PLUGIN_URL . '/libs/cmb2-group-tabs/css/style.css', INTRAVEL_VERSION);
        global $post;
        if($post){
            $post_id = $post->ID;
        }
        else{
            $post_id = '';
        }
        wp_localize_script('cmb2-group-tab', 'cmb2_group_tab_option', array(
            'post_id' => $post_id
        ));
    }

    add_action('admin_enqueue_scripts',  'cmb2_group_tabs');
}