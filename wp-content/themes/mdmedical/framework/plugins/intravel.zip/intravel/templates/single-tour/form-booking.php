<?php
    global $post;
    $customer = it_get_customer();
    $tour = it_get_tour();
    wp_localize_script('plg-intravel', 'tourData', array(
        'tour_id' => $post->ID,
        'booking_days' => json_encode($tour->get_booking_days()),
        'get_msg_tax' => false,
    ));
    $booking_day = $tour->get_booking_day();
?>
<form action="<?php echo it_get_booking_form_url(); ?>" method="post" class="tour-booking-form">
    <div>
		<h3 class="title"><?php _e('Book this tour', 'intravel'); ?></h3>
        <div class="field-group input-form">
            <div class="field-group-inner">
				<span class="icon"><i class="ion-ios-person"></i></span>
                <input class="control" type="text" name="first_name" placeholder="<?php _e('First Name', 'intravel'); ?>" value="<?php echo $customer->first_name; ?>" required/>
            </div>
        </div>
        <div class="field-group input-form">
            <div class="field-group-inner">
				<span class="icon"><i class="ion-ios-person"></i></span>
                <input class="control" type="text" name="last_name" placeholder="<?php _e('Last Name', 'intravel'); ?>" value="<?php echo $customer->last_name; ?>" required/>
            </div>
        </div>
        <div class="field-group input-form">
            <div class="field-group-inner">
				<span class="icon"><i class="ion-email"></i></span>
                <input class="control" type="email" name="email" placeholder="<?php _e('Your Email', 'intravel'); ?>" value="<?php echo $customer->email; ?>" required/>
            </div>
        </div>
        <div class="field-group input-form">
            <div class="field-group-inner">
				<span class="icon"><i class="ion-ios-telephone"></i></span>
                <input class="control" type="text" name="phone" placeholder="<?php _e('Phone number', 'intravel'); ?>" value="<?php echo $customer->phone; ?>" required/>
            </div>
        </div>
        <div class="field-group input-form field-left">
            <div class="field-group-inner">
				<span class="icon"><i class="ion-calendar"></i></span>
                <input type="text" class="tour_start_date control" name="start_date" placeholder="<?php _e('Tour start date', 'intravel'); ?>" value="<?php echo $booking_day; ?>"/>
            </div>
        </div>
        <?php
        if($tour->get_start_time()){
            ?>
            <div class="field-group input-form field-left">
                <div class="field-group-inner field-tour_start_time">
                    <span class="icon"><i class="ion-calendar"></i></span>
                    <select class="tour_start_time control" name="start_time" title="<?php echo __('Start time', 'intravel'); ?>">
                        <?php foreach ($tour->get_start_time() as $start_time){?>
                            <option value="<?php echo esc_attr($start_time); ?>"><?php echo esc_html($start_time); ?></option>
                        <?php } ?>
                    </select>
                </div>
            </div>
            <?php
        }
        ?>
        <div class="field-group input-form field-left">
            <div class="field-group-inner">
				<span class="icon"><i class="ion-ios-person"></i></span>
                <input class="adult_ticket control" type="number" name="adult_ticket" placeholder="<?php _e('Number of adult', 'intravel'); ?>" value="" min="0" />
            </div>
        </div>
        <div class="field-group input-form field-left">
            <div class="field-group-inner">
				<span class="icon"><i class="ion-ios-person"></i></span>
                <input class="children_ticket control" type="number" name="children_ticket" placeholder="<?php _e('Number of children', 'intravel'); ?>" value="" min="0"/>
            </div>
        </div>
        <?php it_get_template_part('single-tour/form-booking-services'); ?>

        <div class="field-group field-submit field-left">
                <input type="hidden" name="tour" value="<?php echo $post->ID; ?>"/>
                <input type="hidden" name="intravel-action" value="checkout-tour"/>
                <?php wp_nonce_field('intravel-verify'); ?>
                <div class="tour-price-now">
                    <div class="msg-wrap"></div>
                    <img alt="" src="<?php echo INTRAVEL_PLUGIN_URL.'/assets/img/facebook-loading.gif'; ?>"></div>
                <button type="submit" class="tour-submit-booking tour-submit-form theme-bg disable"><?php _e('Booking tour', 'intravel'); ?></button>
        </div>

    </div>
</form>