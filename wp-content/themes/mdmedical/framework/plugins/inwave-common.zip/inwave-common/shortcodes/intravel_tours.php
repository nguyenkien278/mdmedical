<?php

/*
 * Travel Tours for Visual Composer
 */
if (!class_exists('inTravel_Tours')) {

    class inTravel_Tours extends Inwave_Shortcode{

        protected $name = 'intravel_tours';
        protected $count;

        function init_params() {

            $this->count = 0;

            $args = array(
                'taxonomy' => 'destination',
                'hide_empty' => false,
            );

            $_destinations = get_terms($args);
            $select_destinations = array();
            $select_destinations[__("All", "inwavethemes")] = '0';
            if(!is_wp_error($_destinations) && $_destinations){
                foreach ($_destinations as $destination){
                    $select_destinations[$destination->name] = $destination->slug;
                }
            }

            return array(
                "name" => __('Travel Tours', 'inwavethemes'),
                "base" => $this->name,
                'category' => 'Custom',
                "description" => '',
                'icon' => 'iw-default',
                "params" => array(
					array(
							"type" => "dropdown",
							"admin_label" => true,
							"heading" => "Style",
							"param_name" => "style",
							"value" => array(
                                "Style 1 - Tours Grid" => "style1",
								"Style 2 - Tours Grid Slide" => "style2",
								"Style 3 - Tours Grid Filter" => "style3",
								"Style 4 - Tour width Booking" => "style4",
							)
					),
					array(
                        "type" => "iwevent_preview_image",
                        "heading" => __("Preview Style", "inwavethemes"),
                        "param_name" => "preview_style1",
                        "value" => get_template_directory_uri() . '/assets/images/shortcodes/travel-tours-style1.jpg',
                        "dependency" => array('element' => 'style', 'value' => 'style1')
                    ),
					array(
                        "type" => "iwevent_preview_image",
                        "heading" => __("Preview Style", "inwavethemes"),
                        "param_name" => "preview_style2",
                        "value" => get_template_directory_uri() . '/assets/images/shortcodes/travel-tours-style2.jpg',
                        "dependency" => array('element' => 'style', 'value' => 'style2')
                    ),
					array(
                        "type" => "iwevent_preview_image",
                        "heading" => __("Preview Style", "inwavethemes"),
                        "param_name" => "preview_style3",
                        "value" => get_template_directory_uri() . '/assets/images/shortcodes/travel-tours-style3.jpg',
                        "dependency" => array('element' => 'style', 'value' => 'style3')
                    ),
                    array(
                        "type" => "iwevent_preview_image",
                        "heading" => __("Preview Style", "inwavethemes"),
                        "param_name" => "preview_style4",
                        "value" => get_template_directory_uri() . '/assets/images/shortcodes/travel-tours-style4.jpg',
                        "dependency" => array('element' => 'style', 'value' => 'style4')
                    ),
                    array(
                        "type" => "dropdown",
                        "heading" => __("Select Location", 'inwavethemes'),
                        "param_name" => "select_destination",
                        "value" => $select_destinations,
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Title destination tour", "inwavethemes"),
                        "param_name" => "title_tour",
                        "value" => 'San Francisco Tours',
                        "dependency" => array('element' => 'style', 'value' => 'style4')
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Text for Booking tour", "inwavethemes"),
                        "param_name" => "text_booking_tour",
                        "value" => 'Book now',
                        "dependency" => array('element' => 'style', 'value' => 'style4')
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Limit", "inwavethemes"),
                        "param_name" => "limit",
                        "value" => '8',
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Offset", "inwavethemes"),
                        "param_name" => "offset",
                        "value" => '',
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Include Tour IDs", "inwavethemes"),
                        "param_name" => "include_ids",
                        "value" => '',
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Exclude Tour IDs", "inwavethemes"),
                        "param_name" => "exclude_ids",
                        "value" => '',
                    ),
                    array(
                        "type" => "dropdown",
                        "heading" => __("Function", 'inwavethemes'),
                        "param_name" => "function",
                        "value" => array(
                            "Get all tours" => "1",
                            "Only featured tours" => "2",
                            "Only discount tours" => "3",
                        ),
                    ),

                    array(
                        "type" => "dropdown",
                        "heading" => __("Order By", 'inwavethemes'),
                        "param_name" => "order_by",
                        "value" => array(
                            "No" => "none",
                            "ID" => "id",
                            "Title" => "title",
                            "Date" => "date",
                            "Ordering" => "menu_order",
                            "Popular" => "popular",
                        ),
                    ),
                    array(
                        "type" => "dropdown",
                        "heading" => __("Order Direction", 'inwavethemes'),
                        "param_name" => "order_dir",
                        "value" => array(
                            "Descending" => "DESC",
                            "Ascending" => "ASC",
                        ),
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Extra Class", "inwavethemes"),
                        "param_name" => "class",
                        "value" => "",
                        "description" => __("Write your own CSS and mention the class name here.", "inwavethemes"),
                    )
                )
            );
        }

        // Shortcode handler function for item
        function init_shortcode($atts, $content = null) {

            if(!class_exists('inTravel')){
                return __('Please active the plugin inTravel', 'inwavethemes');
            }

            $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( $this->name, $atts ) : $atts;

            $output = $style = $title_tour = $text_booking_tour = $limit = $class = '';
            extract(shortcode_atts(array(
                'style' => '',
                'select_destination' => '',
                'title_tour' => '',
                'text_booking_tour' => '',
                'limit' => '',
                'offset' => '',
                'include_ids' => '',
                'exclude_ids' => '',
                'order_by' => '',
                'order_dir' => '',
                'function' => '',
                'class' => '',
            ), $atts));

            $include_ids = $include_ids ? explode(',', $include_ids) : array();
            $exclude_ids = $exclude_ids ? explode(',', $exclude_ids) : array();

            $meta_query = array();
            if($function == 2){
                $meta_query['realtion'] = 'OR';
                $meta_query[] = array(
                    'key' => 'intravel_featured',
                    'value' => 'yes',
                );
            }
            elseif($function == 3)
            {
                $meta_query['realtion'] = 'OR';
                $meta_query[] = array(
                    'key' => 'intravel_discount',
                    'compare' => '>',
                    'value' => '0',
                );
                $meta_query[] = array(
                    'key' => 'intravel_discount',
                    'compare' => '!=',
                    'value' => '',
                );
            }
			
			$offset = (int)$offset;
			$page = 1;
			if(get_query_var('paged')){
				$page = get_query_var( 'paged' );
				$offset = ( $page-1 ) * $limit;
			}

            if($order_by == 'popular'){
                $args = array(
				//	'posts_per_page' => 3,
                    'numberposts' => ($limit ? $limit : -1),
                    'offset' => ($offset ? $offset : ''),
                    'post_type' => 'tour',
                    'meta_key' => 'intravel_total_sales',
                    'orderby' => 'meta_value_num',
                    'order' => $order_dir,
                    'include' => $include_ids,
                    'exclude' => $exclude_ids,
                    'destination' => $select_destination,
			'meta_query' => $meta_query
                );

                $tours = get_posts($args);
            }
            else{
                $args = array(
				//	'posts_per_page' => 3,
                    'numberposts' => ($limit ? $limit : -1),
                    'offset' => ($offset ? $offset : ''),
                    'post_type' => 'tour',
                    'orderby' => $order_by,
                    'order' => $order_dir,
                    'include' => $include_ids,
                    'exclude' => $exclude_ids,
                    'destination' => $select_destination,
			'meta_query' => $meta_query
                );

                $tours = get_posts($args);
            }

            $class = ' '.$style;
            ob_start();
				switch ($style) {
                case 'style1':
                    ?>
                    <div class="iw-travel-tours <?php echo $class; ?>">
                        <?php foreach ($tours as $tour) :
                            global $post;
							if(!is_object($tour)){
								$post = get_post($tour);
							}
							else{
								$post = $tour;
							}
                            $tour = it_get_tour($tour);
                            $duration = $tour->duration;
                            $price = $tour->price;
                            $destinations = $tour->get_destinations();
                            ?>
                            <div class="col-md-4 col-sm-4 col-xs-12">
                                <div class="iw-tour-item">
                                    <div class="image-wrap">
                                        <?php $large_image_url = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full'); ?>
                                        <img src="<?php echo esc_url($large_image_url[0]); ?>" alt=""/>
                                        <div class="icon-action">
                                            <a class="iw-to-detail theme-color-hover" href="<?php echo get_permalink(); ?>"><i class="fa fa-arrow-right"></i></a>
                                        </div>
                                    </div>
                                    <div class="info-wrap">
                                        <div class="info-left">
                                            <h3 class="title"><a class="theme-color" href="<?php echo get_permalink(); ?>"><?php echo the_title(); ?></a></h3>
                                            <div class="post-meta">
                                                <ul>
                                                    <?php if ($destinations) : ?>
                                                        <li class="destinations">
                                                            <i class="fa fa-map-marker"> </i>
                                                            <?php
                                                            $destination_html = array();
                                                            foreach($destinations as $destination){
                                                                $destination_html[] = '<a href="'.esc_url(get_term_link($destination->slug, 'destination')).'" class="destination">'.$destination->name.'</a>';
                                                            }
                                                            echo implode(' / ', $destination_html);
                                                            ?>
                                                        </li>
                                                    <?php endif ?>
                                                    <?php if ($duration) : ?>
                                                        <li>
                                                            <span class="duration"><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo $duration; ?></span>
                                                        </li>
                                                    <?php endif ?>
                                                </ul>
                                            </div>
                                        </div>
                                        <?php if ($price) : ?>
                                            <div class="tour-price right theme-bg">
                                                <span><?php echo it_price($price); ?></span>
                                            </div>
                                        <?php endif; ?>
                                        <div style="clear: both"></div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach;
                        wp_reset_postdata(); ?>
                    </div>
                    <?php
                    break;
				
				case 'style2':
                    wp_enqueue_style('owl-carousel');
                    wp_enqueue_style('owl-theme');
                    wp_enqueue_style('owl-transitions');
                    wp_enqueue_script('owl-carousel');
                    
					$sliderConfig = '{';
                    $sliderConfig .= '"navigation":false';
					$sliderConfig .= ',"navigationText": ["<i class=\"fa fa-angle-left\"></i>", "<i class=\"fa fa-angle-right\"></i>"]';
					$sliderConfig .= ',"autoPlay":false';
                    $sliderConfig .= ',"pagination":true';
                    $sliderConfig .= ',"items":1';
					$sliderConfig .= ',"autoHeight":true';
                    $sliderConfig .= ',"itemsDesktop":[1199,1]';
                    $sliderConfig .= ',"itemsDesktopSmall":[979,1]';
                    $sliderConfig .= ',"itemsTablet":[768,1]';
                    $sliderConfig .= ',"itemsMobile":[479,1]';
                    $sliderConfig .= '}';
				?>
					<div class="iw-travel-tours <?php echo $class; ?> style4">
                        <div class="owl-carousel" data-plugin-options='<?php echo $sliderConfig; ?>'>
                        <?php 
						$total_tours = count($tours);
						$k = 0;
						$i = 0;
						foreach ($tours as $tour){
                            global $post;
							if(!is_object($tour)){
								$post = get_post($tour);
							}
							else{
								$post = $tour;
							}
                            $tour = it_get_tour($tour);
                            $price = $tour->price;
                            $rating = $tour->get_rating_html();
							$galleries = $tour->get_gallery_attachment_ids();
                            $destinations = $tour->get_destinations();
                            $total_reviews = $tour->get_review_count();
						//	$regular_price = $tour->get_regular_price();
							$discount = $tour->discount;
                            ?>
							
							<?php if ($k % 6 == 0){
							echo '<div class="tour-row-item">'; 
							echo '<div class="row">'; 
							}
						//	if ($i % 3 == 0){
						//		echo '<div class="row">';
						//	}
							?>
							
								<div class="col-md-4 col-sm-6 col-xs-12 item">
									<div class="iw-tour-item">
										<?php if($tour->is_on_sale()){ ?>
											<div class="tour-discount"><?php echo $discount.'%'; ?></div>
										<?php } ?>
										<div class="image-wrap">
											<?php 
												$img = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');
												if ($img){
													$img_src = count($img) ? $img[0] : '';
												} elseif($galleries) {
													reset($galleries);
													$img_src = current($galleries);
												}
												$img_src = inwave_resize($img_src, 370, 255, true);
											?>
											<img src="<?php echo esc_url($img_src); ?>" alt=""/>
											<div class="booking-action">
												<a class="link-to-detail theme-bg" href="<?php echo get_permalink(); ?>">
													<?php echo __('Book now', 'inwavethemes'); ?>
												</a>
											</div>
										</div>
										<div class="info-wrap">
											<div class="info-left">
												<h3 class="title"><a class="theme-color-hover" href="<?php echo get_permalink(); ?>"><?php echo the_title(); ?></a></h3>
												<div class="post-meta">
													<ul>
														<?php if ($destinations) : ?>
                                                            <li class="destinations">
                                                                <i class="fa fa-map-marker"> </i>
                                                                <?php
                                                                $destination_html = array();
                                                                foreach($destinations as $destination){
                                                                    $destination_html[] = '<a href="'.esc_url(get_term_link($destination->slug, 'destination')).'" class="destination">'.$destination->name.'</a>';
                                                                }
                                                                echo implode(' / ', $destination_html);
                                                                ?>
                                                            </li>
														<?php endif ?>
														<?php if ($tour ->get_duration()) : ?>
															<li>
																<span class="duration"><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo $tour ->get_duration(); ?></span>
															</li>
														<?php endif ?>
													</ul>
												</div>
											</div>
											
												<div class="tour-price-vote">
													<?php if ($price) : ?>
													<span class="price-tour theme-bg"><?php echo it_price($price); ?></span>
													<?php endif; ?>
													<div class="iwt-rating">
														<?php echo $rating; ?>
													</div>
												</div>
											
										</div>
									</div>
								</div>
							
							<?php 
							//	if (($i + 1) % 3 == 0 || ($i + 1) == $total_tours){
							//		echo '</div>';
							//	}
							if (($k + 1) % 6 == 0 || ($k + 1) == $total_tours) { 
							//	echo '</div>';
								echo '</div>';
								echo '</div>';
							}
							?>

                        <?php
						$i++;
						$k++;
						}
                        wp_reset_postdata(); ?>
                        </div>
                    </div>
				
				<?php
				break;
				
				case 'style3':
					wp_enqueue_script('isotope');
                    wp_enqueue_script('imagesloaded');
					wp_enqueue_script('filtering');
					
				
					
				?>
				<div class="iw-travel-tours <?php echo $class; ?> style4">
					<?php 
						$tour_type_args = array(
							'taxonomy' => 'tour_type',
							'hide_empty' => true,
						);
						$_tour_types = get_terms($tour_type_args);
					?>
					<div class="button-filter">
						<div class="filters button-group" id="filters">
							<?php 
								if (!empty($_tour_types)) {
										
										$button_filter[] = '<button class="filter is-checked" data-filter="*">' . __('All tours', 'inwavethemes') . '</button>';
										foreach ($_tour_types as $tour_type) {
											$button_filter[] = '<button class="filter" data-filter=".' .$tour_type->slug. '">'.$tour_type->name. '</button>';
										}
									echo implode(' / ', $button_filter);
									}
							?>
						</div>
					</div>
					
					<div class="tours-list-isotop">
						<div class="row">
							<div class="list-isotop">
								<section id="isotope-main" class="isotope"  style="">
										<?php 
										foreach($tours as $tour){
										
										global $post;
										if(!is_object($tour)){
											$post = get_post($tour);
										}
										else{
											$post = $tour;
										}
										$tour = it_get_tour($tour);
										$price = $tour->price;
										$rating = $tour->get_rating_html();
										$galleries = $tour->get_gallery_attachment_ids();
										$destinations = $tour->get_destinations();
										$total_reviews = $tour->get_review_count();
										$discount = $tour->discount;
										
										$terms = wp_get_post_terms($tour->post->ID, 'tour_type');
										$term_class = array();
										foreach($terms as $term){
											$term_class[] = $term->slug;
										}
										?>
										<div class="col-md-4 col-sm-6 col-xs-12 element-item <?php echo $term_class ? implode(' ', $term_class) : ''; ?>">
											
											<div class="iw-tour-item">
												<?php if($tour->is_on_sale()){ ?>
													<div class="tour-discount"><?php echo $discount.'%'; ?></div>
												<?php } ?>
												<div class="image-wrap">
													<?php 
														$img = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');
														if ($img){
															$img_src = count($img) ? $img[0] : '';
														} elseif($galleries) {
															reset($galleries);
															$img_src = current($galleries);
														}
														$img_src = inwave_resize($img_src, 370, 255, true);
													?>
													<img src="<?php echo esc_url($img_src); ?>" alt=""/>
													<div class="booking-action">
														<a class="link-to-detail theme-bg" href="<?php echo get_permalink(); ?>">
															<?php echo __('Book now', 'inwavethemes'); ?>
														</a>
													</div>
												</div>
												<div class="info-wrap">
													<div class="info-left">
														<h3 class="title"><a class="theme-color-hover" href="<?php echo get_permalink(); ?>"><?php echo the_title(); ?></a></h3>
														<div class="post-meta">
															<ul>
																<?php if ($destinations) : ?>
																	<li class="destinations">
																		<i class="fa fa-map-marker"> </i>
																		<?php
																		$destination_html = array();
																		foreach($destinations as $destination){
																			$destination_html[] = '<a href="'.esc_url(get_term_link($destination->slug, 'destination')).'" class="destination">'.$destination->name.'</a>';
																		}
																		echo implode(' / ', $destination_html);
																		?>
																	</li>
																<?php endif ?>
																<?php if ($tour ->get_duration()) : ?>
																	<li>
																		<span class="duration"><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo $tour ->get_duration(); ?></span>
																	</li>
																<?php endif ?>
															</ul>
														</div>
													</div>
													
														<div class="tour-price-vote">
															<?php if ($price) : ?>
															<span class="price-tour theme-bg"><?php echo it_price($price); ?></span>
															<?php endif; ?>
															<div class="iwt-rating">
																<?php echo $rating; ?>
															</div>
														</div>
													
												</div>
											
												
											
											</div>
											
										</div>
										<?php
										}
										?>
								</section>
							</div>
						</div>
					</div>
				</div>
				
				<?php
				break;
				case 'style4':
                    wp_enqueue_script('isotope');
                    wp_enqueue_script('imagesloaded');
                    ?>
                    <h4 class="title-travel-tour-style-4"><?php echo esc_html__($title_tour, 'intravel'); ?></h4>
                    <div class="row iw-travel-tours <?php echo $class; ?>">
                        <div id="iw-isotope-travel-4-main" class="isotope">
                        <?php foreach ($tours as $tour) :
                            global $post;
							if(!is_object($tour)){
								$post = get_post($tour);
							}
							else{
								$post = $tour;
							}
                            $tour = it_get_tour($tour);
                            $price = $tour->price;
                            $rating = $tour->get_rating_html();
                            $destinations = $tour->get_destinations();
                            $total_reviews = $tour->get_review_count();
                            ?>

                            <div class="col-md-4 col-sm-6 col-xs-12 element-item">
                                <div class="iw-tour-item">
                                    <div class="image-wrap">
                                        <?php $large_image_url = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');
                                        $image_url = $large_image_url ? $large_image_url[0] : '';
                                        $image_url = inwave_resize($image_url, 370, 255, true)
                                        ?>
                                        <img src="<?php echo esc_url($image_url); ?>" alt=""/>
                                        <div class="booking-action">
                                            <a class="link-to-detail theme-bg" href="<?php echo get_permalink(); ?>">
												<?php echo __('Book now', 'inwavethemes'); ?>
											</a>
                                        </div>
                                    </div>
                                    <div class="info-wrap">
                                        <div class="info-left">
                                            <h3 class="title"><a class="theme-color-hover" href="<?php echo get_permalink(); ?>"><?php echo the_title(); ?></a></h3>
                                            <div class="post-meta">
                                                <ul>
                                                    <?php if ($destinations) : ?>
                                                        <li class="destinations">
                                                            <i class="fa fa-map-marker"> </i>
                                                            <?php
                                                            $destination_html = array();
                                                            foreach($destinations as $destination){
                                                                $destination_html[] = '<a href="'.esc_url(get_term_link($destination->slug, 'destination')).'" class="destination">'.$destination->name.'</a>';
                                                            }
                                                            echo implode(' / ', $destination_html);
                                                            ?>
                                                        </li>
                                                    <?php endif ?>
                                                    <?php if ($tour ->get_duration()) : ?>
                                                        <li>
                                                            <span class="duration"><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo $tour ->get_duration(); ?></span>
                                                        </li>
                                                    <?php endif ?>
                                                </ul>
                                            </div>
                                        </div>
                                        <?php if ($price) : ?>
                                            <div class="tour-price-vote">
                                                <span class="price-tour theme-bg"><?php echo it_price($price); ?></span>
                                                <div class="iwt-rating">
                                                    <?php echo $rating; ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                </div>
                            </div>

                        <?php endforeach;
                        wp_reset_postdata(); ?>
                        </div>
                    </div>

                    <?php
                    break;
				}
            $html = ob_get_contents();
            ob_end_clean();

            return $html;
        }
		
    }
}

new inTravel_Tours;
