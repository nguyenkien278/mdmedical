<?php

/*
 * Travel Tours for Visual Composer
 */
if (!class_exists('inTravel_Discount_Tours')) {

    class inTravel_Discount_Tours extends Inwave_Shortcode{

        protected $name = 'intravel_discount_tours';
        protected $count;

        function init_params() {

            $this->count = 0;

            return array(
                "name" => __('Travel Discount Tours', 'inwavethemes'),
                "base" => $this->name,
                'category' => 'Custom',
                "description" => '',
                'icon' => 'iw-default',
                "params" => array(
                    array(
                        "type" => "dropdown",
                        "admin_label" => true,
                        "heading" => "Style",
                        "param_name" => "style",
                        "value" => array(
                            "Style 1 - Tours slider" => "style1",
                            "Style 2 - Tours Grid" => "style2",
                        )
                    ),
                    array(
                        "type" => "iwevent_preview_image",
                        "heading" => __("Preview Style", "inwavethemes"),
                        "param_name" => "preview_style1",
                        "value" => get_template_directory_uri() . '/assets/images/shortcodes/discount_tours-v1.jpg',
                        "dependency" => array('element' => 'style', 'value' => 'style1')
                    ),
                    array(
                        "type" => "iwevent_preview_image",
                        "heading" => __("Preview Style", "inwavethemes"),
                        "param_name" => "preview_style2",
                        "value" => get_template_directory_uri() . '/assets/images/shortcodes/discount_tours-v2.jpg',
                        "dependency" => array('element' => 'style', 'value' => 'style2')
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Limit", "inwavethemes"),
                        "param_name" => "limit",
                        "value" => '8',
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Include Tour IDs", "inwavethemes"),
                        "param_name" => "include_ids",
                        "value" => '',
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Exclude Tour IDs", "inwavethemes"),
                        "param_name" => "exclude_ids",
                        "value" => '',
                    ),
                    array(
                        "type" => "dropdown",
                        "heading" => __("Order By", 'inwavethemes'),
                        "param_name" => "order_by",
                        "value" => array(
                            "No" => "none",
                            "ID" => "id",
                            "Title" => "title",
                            "Date" => "date",
                            "Ordering" => "menu_order",
                        ),
                    ),
                    array(
                        "type" => "dropdown",
                        "heading" => __("Order Direction", 'inwavethemes'),
                        "param_name" => "order_dir",
                        "value" => array(
                            "Descending" => "DESC",
                            "Ascending" => "ASC",
                        ),
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Extra Class", "inwavethemes"),
                        "param_name" => "class",
                        "value" => "",
                        "description" => __("Write your own CSS and mention the class name here.", "inwavethemes"),
                    )
                )
            );
        }

        // Shortcode handler function for item
        function init_shortcode($atts, $content = null) {
            if(!class_exists('inTravel')){
                return __('Please active the plugin inTravel', 'inwavethemes');
            }

            $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( $this->name, $atts ) : $atts;

            extract(shortcode_atts(array(
                'style' => '',
                'limit' => '',
                'include_ids' => '',
                'exclude_ids' => '',
                'order_by' => '',
                'order_dir' => '',
                'class' => '',
            ), $atts));

            $include_ids = $include_ids ? explode(',', $include_ids) : array();
            $exclude_ids = $exclude_ids ? explode(',', $exclude_ids) : array();

            $args = array(
                'numberposts' => ($limit ? $limit : -1),
                'offset' => '',
                'post_type' => 'tour',
                'orderby' => $order_by,
                'order' => $order_dir,
                'include' => $include_ids,
                'exclude' => $exclude_ids,
                'meta_query' => array(
                    array(
                        'key' => 'intravel_discount',
                        'value' => '',
                        'compare' => '!=',
                    )
                )
            );

            $tours = get_posts($args);
			
			wp_enqueue_style('owl-carousel');
			wp_enqueue_style('owl-theme');
			wp_enqueue_style('owl-transitions');
			wp_enqueue_script('owl-carousel');
			
            ob_start();
					$sliderConfig = '{';
                    $sliderConfig .= '"navigation":true';
					$sliderConfig .= ',"navigationText": ["<i class=\"fa fa-angle-left\"></i>", "<i class=\"fa fa-angle-right\"></i>"]';
					$sliderConfig .= ',"autoPlay":false';
                    $sliderConfig .= ',"pagination":false';
                    $sliderConfig .= ',"items":3';
                    $sliderConfig .= ',"itemsDesktop":[1199,3]';
                    $sliderConfig .= ',"itemsDesktopSmall":[979,2]';
                    $sliderConfig .= ',"itemsTablet":[768,1]';
                    $sliderConfig .= ',"itemsMobile":[479,1]';
                    $sliderConfig .= '}';
            switch ($style) {
            case 'style1':
            ?>
					<div class="intravel-discount-tours">
						<div class="owl-carousel" data-plugin-options='<?php echo $sliderConfig ?>'>
							<?php 
							foreach ($tours as $tour) {
							global $post;
							if(!is_object($tour)){
								$post = get_post($tour);
							}
							else{
								$post = $tour;
							}

							$tour = it_get_tour($tour);
							$price = $tour->price;
							$tour_type = $tour->get_type();
							?>
								<div class="iw-tour-item-wrap">
									<div class="iw-tour-item">
										<div class="image-wrap">
											<?php 
											$large_image_url = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');
											$tour_image = count($large_image_url) ? $large_image_url[0] : '';
											$tour_image = inwave_resize($tour_image, 600, 600, true);
											?>
										<!--<img src="<?php //echo esc_url($large_image_url[0]); ?>" alt=""/>-->
											<a class="iw-to-detail" href="<?php echo get_permalink(); ?>">
												<img src="<?php echo esc_url($tour_image); ?>" alt=""/>
											</a>
										</div>
										<div class="info-wrap">
											<div class="info-tour">
												<div class="post-meta">
													<div class="discount">
														<span><?php echo $tour->discount; ?>%</span>
													</div>
													<div class="tour-type">
														<?php echo $tour_type->name; ?>
													</div>
												</div>
												<h3 class="title"><a class="" href="<?php echo get_permalink(); ?>"><?php echo the_title(); ?></a></h3>
											</div>
										<!--	
											
											<?php if ($price) : ?>
												<div class="tour-price right theme-bg">
													<span><?php echo $price; ?></span>
												</div>
											<?php endif; ?>
											
										-->
											<div style="clear: both"></div>
										</div>
									</div>
								</div>
								<?php 
								}
								wp_reset_postdata(); ?>
						</div>
					</div>
                <?php
                break;
                case 'style2':
                    wp_enqueue_script('isotope');
                    wp_enqueue_script('imagesloaded');
                    ?>
                    <div class="row iw-travel-tours style4 style2">
                        <div id="iw-isotope-travel-5-main" class="isotope">
                            <?php foreach ($tours as $tour) :
                                global $post;
                                if(!is_object($tour)){
                                    $post = get_post($tour);
                                }
                                else{
                                    $post = $tour;
                                }
                                $tour = it_get_tour($tour);
                                $price = $tour->price;
                                $rating = $tour->get_rating_html();
                                $destinations = $tour->get_destinations();
                                $total_reviews = $tour->get_review_count();
                                ?>
                                <div class="col-md-4 col-sm-6 col-xs-12 element-item">
                                    <div class="iw-tour-item">
                                        <div class="tour-discount"><?php echo $tour->discount; ?>%</div>
                                        <div class="image-wrap">
                                            <?php $large_image_url = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');
                                            $image_url = $large_image_url ? $large_image_url[0] : '';
                                            $image_url = inwave_resize($image_url, 370, 255, true)
                                            ?>
                                            <img src="<?php echo esc_url($image_url); ?>" alt=""/>
                                            <div class="booking-action">
                                                <a class="link-to-detail theme-bg" href="<?php echo get_permalink(); ?>">
                                                    <?php echo __('Book now', 'inwavethemes'); ?>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="info-wrap">
                                            <div class="info-left">
                                                <h3 class="title"><a class="theme-color-hover" href="<?php echo get_permalink(); ?>"><?php echo the_title(); ?></a></h3>
                                                <div class="post-meta">
                                                    <ul>
                                                        <?php if ($destinations) : ?>
                                                            <li class="destinations">
                                                                <i class="fa fa-map-marker"> </i>
                                                                <?php
                                                                $destination_html = array();
                                                                foreach($destinations as $destination){
                                                                    $destination_html[] = '<a href="'.esc_url(get_term_link($destination->slug, 'destination')).'" class="destination">'.$destination->name.'</a>';
                                                                }
                                                                echo implode(' / ', $destination_html);
                                                                ?>
                                                            </li>
                                                        <?php endif ?>
                                                        <?php if ($tour ->get_duration()) : ?>
                                                            <li>
                                                                <span class="duration"><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo $tour ->get_duration(); ?></span>
                                                            </li>
                                                        <?php endif ?>
                                                    </ul>
                                                </div>
                                            </div>
                                            <?php if ($price) : ?>
                                                <div class="tour-price-vote">
                                                    <span class="price-tour theme-bg"><?php echo it_price($price); ?></span>
                                                    <?php if($total_reviews > 0) : ?>
                                                        <div class="iwt-rating">
                                                            <?php echo $rating; ?>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach;
                            wp_reset_postdata(); ?>
                        </div>
                    </div>

                    <?php
                    break;
            }
            $html = ob_get_contents();
            ob_end_clean();

            return $html;
        }
    }
}

new inTravel_Discount_Tours;