<?php
/** Widget Rating Filter **/
class IT_Widget_Rating_Filter extends WP_Widget {

    function __construct() {
        $widget_ops = array('classname' => 'widget_tour_rating_filter', 'description' => esc_html__('Display a price filter slider in a widget which lets you narrow down the list of shown tours.', 'inevent'));
        $control_ops = array('width' => 400, 'height' => 350);
        
        parent::__construct('it-rating-filter', esc_html__('InTravel Average Rating Filter', 'inevent'), $widget_ops, $control_ops);
    }

    /**
     * Get current page URL for layered nav items.
     * @return string
     */
    protected function get_page_base_url() {

        $link = it_get_page_permalink('tours');

        // Min/Max
        if ( isset( $_GET['min_price'] ) ) {
            $link = add_query_arg( 'min_price', wc_clean( $_GET['min_price'] ), $link );
        }

        if ( isset( $_GET['max_price'] ) ) {
            $link = add_query_arg( 'max_price', wc_clean( $_GET['max_price'] ), $link );
        }

        if ( isset( $_GET['tour_type'] ) ) {
            $link = add_query_arg( 'tour_type', wc_clean( $_GET['tour_type'] ), $link );
        }

        if ( isset( $_GET['destination'] ) ) {
            $link = add_query_arg( 'destination', wc_clean( $_GET['destination'] ), $link );
        }

        // Orderby
        if ( isset( $_GET['orderby'] ) ) {
            $link = add_query_arg( 'orderby', wc_clean( $_GET['orderby'] ), $link );
        }

        /**
         * Search Arg.
         * To support quote characters, first they are decoded from &quot; entities, then URL encoded.
         */
        if ( get_search_query() ) {
            $link = add_query_arg( 's', rawurlencode( htmlspecialchars_decode( get_search_query() ) ), $link );
        }

        return $link;
    }

    /**
     * Count products after other filters have occured by adjusting the main query.
     * @param  int $rating
     * @return int
     */
    protected function get_filtered_tour_count( $rating ) {
        global $wpdb;

        $tax_query  = intravel_query::get_main_tax_query();
        $meta_query = intravel_query::get_main_meta_query();

        // Unset current rating filter
        foreach ( $meta_query as $key => $query ) {
            if ( ! empty( $query['rating_filter'] ) ) {
                unset( $meta_query[ $key ] );
            }

            if($query['key'] == '_visibility'){
                unset( $meta_query[ $key ] );
            }
        }

        // Set new rating filter
        $meta_query[] = array(
            'key'           => '_it_average_rating',
            'value'         => $rating,
            'compare'       => '>=',
            'type'          => 'DECIMAL',
            'rating_filter' => true
        );

        $meta_query = new WP_Meta_Query( $meta_query );
        $tax_query  = new WP_Tax_Query( $tax_query );

        $meta_query_sql = $meta_query->get_sql( 'post', $wpdb->posts, 'ID' );
        $tax_query_sql  = $tax_query->get_sql( $wpdb->posts, 'ID' );

        $sql  = "SELECT COUNT( {$wpdb->posts}.ID ) FROM {$wpdb->posts} ";
        $sql .= $tax_query_sql['join'] . $meta_query_sql['join'];
        $sql .= $tax_query_sql['join'];
        $sql .= " WHERE {$wpdb->posts}.post_type = 'tour' AND {$wpdb->posts}.post_status = 'publish' ";
        $sql .= $tax_query_sql['where'] . $meta_query_sql['where'];
        $sql .= $tax_query_sql['where'];

        return absint( $wpdb->get_var( $sql ) );
    }


    function widget( $args, $instance ) {
        ob_start();
        $found      = false;
        $min_rating = isset( $_GET['min_rating'] ) ? absint( $_GET['min_rating'] ) : '';
        echo $args['before_widget'];
        $title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : __( 'Average Rating Filter', 'intravel' );
        $title = apply_filters( 'widget_title', $title, $instance, $this->id_base );
        if ( !empty( $title ) ) { echo $args['before_title'] . $title . $args['after_title']; }

        echo '<ul>';

        for ( $rating = 4; $rating >= 1; $rating-- ) {
            $count = $this->get_filtered_tour_count( $rating );

            if ( ! $count ) {
                continue;
            }

            $found = true;
            $link  = $this->get_page_base_url();
            $link  = $min_rating !== $rating ? add_query_arg( 'min_rating', $rating, $link ) : $link;

            echo '<li class="tour-layered-nav-rating ' . ( ! empty( $_GET['min_rating'] ) && $rating === absint( $_GET['min_rating'] ) ? 'chosen' : '' ) . '">';

            echo '<a href="' . esc_url( apply_filters( 'intravel_rating_filter_link', $link ) ) . '">';

            echo '<span class="star-rating" title="' . esc_attr( sprintf( __( 'Rated %s and above', 'intravel' ), $rating ) ). '">
                <span style="width:' . esc_attr( ( $rating / 5 ) * 100 ) . '%">' . sprintf( __( 'Rated %s and above', 'intravel'), $rating ) . '</span>
            </span> (' . esc_html( $count ) . ')';

            echo '</a>';

            echo '</li>';
        }

        echo '</ul>';

        echo $args['after_widget'];

        if ( ! $found ) {
            ob_end_clean();
        } else {
            echo ob_get_clean();
        }
    }

    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;
        $instance['title'] = strip_tags($new_instance['title']);

        return $instance;
    }

    function form( $instance ) {
        $instance = wp_parse_args( (array) $instance, array( 'title' => __( 'Average Rating Filter', 'intravel' )) );
        $title = strip_tags($instance['title']);
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'inevent'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <?php
    }
}

function it_rating_filter_widget() {
    register_widget('IT_Widget_Rating_Filter');
}
add_action('widgets_init', 'it_rating_filter_widget');