
var newmoveform = addComment.moveForm;
addComment.moveForm = function (commId, parentId, respondId, postId) {
    newmoveform.call(addComment, commId, parentId, respondId, postId);
    jQuery('.comment-form').find('.comment-form-rating').hide();
    var  cancel_reply_button = jQuery('#cancel-comment-reply-link');
    cancel_reply_button.click(function(){
        jQuery('.comment-form').find('.comment-form-rating').show();
    });

    return false;
};
