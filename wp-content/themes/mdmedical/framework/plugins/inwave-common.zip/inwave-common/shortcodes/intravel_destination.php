<?php

/*
 * Inwave_Heading for Visual Composer
 */
if (!class_exists('InTravel_Detination')) {

    class InTravel_Detination extends Inwave_Shortcode{

        protected $name = 'intravel_destination';

        function init_params() {
            $args = array(
                'taxonomy' => 'destination',
                'hide_empty' => false,
            );

            $_destinations = get_terms($args);
            $destinations = array();
            if(!is_wp_error($_destinations) && $_destinations) {
                foreach ($_destinations as $destination) {
                    $destinations[$destination->name] = $destination->slug;
                }
            }

            return array(
                'name' => __('Tour Single Destination', 'inwavethemes'),
                'description' => __('A Destination of intravel', 'inwavethemes'),
                'base' => $this->name,
                'icon' => 'iw-default',
                'category' => 'Custom',
                'params' => array(
                    array(
                        "type" => "dropdown",
                        "heading" => __("Select Location", 'inwavethemes'),
                        "param_name" => "destination",
                        "value" => $destinations,
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Image Width", "inwavethemes"),
                        "description" => __("Image Width in px", "inwavethemes"),
                        "param_name" => "image_width",
                        "value" => '560',
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Image Height", "inwavethemes"),
                        "description" => __("Image Height in px", "inwavethemes"),
                        "param_name" => "image_height",
                        "value" => '560',
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Extra Class", "inwavethemes"),
                        "param_name" => "class",
                        "value" => "",
                        "description" => __("Write your own CSS and mention the class name here.", "inwavethemes"),
                    )
                )
            );
        }

        // Shortcode handler function for list Icon
        function init_shortcode($atts, $content = null) {

            if(!class_exists('inTravel')){
                return __('Please active the plugin inTravel', 'inwavethemes');
            }

            $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( $this->name, $atts ) : $atts;

            $output = '';
            extract(shortcode_atts(array(
                //'title' => '',
                'image_width' => '',
                'image_height' => '',
                'destination' => '',
                'class' => '',
            ), $atts));

            if($destination){
                $destination = get_term_by('slug', $destination, 'destination');
                $output .= '<div class="intravel-destination'.esc_attr($class ? ' '.$class : '').'">';
                $image = get_term_meta($destination->term_id, 'intravel_image', true);

                if($image){
                    $image = inwave_resize($image, $image_width, $image_height, true);
                }

                if(!$image){
                    $image = it_get_placeholder_image();
                }

                $output .= '<div class="img-wrap"><img src="'.esc_url($image).'" alt="'.esc_attr($destination->name).'"></div>';
                $output .= '<div class="destination-info">';
                $output .= '<h3><a href="'.get_term_link($destination->slug, 'destination').'">'.$destination->name.'</a></h3>';
                $output .= '<p class="description-destination">'.wp_trim_words($destination->description, 20, null).'</p>';
                $output .= '<ul>';
                if ($this->get_ancestors($destination)) {
                    $output .= '<li class="meta-destination"><i class="fa fa-map-marker"></i> '.$this->get_ancestors($destination).'</li>';
                }
                $total_tours = $this->get_total_tours($destination);
                $output .= '<li class="meta-tour"><i class="tour-icon"></i> '.sprintf(_n('%d tour', '%d tours', $total_tours, 'inwavethemes'), $total_tours). '</li>';
                $output .= '</ul>';
                $output .= '</div>';
                $output .= '</div>';
            }
            else{
                $output .= '<p>'.__('Please select a destination', 'intravel').'</p>';
            }

            return $output;
        }

        function get_ancestors($destination){
            $html = array();
            $parents = get_ancestors($destination->term_id, 'destination');
            if($parents){
                foreach ($parents as $destination_id){
                    $destination = get_term( $destination_id, 'destination' );
                    $html[] = '<a href="'.get_term_link($destination, 'destination').'">'.$destination->name.'</a>';
                }
            }

            if($html){
                return $html[0];
            }

            return '';
        }

        function get_total_tours($destination){
            global $wpdb;

            $total = $wpdb->get_var( $wpdb->prepare( "
				SELECT COUNT(*) FROM {$wpdb->posts} as post
				LEFT JOIN {$wpdb->term_relationships} as term_relationships ON term_relationships.object_id = post.ID
				WHERE post.post_type = 'tour'
				AND (post.post_status = 'publish' || post.post_status = 'private')
				AND term_relationships.term_taxonomy_id = %d
				", $destination->term_id));
            return $total;
        }
    }
}

new InTravel_Detination;
