/* 
 * @package Inwave Event
 * @version 1.0.0
 * @created Jun 2, 2016
 * @author Inwavethemes
 * @email inwavethemes@gmail.com
 * @website http://inwavethemes.com
 * @support Ticket https://inwave.ticksy.com/
 * @copyright Copyright (c) 2015 Inwavethemes. All rights reserved.
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 *
 */

/**
 * Description of iwevent-script
 *
 * @developer Hien Tran
 */
(function ($) {
    'use strict';

    $(document).ready(function(){
        var tour_start_date = $('.tour_start_date');
        var adult_input = $('.adult_ticket');
        var children_input = $('.children_ticket');
        var service_element = $('[name="intravel_service[]"]');
        if (tour_start_date.length) {
            var booking_days = JSON.parse(tourData.booking_days);
            var from_date = new Date();
            from_date.setMonth(from_date.getMonth() + 1);
            tour_start_date.datepicker({
                dateFormat : 'mm/dd/yy',
                onChangeMonthYear: function(year, month, inst) {
                    var to_date = new Date(year, month);
                    if(to_date >= from_date){
                        var month = from_date.getMonth() + 1;
                        $.ajax({
                            type: 'post',
                            dataType: 'json',
                            url: PlgIntravelCfg.ajaxUrl,
                            data: {action: 'intravel_change_monthyear', 'tour_id' : tourData.tour_id, 'from_date' : month+'-'+from_date.getFullYear(), 'to_date' : ''},
                            beforeSend: function () {
                                $('#ui-datepicker-div').addClass('loading');
                            },
                            success:function(data) {
                                booking_days= $.extend(booking_days, data);

                                from_date = to_date;
                                $('#ui-datepicker-div').removeClass('loading');
                                tour_start_date.datepicker("refresh");
                                tour_start_date.datepicker("enable");
                            },
                            error: function(errorThrown){
                                console.log(errorThrown);
                            }
                        });
                    }
                },
                beforeShowDay : function (date) {
                    var dd = ("0" + date.getDate()).slice(-2);
                    var mm = ("0" + (date.getMonth() + 1)).slice(-2); //January is 0!
                    var yyyy = date.getFullYear();
                    var shortDate = mm+'/'+dd+'/'+yyyy;
                    var validate = false;
                    if(!booking_days.hasOwnProperty(shortDate)){
                        return [false, ""];
                    }
                    else{
                        return [true, booking_days[shortDate][0] , booking_days[shortDate][1] ];
                    }

                },onSelect: function(dateText, inst) {
                    tour_price(dateText);
                }
            });
        }

        if($('.has-date-picker').length){
            $('.has-date-picker').datepicker({
                dateFormat: 'mm/dd/yy'
            });
        }
        
        adult_input.on('keyup change', function () {
            var date = tour_start_date.val();
            if(date){
                tour_price();
            }
        });

        children_input.on('keyup', function () {
            var date = tour_start_date.val();
            if(date){
                tour_price();
            }
        });

        tour_start_date.change(function () {
            var date = tour_start_date.val();
            if(date){
                tour_price();
            }
        });

        $('[name="intravel_service[]"].has-price').change(function(){
            tour_price();
        });

        //trigger
        var adult_val = parseInt(adult_input.val()),
            children_val = parseInt(children_input.val()),
            tour_start_date_val = tour_start_date.val();
            if( adult_val && children_val && tour_start_date_val){
                tour_price();
            }

        $('.tour-booking-form, .tour-checkout-form').submit(function () {
            if(!$('.tour_start_date').val()){
                alert('Please select tour start date');
                return false;
            }
            if(!parseInt($('.adult_ticket').val()) && !parseInt($('.children_ticket').val())){
               alert('Please input Adult tickets');
               return false;
            }
        });

        function tour_price(date){
            if(!date){
                date = tour_start_date.val();
            }
            var adult = adult_input.val();
            var children = children_input.val();
            var services = [];
            service_element.find(':selected').each(function () {
                if($(this).val()){
                    services.push($(this).val());
                }
            });
            service_element.each(function () {
                if($(this).is(':checked') && $(this).val()){
                    services.push($(this).val());
                }
            });

            $.ajax({
                type: 'post',
                dataType: 'json',
                url: PlgIntravelCfg.ajaxUrl,
                data: {action: 'intravel_tour_price', 'tour_id' : tourData.tour_id, 'date' : date, 'adult' : adult, 'children' : children, 'services' : services, 'get_msg_tax' : tourData.get_msg_tax},
                beforeSend: function() {
                    $('.tour-submit-form').attr('disabled', true);
                    $('.tour-price-now').addClass('loading');
                },
                success:function(data) {
                    $('.tour-price-now').removeClass('loading').find('.msg-wrap').html(data.msg).fadeIn();
                    if(data.status == 1){
                        $('.tour-submit-form').removeAttr('disabled');
                    }
                },
                error: function(errorThrown){
                    console.log(errorThrown);
                }
            });
        }

        $(".filter-destination").select2({
            placeholder: "Destination",
            allowClear: true
        });

        $(".filter-group").select2({
            placeholder: "Group travel",
            allowClear: true
        });

        $(".filter-price").select2({
            placeholder: "Price",
            allowClear: true
        });

        //Booking button click
        $('button.button-booking-tour').click(function () {

            var id = $(this).data('id');
            Custombox.open({
                target: '#booking-tour-form-' + id,
                cache: true,
                effect: 'fadein',
                overlayOpacity: 0.8,
                width: 800
            });
        });

        //Close custombox
        $('.iw-booking-tour-form .close-booking-tour').click(function () {
            Custombox.close();
        });

        function initTourDetailMap(){

            var map = new google.maps.Map(document.getElementById('tour-map'), {
                center: {lat: parseFloat(PlgIntravelTourMapCfg.lat), lng: parseFloat(PlgIntravelTourMapCfg.lng)},
                zoom: parseInt(PlgIntravelTourMapCfg.zoom),
                mapTypeId: google.maps.MapTypeId.ROADMAP,
                scrollwheel: false

            });

            if(PlgIntravelTourMapCfg.markers){
                var directionsService = new google.maps.DirectionsService();
                var markers = [];
                var bounds = new google.maps.LatLngBounds();
                var line = new google.maps.Polyline({
                    //path: directionResult.routes[0].overview_path,
                    strokeColor: PlgIntravelTourMapCfg.polyline_color,
                    strokeOpacity: parseFloat(PlgIntravelTourMapCfg.polyline_stroke_opacity),
                    strokeWeight: parseInt(PlgIntravelTourMapCfg.polyline_stroke_weight)
                });

                PlgIntravelTourMapCfg.markers.forEach(function (marker_data) {
                    addMarker(marker_data);
                });

                calcRoute();
                fitBounds();
            }

            $('.iw-tab-item').click(function(e){
                e.preventDefault();
                if($(this).data('hasmap') == true){
                    google.maps.event.trigger(map, 'resize');
                    if(markers.length){
                        fitBounds();
                    }
                }
            });

            function addMarker(data){
                var latlng = new google.maps.LatLng(data.lat, data.lng);
                var title = data.title ? data.title : data.address;
                if(data.marker_icon){
                    var marker_size = new google.maps.Size( 40, 40 );
                    var marker_icon = {
                        url: PlgIntravelTourMapCfg.marker_url+data.marker_icon,
                        size: marker_size,
                        scaledSize: marker_size,
                        origin: new google.maps.Point( 0, 0 ),
                        anchor: new google.maps.Point( 20, 40 )
                    };

                    var marker = new google.maps.Marker({
                        map: map,
                        position: latlng,
                        icon: marker_icon,
                        animation: false
                    });
                }
                else
                {
                    var marker = new google.maps.Marker({
                        position: latlng,
                        title: title,
                        map: map
                    });
                }

                var infowindow = new google.maps.InfoWindow({
                    content: title
                });
                marker.addListener('click', function() {
                    infowindow.open(map, marker);
                });

                bounds.extend(latlng);

                markers.push(marker);
            }

            function calcRoute() {
                if(markers.length >= 2){
                    var j = 0;
                    var origin = [], destination = [], waypoints = [];
                    markers.forEach(function(marker){
                        if(j == 0){
                            origin = marker.position;
                        }else if(j ==(markers.length - 1)){
                            destination = marker.position
                        }
                        else{
                            var way = {
                                location : marker.position,
                                stopover: true
                            };
                            waypoints.push(way);
                        }

                        j++;
                    });

                    var request = {
                        origin: origin,
                        destination: destination,
                        waypoints: waypoints,
                        travelMode: google.maps.TravelMode['DRIVING']
                    };
                    directionsService.route(request, function(response, status) {
                        if (status == google.maps.DirectionsStatus.OK) {
                            //directionsDisplay.setDirections(response);
                            createPolyline(response);
                        }
                    });
                }
            }

            function createPolyline(directionResult) {
                line.setPath(directionResult.routes[0].overview_path);
                line.setMap(map);
            }

            function fitBounds(){
                if(markers){
                    if(markers.length == 1){
                        markers.forEach(function(marker){
                            if(marker.position){
                                map.setCenter(marker.position);
                            }
                        });
                    }else{
                        map.fitBounds(bounds);
                    }
                }
                else{
                    //
                }
            }
        }
		
		function initDesinationDetailMap(){
            var lat = PlgIntravelDestinationMapCfg.marker.lat ? parseFloat(PlgIntravelDestinationMapCfg.marker.lat) : parseFloat(PlgIntravelDestinationMapCfg.lat);
            var lng = PlgIntravelDestinationMapCfg.marker.lng ? parseFloat(PlgIntravelDestinationMapCfg.marker.lng) : parseFloat(PlgIntravelDestinationMapCfg.lng);
            var zoom = PlgIntravelDestinationMapCfg.marker.zoom ? parseInt(PlgIntravelDestinationMapCfg.marker.zoom) :  parseFloat(PlgIntravelDestinationMapCfg.zoom);
            var latlng = new google.maps.LatLng(lat, lng);
            var map = new google.maps.Map(document.getElementById('destination-map'), {
                center: latlng,
                zoom: zoom,
                mapTypeId: google.maps.MapTypeId.ROADMAP,
                scrollwheel: false,
				styles: [{"featureType":"water","elementType":"geometry","stylers":[{"color":"#e9e9e9"},{"lightness":17}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#f5f5f5"},{"lightness":20}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#ffffff"},{"lightness":17}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#ffffff"},{"lightness":29},{"weight":0.2}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":18}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":16}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#f5f5f5"},{"lightness":21}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"color":"#dedede"},{"lightness":21}]},{"elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#ffffff"},{"lightness":16}]},{"elementType":"labels.text.fill","stylers":[{"saturation":36},{"color":"#333333"},{"lightness":40}]},{"elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"transit","elementType":"geometry","stylers":[{"color":"#f2f2f2"},{"lightness":19}]},{"featureType":"administrative","elementType":"geometry.fill","stylers":[{"color":"#fefefe"},{"lightness":20}]},{"featureType":"administrative","elementType":"geometry.stroke","stylers":[{"color":"#fefefe"},{"lightness":17},{"weight":1.2}]}],

            });

            if(PlgIntravelDestinationMapCfg.marker.lat && PlgIntravelDestinationMapCfg.marker.lng){
                if(PlgIntravelDestinationMapCfg.marker_icon){
                    var marker_size = new google.maps.Size( 44, 60 );
                    var marker_icon = {
                        url: PlgIntravelDestinationMapCfg.marker_icon,
                        size: marker_size,
                        scaledSize: marker_size,
                        origin: new google.maps.Point( 0, 0 ),
                        anchor: new google.maps.Point( 7, 27 )
                    };

                    var marker = new google.maps.Marker({
                        map: map,
                        position: latlng,
                        icon: marker_icon,
                        animation: false
                    });

                }
                else
                {
                    var marker = new google.maps.Marker({
                        position: latlng,
                        map: map
                    });
                }
            }
        }

        function loadTabContent() {
            var item_active = $iwTab.find('.iw-tab-items .iw-tab-item.active');
            content_list.addClass('iw-hidden');
            $(content_list.get(list.index(item_active))).removeClass('iw-hidden');
        }

        if ($('.iw-tabs.tab-travel-detail').length) {
			var $iwTab = $('.iw-tabs.tab-travel-detail'),
                content_list = $iwTab.find('.iw-tab-content .iw-tab-item-content'),
                list = $iwTab.find('.iw-tab-items .iw-tab-item');
			$('.iw-tab-items .iw-tab-item', $iwTab).click(function () {
				if ($(this).hasClass('active')) {
					return;
				}
				$(this).addClass('active');
				var itemclick = this;
				list.each(function () {
					if (list.index(this) !== list.index(itemclick) && $(this).hasClass('active')) {
						$(this).removeClass('active');
					}
				});
				loadTabContent();
			});

			loadTabContent();
		}
        
        if(typeof PlgIntravelTourMapCfg !== 'undefined'){
            initTourDetailMap();
        }

		if(typeof PlgIntravelDestinationMapCfg !== 'undefined'){
			initDesinationDetailMap();
		}

        $(".tour-select-search, .iw-select-2, .intravel-select2, .tour_start_time").select2();


        $('.tours-layout').click(function (e) {
            e.preventDefault();
            if($(this).hasClass('layout-list')){
                $(this).closest('.layout-switcher').find('input[name="layout"]').val('list');
                setCookie("tours-layout", 'list', 30);
                $(this).closest('form').submit();
            }
            else{
                $(this).closest('.layout-switcher').find('input[name="layout"]').val('grid');
                setCookie("tours-layout", 'grid', 30);
                $(this).closest('form').submit();
            }
        });

        $('.tours-order, .tours-orderby').change(function () {
            $(this).closest('form').submit();
        });
    });

    $(window).on("load resize", function () {
        $('.destination-widget .destination-item').each(function(){
            var item = $(this);
            var info_active = item.find('.destination-info .info-active').outerHeight();
            item.find('.destination-info').css({bottom : info_active + 16});
        });
    });

    $(window).on("load", function () {
        var $container_isotope = $('#iw-isotope-main');
        if($container_isotope.length){
            $container_isotope.isotope({
                itemSelector: '.element-item'
                //	layoutMode:'masonry',
                //	resizesContainer: true,
                //	resizable: true,
            });
            $container_isotope.imagesLoaded().progress( function() {
                $container_isotope.isotope('layout');
            });
        }

        if($('#destination-rating').length){
            $('#destination-rating').barrating({
                theme: 'fontawesome-stars',
                showSelectedRating: false,
                initialRating:  parseInt($('#destination-rating').data('rating')),
                onSelect: function(value, text) {
                    var destination =  $('#destination-rating').data('destination');
                    if(value && destination){
                        $.ajax({
                            type: 'post',
                            dataType: 'json',
                            url: PlgIntravelCfg.ajaxUrl,
                            data: {action: 'intravel_destination_rating', 'destination' : destination, 'rating' : value},
                            beforeSend: function () {
                            },
                            success:function(data) {
                                $('.destination-rate .br-wrapper').html(data.message);
                                if(data.status == 1){
                                    setCookie("rating_destination_"+destination, 1, 1);
                                }
                            },
                            error: function(errorThrown){
                                console.log(errorThrown);
                            }
                        });
                    }
                },
            });
        }
    });


    var setCookie = function(cname, cvalue, exdays) {
        var expires = "";
        if (exdays) {
            var d = new Date();
            d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
            expires = " expires=" + d.toUTCString();
        }
        document.cookie = cname + "=" + cvalue + ";" + expires + '; path=/';
    }

})(jQuery);
