<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * is_intravel - Returns true if on a page which uses InTravel templates (cart and checkout are standard pages with shortcodes and thus are not included).
 * @return bool
 */
function is_intravel() {
    return apply_filters( 'is_intravel', ( is_tours() || is_tour_taxonomy() || is_tour() ) ? true : false );
}

if ( ! function_exists( 'is_tours' ) ) {

    /**
     * is_shop - Returns true when viewing the tour type archive (shop).
     * @return bool
     */
    function is_tours() {
        return ( is_post_type_archive( 'tour' ) || is_page( it_get_page_id( 'tours' ) ) );
    }
}

if ( ! function_exists( 'is_tour_taxonomy' ) ) {

    /**
     * is_tour_taxonomy - Returns true when viewing a tour taxonomy archive.
     * @return bool
     */
    function is_tour_taxonomy() {
        return is_tax( get_object_taxonomies( 'tour' ) );
    }
}

if ( ! function_exists( 'is_tour_category' ) ) {

    /**
     * is_tour_category - Returns true when viewing a tour category.
     * @param  string $term (default: '') The term slug your checking for. Leave blank to return true on any.
     * @return bool
     */
    function is_tour_category( $term = '' ) {
        return is_tax( 'tour_cat', $term );
    }
}

if ( ! function_exists( 'is_tour_tag' ) ) {

    /**
     * is_tour_tag - Returns true when viewing a tour tag.
     * @param  string $term (default: '') The term slug your checking for. Leave blank to return true on any.
     * @return bool
     */
    function is_tour_tag( $term = '' ) {
        return is_tax( 'tour_tag', $term );
    }
}

if ( ! function_exists( 'is_tour_destination' ) ) {

    /**
     * is_tour_destinaton - Returns true when viewing a destination (destination).
     * @param  string $term (default: '') The term slug your checking for. Leave blank to return true on any.
     * @return bool
     */
    function is_tour_destination( $term = '' ) {
        return is_tax( 'destination', $term );
    }
}

if ( ! function_exists( 'is_tour' ) ) {

    /**
     * is_tour - Returns true when viewing a single tour.
     * @return bool
     */
    function is_tour() {
        return is_singular( array( 'tour' ) );
    }
}