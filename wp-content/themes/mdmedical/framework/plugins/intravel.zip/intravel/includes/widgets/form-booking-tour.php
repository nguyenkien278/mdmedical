<?php
/**
 * Widget API: Inwave_Intravel_Form_Booking_Tour class
 *
 * @package WordPress
 * @subpackage Widgets
 * @since 4.4.0
 */

class Inwave_Intravel_Form_Booking_Tour extends WP_Widget {

    public function __construct() {
        $widget_ops = array(
            'description' => esc_html__( 'Display InTravel form booking tour.' ),
            'customize_selective_refresh' => true,
        );
        parent::__construct( 'intravel_form _booking_tour', esc_html__( 'InTravel Form Booking Tour' ), $widget_ops );
    }

    public function widget( $args, $instance ) {

        /** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */

        echo $args['before_widget'];
        ?>
        <?php
            if(is_single() && get_post_type() == 'tour'){
                it_get_template_part('single-tour/form', 'booking');
            }
        ?>

        <?php
        echo $args['after_widget'];
    }

}

function inwave_intravel_form_booking_tour() {
    register_widget('Inwave_Intravel_Form_Booking_Tour');
}
add_action('widgets_init', 'inwave_intravel_form_booking_tour');