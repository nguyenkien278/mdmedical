<?php

if ( ! defined( 'ABSPATH' ) ) exit;

class IT_Email {

	static public function sendMail ($type, $tour_booking) {
		if(it_use_woocommerce_payment()){
			return false;
		}

		if(is_numeric($tour_booking)){
			$tour_booking = it_get_booking($tour_booking);
		}
		if($type && $tour_booking){
			$email = self::get_email_data($type, $tour_booking);
			if($email){
				$headers = array();
				$headers[] = 'Content-Type: text/html; charset=UTF-8';
				$from_name = it_get_option('email_from_name');
				$from_name = $from_name ? $from_name : get_bloginfo('name');
				$from_address = it_get_option('email_from_address');
				$from_address = $from_address ? $from_address : get_bloginfo('admin_email');
				$headers[] = 'From: '.$from_name.' <'.$from_address.'>';
				wp_mail($email['recipients'], $email['subject'], $email['body'], $headers);
			}
		}
	}

	static function get_email_tags(){
		return array(
			'intravel_site_title',
			'intravel_admin_email',
			'intravel_custommer_name',
			'intravel_custommer_firstname',
			'intravel_custommer_lastname',
			'intravel_custommer_email',
			'intravel_check_order_link',
			'intravel_order_admin_link',
			'intravel_order_code',
			'intravel_order_price',
			'intravel_order_adult_number',
			'intravel_order_children_number',
			'intravel_tour_start_date',
			'intravel_tour_title',
			'intravel_tour_link',
			'intravel_hold_order_hours',
		);
	}

	static function get_email_data($type, $tour_booking){
		$email = array();
		$email_enable = it_get_option('email_'.$type.'_enable', 1);

		if(!$email_enable){
			return $email;
		}

		$email['recipients'] = it_get_option('email_'.$type.'_recipients');
		if(!$email['recipients']){
			return array();
		}

		$email['subject'] = it_get_option('email_'.$type.'_subject');

		$email['body'] = it_get_option('email_'.$type.'_body_html');

		if(!$email['body']){
			return array();
		}

		$email_tags = self::get_email_tags();
		foreach ($email as $field => $field_value){
			foreach ($email_tags as $email_tag){
				$value = '';
				switch ($email_tag){
					case 'intravel_site_title':
						$value = get_bloginfo('name');
						break;
					case 'intravel_admin_email':
						$value = get_bloginfo('admin_email');
						break;
					case 'intravel_custommer_name':
						$value = $tour_booking->first_name.' '.$tour_booking->last_name;
						break;
					case 'intravel_custommer_firstname':
						$value = $tour_booking->first_name;
						break;
					case 'intravel_custommer_lastname':
						$value = $tour_booking->last_name;
						break;
					case 'intravel_custommer_email':
						$value = $tour_booking->email;
						break;
					case 'intravel_order_price':
						$value = it_price($tour_booking->email);
						break;
					case 'intravel_order_admin_link':
						$value = '<a href="'.get_edit_post_link($tour_booking->tour).'" target="_blank">'.__('here', 'intravel').'</a>';
						break;
					case 'intravel_check_order_link':
						$value = '<a href="'.$tour_booking->getCheckOrderUrl().'" target="_blank">'.__('here', 'intravel').'</a>';
						break;
					case 'intravel_order_code':
						$value = $tour_booking->get_booking_number();
						break;
					case 'intravel_order_adult_number':
						$value = $tour_booking->adult_ticket;
						break;
					case 'intravel_order_children_number':
						$value = $tour_booking->children_ticket;
						break;
					case 'intravel_order_start_date':
						$value = date(get_option('date_format'), strtotime($tour_booking->start_date));
						break;
					case 'intravel_tour_title':
						$value = get_the_title($tour_booking->tour);
						break;
					case 'intravel_tour_link':
						$value = '<a href="'.get_the_permalink($tour_booking->tour).'" target="_blank">'.get_the_title($tour_booking->tour).'</a>';
						break;
					case 'intravel_hold_order_hours':
						$value = it_get_option( 'hold_stock_hours', '1' );
						break;
				}

				$field_value = str_replace('{'.$email_tag.'}', $value, $field_value);

				$email[$field] = $field_value;
			}
		}

		return $email;
	}
}