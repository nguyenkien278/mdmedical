/*
 * @package Inwave Event
 * @version 1.0.0
 * @created Jun 2, 2016
 * @author Inwavethemes
 * @email inwavethemes@gmail.com
 * @website http://inwavethemes.com
 * @support Ticket https://inwave.ticksy.com/
 * @copyright Copyright (c) 2015 Inwavethemes. All rights reserved.
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 *
 */

/**
 * Description of iwevent-script
 *
 * @developer Hien Tran
 */
(function ($) {
    'use strict';

    $(document).ready(function () {
        $('#intravel_user:not([readonly])').change(function () {
            var user_id = $(this).val();
            if(user_id){
                $.ajax({
                    type: 'post',
                    dataType: 'json',
                    url: PlgIntravelCfg.ajaxUrl,
                    data: {action: 'intravel_get_customer_data', 'user_id' : user_id},
                    success:function(data) {
                        if(data){
                            $('#intravel_first_name').val(data.first_name);
                            $('#intravel_last_name').val(data.last_name);
                            $('#intravel_email').val(data.email);
                            $('#intravel_phone').val(data.phone);
                            $('#intravel_address').val(data.address);
                        }
                    },
                    error: function(errorThrown){
                        console.log(errorThrown);
                    }
                });
            }
        });
    });

    $('.booking-from-date').datepicker({ dateFormat: 'yy/mm/dd' });
    $('.booking-to-date').datepicker({
        dateFormat: 'yy/mm/dd',
        beforeShowDay : function (date) {
            var from_date = $('.booking-from-date').val();

            if(from_date){
                var dd = ("0" + date.getDate()).slice(-2);
                var mm = ("0" + (date.getMonth() + 1)).slice(-2); //January is 0!
                var yyyy = date.getFullYear();
                var shortDate = yyyy+'/'+mm+'/'+dd;
                if(shortDate < from_date){
                    return [false, ""  ];
                }
                else{
                    return [true, ""];
                }
            }else{
                return [true, ""];
            }
        }
    });

    $('.tour_page_tour-booking #doaction').click(function () {
        var form = $(this).closest('form');
        var action_url = form.data('action');
        form.attr('action', action_url);
    });

    setTimeout(function () {
        if($('.cmb2-id-intravel-discount-from').find('input').val() == '' && $('.cmb2-id-intravel-discount-to').find('input').val() == ''){
            $('.cmb2-id-intravel-discount-from').hide();
            $('.cmb2-id-intravel-discount-to').hide();
        }
        else{
            $('.cmb2-id-intravel-discount-from').show();
            $('.cmb2-id-intravel-discount-to').show();
        }
    }, 100);


    $('.tour-discount-schedule').click(function (e) {
        e.preventDefault();
        if($('.cmb2-id-intravel-discount-from').is(':visible') || $('.cmb2-id-intravel-discount-to').find('input').is(':visible')){
            $('.cmb2-id-intravel-discount-from').hide().find('input').val('');
            $('.cmb2-id-intravel-discount-to').hide().find('input').val('');
            $(this).html('Schedule');
        }
        else{
            $('.cmb2-id-intravel-discount-from').show();
            $('.cmb2-id-intravel-discount-to').show();
            $(this).html('Cancel Schedule');
        }
    });
})(jQuery);

