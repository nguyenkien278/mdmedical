<?php

/*
 * Inwave_Heading for Visual Composer
 */
if (!class_exists('InTravel_Tour')) {

    class InTravel_Tour extends Inwave_Shortcode{

        protected $name = 'intravel_tour';

        function init_params() {
            return array(
                'name' => __('InTravel Single Tour', 'inwavethemes'),
                'description' => __('A Tour of intravel', 'inwavethemes'),
                'base' => $this->name,
                'icon' => 'iw-default',
                'category' => 'Custom',
                'params' => array(
                    array(
                        "type" => "textfield",
                        "heading" => __("Tour ID", "inwavethemes"),
                        "description" => __("Enter Tour ID", "inwavethemes"),
                        "param_name" => "tour_id",
                        "value" => '',
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Image Width", "inwavethemes"),
                        "description" => __("Image Width in px", "inwavethemes"),
                        "param_name" => "image_width",
                        "value" => '269',
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Image Height", "inwavethemes"),
                        "description" => __("Image Height in px", "inwavethemes"),
                        "param_name" => "image_height",
                        "value" => '360',
                    ),
                    array(
                        "type" => "dropdown",
                        "heading" => "Text align",
                        "param_name" => "align",
                        "value" => array(
                            "Default" => "",
                            "Left" => "left",
                            "Right" => "right",
                            "Center" => "center"
                        )
                    ),
                    array(
                        'type' => 'css_editor',
                        'heading' => __( 'CSS box', 'js_composer' ),
                        'param_name' => 'css',
                        // 'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'js_composer' ),
                        'group' => __( 'Design Options', 'js_composer' )
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Extra Class", "inwavethemes"),
                        "param_name" => "class",
                        "value" => "",
                        "description" => __("Write your own CSS and mention the class name here.", "inwavethemes"),
                    )
                )
            );
        }

        // Shortcode handler function for list Icon
        function init_shortcode($atts, $content = null) {

            if(!class_exists('inTravel')){
                return __('Please active the plugin inTravel', 'inwavethemes');
            }

            $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( $this->name, $atts ) : $atts;

            $output = '';

            extract(shortcode_atts(array(
                //'title' => '',
                'tour_id' => '',
                'image_width' => '',
                'image_height' => '',
                'align' => '',
                'css' => '',
                'class' => '',
            ), $atts));

            $class .= ' '. vc_shortcode_custom_css_class( $css);

            if($align){
                $class.= ' text-'.$align;
            }

            if($tour_id){
                $tour = get_post($tour_id);
                if($tour->post_status == 'publish'){
                    $output .= '<div class="intravel-tour '.esc_attr($class ? ' '.$class : '').'">';
                    $image = get_post_thumbnail_id($tour_id);
                    $image_url = '';
                    if($image){
                        $image_url = wp_get_attachment_url($image);
                        if($image_width && $image_height){
                            $image_url = inwave_resize($image_url, $image_width, $image_height, true);
                        }
                    }

                    if(!$image_url){
                        $image_url = it_get_placeholder_image();
                    }

                    $output .= '<img src="'.esc_url($image_url).'" alt="'.esc_attr($tour->post_name).'">';
                    $output .= '<div class="tour-info">';
                    $output .= '<h4>'.$this->get_type($tour).'</h4>';
                    $output .= '<h3>'.get_the_title($tour).'</h3>';
//					$output .= apply_filters('the_content', $tour->post_content);
                    $output .= '</div>';
                    $output .= '</div>';
                }
                else
                {
                    $output .= '<p>'.__('Tour not publishing', 'intravel').'</p>';
                }
            }
            else{
                $output .= '<p>'.__('Please select a tour', 'intravel').'</p>';
            }

            return $output;
        }

        function get_type($tour){
            $terms = get_the_terms( $tour, 'tour_type' );
            if($terms){
                $term = $terms[0];
                return '<a href="'.get_term_link($term).'">'.$term->name.'</a>';
            }

            return '';
        }
    }
}

new InTravel_Tour;
