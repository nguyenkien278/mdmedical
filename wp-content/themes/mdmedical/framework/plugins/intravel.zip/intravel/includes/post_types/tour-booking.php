<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

class IT_Tour_Booking_Post_Type{
    function __construct()
    {
        add_action('init', array($this, 'register'));
        add_action('admin_head', array($this, 'custom_admin_head'));
       // add_action('admin_menu', array($this, 'custom_admin_menu'));
        add_filter('cmb2_admin_init', array($this, 'meta_boxes'));
        add_action('save_post', array($this, 'custom_save_post'), 100, 1);
        add_action('restrict_manage_posts', array($this, 'custom_restrict_manage_posts'));

        add_filter('post_row_actions', array($this, 'custom_post_row_actions'), 10, 2);
        add_filter('manage_posts_columns' , array($this, 'custom_columns_head' ));
        add_filter('manage_posts_custom_column' , array($this, 'custom_columns_content' ), 10, 2);
        add_filter('manage_edit-tour_booking_sortable_columns', array($this, 'custom_tour_booking_sortable_columns' ));
        add_filter('request', array($this, 'custom_request' ));
        add_filter('bulk_actions-edit-tour_booking', array($this, 'custom_bulk_actions'));

        add_action( 'wp_ajax_cancel_tour_booking', array($this, 'cancel_tour_booking') );
        add_action( 'wp_ajax_complete_tour_booking', array($this, 'complete_tour_booking') );
        add_action( 'wp_ajax_onhold_tour_booking', array($this, 'onhold_tour_booking') );
        add_action('admin_notices', array($this, 'admin_notice'));
        add_action('cmb2_save_field_intravel_status', array($this, 'change_status'), 10, 3);
        //add_action('admin_enqueue_scripts', array($this, 'admin_scripts'));
    }

    function register(){
        global $wpdb;
        $sql = "SELECT COUNT(1) FROM $wpdb->posts as post JOIN $wpdb->postmeta as postmeta ON post.ID = postmeta.post_id WHERE 
                post.post_type = 'tour_booking' AND post.post_status = 'publish' AND postmeta.meta_key = 'intravel_read' AND postmeta.meta_value = '0'";
        $unread = $wpdb->get_var($sql);
        $labels = array(
            'name' 					=> __('Booking', 'intravel'),
            'singular_name' 		=> __('Booking', 'intravel'),
            'add_new' 				=> __('Add New', 'intravel'),
            'all_items' 			=> __('Bookings', 'intravel') . ($unread ? '<span class="tour-booking-unred">'.$unread.'</span>' : ''),
            'add_new_item' 			=> __('Add New Booking', 'intravel'),
            'edit_item' 			=> __('Edit Booking', 'intravel'),
            'new_item' 				=> __('New Booking', 'intravel'),
            'view_item' 			=> __('View Booking', 'intravel'),
            'search_items' 			=> __('Search Booking', 'intravel'),
            'not_found' 			=> __('No Booking Found', 'intravel'),
            'not_found_in_trash' 	=> __('No Booking Found in Trash', 'intravel'),
            'parent_item_colon' 	=> '',
        );

        $args = array(
            'labels' 			=> $labels,
            'public' 			=> true,
            'show_ui' 			=> true,
            'capability_type' 	=> 'post',
            'taxonomies'        => array(),
            'hierarchical' 		=> false,
            'rewrite' 			=> false,
            'query_var' 		=> true,
            'show_in_menu'      => 'edit.php?post_type=tour',
            'has_archive'       => false,
            'menu_icon' 		=> 'dashicons-list-view',
            'supports' 			=> array(),
        );

        register_post_type( 'tour_booking' , $args );
    }

    function meta_boxes(){
        $prefix = 'intravel_';

        $attributes = array();
        if(isset($_GET['post'])){
            $attributes = array('readonly' => 'readonly');
            $read = get_post_meta($_GET['post'], 'intravel_read', true);
            if(!$read){
                update_post_meta($_GET['post'], 'intravel_read', '1');
            }
        }

        $args = array(
            'posts_per_page'   => -1,
            'orderby'          => 'date',
            'order'            => 'DESC',
            'post_type'        => 'tour',
            'post_status'      => 'publish',
        );
        $_tours = get_posts($args);
        $tours = array();
        if($_tours){
            foreach ($_tours as $_tour){
                $tours[$_tour->ID] = $_tour->post_title;
            }
        }

        $users = array();
        $users[''] = __(' - Guest', 'intravel');
        $_users = get_users();
        foreach ($_users as $_user){
            $users[$_user->ID] = $_user->ID. ' - '.$_user->display_name;
        }

        $fields = array(
            array(
                'name' => __( 'Custommer' ),
                'id' => $prefix . 'user',
                'type' => 'user_search_text',
                'select_type' => 'radio',
                //'roles' => array( 'administrator', 'author', 'editor' )
                //'description' =>  $user_id ? '<a href="'.get_edit_user_link($user_id).'" target="_blank">'.$user->display_name . ' - ' . $user->user_email . '</a>' : '',
            ),
            array(
                'name'    => __( 'First Name', 'intravel' ),
                'id'      => $prefix . 'first_name',
                'type'    => 'text',
            ),
            array(
                'name'    => __( 'Last Name', 'intravel' ),
                'id'      => $prefix . 'last_name',
                'type'    => 'text',
            ),
            array(
                'name'    => __( 'Phone Number', 'intravel' ),
                'id'      => $prefix . 'phone',
                'type'    => 'text',
            ),
            array(
                'name'    => __( 'Email', 'intravel' ),
                'id'      => $prefix . 'email',
                'type'    => 'text',
            ),
            /*array(
                'name'    => __( 'Address', 'intravel' ),
                'id'      => $prefix . 'address',
                'type'    => 'text',
            ),*/
            array(
                'name'        => __( 'Tour' ),
                'id'          => $prefix . 'tour',
                'type'        => 'post_search_text', // This field type
                // post type also as array
                'post_type'   => 'tour',
                // Default is 'checkbox', used in the modal view to select the post type
                'select_type' => 'radio',
                // Will replace any selection with selection from modal. Default is 'add'
                'select_behavior' => 'replace',
            ),
           // 'description'  => $tour_id ? '<a href="'.get_edit_post_link($tour_id).'" target="_blank">'.get_the_title($tour_id).'</a>',

            array(
                'name'    => __( 'Adult Tickets', 'intravel' ),
                'id'      => $prefix . 'adult_ticket',
                'type'    => 'text',
                'attributes' => $attributes
            ),
            array(
                'name'    => __( 'Children Tickets', 'intravel' ),
                'id'      => $prefix . 'children_ticket',
                'type'    => 'text',
                'attributes' => $attributes
            ));
            if(isset($_GET['post'])){
                $services = wp_get_post_terms($_GET['post'], 'tour_service');
                $service_name = array();
                if($services){
                    foreach ($services as $service){
                        if($service->parent){
                            $parent = get_term($service->parent, 'tour_service');
                            $service_name[] = $parent->name .' '.$service->name;
                        }
                        else{
                            $service_name[] = $service->name;
                        }
                    }
                }
                $fields = array_merge($fields, array(
                    array(
                        'name'    => __( 'Price', 'intravel' ),
                        'id'      => $prefix . 'price',
                        'type'    => 'text',
                        'attributes' => $attributes,
                        'description' =>  (isset($_GET['post']) ? get_post_meta($_GET['post'], $prefix . 'currency', true) : ''),
                        'after_row' => '<div class="cmb-row table-layout">
                                            <div class="cmb-th">
                                                <label for="intravel_start_date">'.__('Tour Start Date', 'intravel' ).'</label>
                                            </div>
                                            <div class="cmb-td">
                                                <p class="cmb2-metabox-description">'.
                                                    date(get_option('date_format'), strtotime(get_post_meta($_GET['post'], $prefix . 'start_date', true))).
                                                    (get_post_meta($_GET['post'], $prefix . 'start_time', true) ? ' '.get_post_meta($_GET['post'], $prefix . 'start_time', true) : '')
                                                .'</p>
                                            </div>
                                        </div>
                                        <div class="cmb-row table-layout">
                                            <div class="cmb-th">
                                                <label for="intravel_start_date">'.__('Extra Services', 'intravel' ).'</label>
                                            </div>
                                            <div class="cmb-td">
                                                <p class="cmb2-metabox-description">'.implode(', ', $service_name).'</p>
                                            </div>
                                        </div>'
                    )
                ));
            }else{
                $args = array(
                    'taxonomy' => 'tour_service',
                    'orderby' => 'term_group',
                    'parent' => '0',
                    'hide_empty' => false,
                );
                $_tour_services = get_terms($args);
                $tour_services = array();
                if($_tour_services){
                    foreach ($_tour_services as $_tour_service){
                        if($_tour_service->parent){
                            $tour_services[$_tour_service->term_id] = '--'.$_tour_service->name;
                        }
                        else{
                            $tour_services[$_tour_service->term_id] = $_tour_service->name;
                        }
                    }
                }

                $fields = array_merge($fields, array(
                    array(
                        'name'    => __( 'Price', 'intravel' ),
                        'id'      => $prefix . 'price',
                        'type'    => 'text',
                        'attributes' => $attributes,
                        'description' =>  (isset($_GET['post']) ? get_post_meta($_GET['post'], $prefix . 'currency', true) : ''),
                    ),
                    array(
                        'name'    => __( 'Tour Start Date', 'intravel' ),
                        'id'      => $prefix . 'start_date',
                        'type'    => (isset($_GET['post']) ? 'text' : 'text_date'),
                        'attributes' => (isset($_GET['post']) ? array('type' => 'hidden') : $attributes),
                    ),array(
                        'name'       => __( 'Type', 'intravel' ),
                        'id'         => $prefix . 'tour_service',
                        'type'       => 'multicheck',
                        'options' => $tour_services,
                    )
                ));
            }
        $fields = array_merge($fields, array(
            array(
                'name'    => __( 'Duration', 'intravel' ),
                'id'      => $prefix . 'duration',
                'type'    => 'text',
                'attributes' => $attributes,
            ),
            array(
                'name'    => __( 'Payment Method', 'intravel' ),
                'id'      => $prefix . 'payment_method',
                'type'    => 'select',
                'options' =>  it_get_payment_methods(),
                'attributes' => $attributes,
            ),
            array(
                'name'    => __( 'Special Requirements', 'intravel' ),
                'id'      => $prefix . 'special_requirements',
                'type'    => 'textarea_small',
            ),
            array(
                'name'    => __( 'Status', 'intravel' ),
                'id'      => $prefix .'status',
                'type'    => 'select',
                'options'    => array(
                    'pending'   => __( 'Pending', 'intravel' ),
                    'onhold'     => __( 'On hold', 'intravel' ),
                    'completed'     => __( 'Completed', 'intravel' ),
                    'cancelled'     => __( 'Cancelled', 'intravel' ),
                ),
            ),
            array(
                'name'    => '',
                'id'      => $prefix . 'submit',
                'type'    => 'input',
                'attributes' => array('type' => 'submit' , 'class'=>'button'),
                'default' => isset($_GET['post']) ? __('Save', 'intravel') : __('Submit', 'intravel')
            )
        ));

        if(!isset($_GET['post'])){
            $fields[] =  array(
                'name'    => '',
                'id'      => 'post_status',
                'type'    => 'input',
                'attributes' => array('type' => 'hidden'),
                'std' => 'publish'
            );
        }
        $meta_boxes = new_cmb2_box( array(
            'id'            => $prefix . 'tour_booking_info',
            'title'         => __('Tour Booking Info', 'intravel'),
            'object_types'  => array( 'tour_booking', ), // Post type
            // 'show_on_cb' => 'yourprefix_show_if_front_page', // function should return a bool value
            // 'context'    => 'normal',
            // 'priority'   => 'high',
            // 'show_names' => true, // Show field names on the left
            // 'cmb_styles' => false, // false to disable the CMB stylesheet
            // 'closed'     => true, // true to keep the metabox closed by default
            // 'classes'    => 'extra-class', // Extra cmb2-wrap classes
            // 'classes_cb' => 'yourprefix_add_some_classes', // Add classes through a callback.
            'fields' => $fields
        ) );

        /*$meta_boxes['booking_detail'] = array(
            'id'         => 'booking_detail',
            'title'      => __( 'Booking Detail', 'intravel' ),
            'pages'      => array( 'tour_booking' ), // Post type
            'context'    => 'normal',
            'priority'   => 'low',
            'show_names' => true, // Show field names on the left
            'fields'     => $fields
        );

        return $meta_boxes;*/
    }

    function custom_admin_head() {
        $screen = get_current_screen();
        if($screen && $screen->post_type == 'tour_booking'){
            echo '<style type="text/css">
                #postbox-container-1{
                    display: none !important;
                }
            </style>';
        }
    }

    function custom_admin_menu() {
        $edit = add_submenu_page( 'edit.php?post_type=tour',
            __( 'Booking', 'intravel' ),
            __( 'Booking', 'intravel' ),
            'manage_options', 'tour-booking',
            array($this, 'admin_management_page') );
    }

    function admin_management_page() {

        $list_table = new Tour_Booking_List_Table();
        $list_table->prepare_items();

        ?>
        <div class="wrap">

            <h1><?php
                echo esc_html( __( 'Tour Booking', 'intravel' ) );
                if ( current_user_can( 'edit_posts' ) ) {
                    echo ' <a href="' . esc_url( admin_url("post-new.php?post_type=tour_booking") ) . '" class="page-title-action">' . esc_html( __( 'Add New', 'intravel' ) ) . '</a>';
                }

                if ( ! empty( $_REQUEST['s'] ) ) {
                    echo sprintf( '<span class="subtitle">'
                        . __( 'Search results for &#8220;%s&#8221;', 'intravel' )
                        . '</span>', esc_html( $_REQUEST['s'] ) );
                }
                ?></h1>
            <?php
            $form_url = admin_url('edit.php?post_type=tour_booking');
            if($_REQUEST['post_status']){
                $form_url .= '&post_status='.$_REQUEST['post_status'];
            }

            wp_enqueue_script('jquery');
            wp_enqueue_script('jquery-ui-core');
            wp_enqueue_script('jquery-ui-datepicker');

            ?>
            <form method="post" action="" data-action="<?php echo $form_url; ?>">
                <input type="hidden" name="page" value="<?php echo esc_attr( $_REQUEST['page'] ); ?>" />
                <?php $list_table->views(); ?>
                <?php $list_table->search_box( __( 'Search Tour Booking', 'intravel' ), 'tour-booking' ); ?>
                <?php $list_table->display(); ?>
            </form>

        </div>
        <?php
    }

    function custom_post_row_actions($actions, $post){
        //check for your post type
        if ($post->post_type =="tour_booking"){
            if(isset($actions['inline hide-if-no-js'])){
                unset($actions['inline hide-if-no-js']);
            }
            if(isset($actions['view'])){
                unset($actions['view']);
            }

            if(get_post_status( $post->ID ) != 'trash'){
                $status = get_post_meta($post->ID, 'intravel_status', true);
                if($status != 'cancelled'){
                    $actions['cancel_tour_booking'] = '<a href="'.admin_url('admin-ajax.php?action=cancel_tour_booking&post_id='.$post->ID).'">Cancel</a>';
                }
                if($status != 'on-hold'){
                    $actions['onhold_tour_booking'] = '<a href="'.admin_url('admin-ajax.php?action=onhold_tour_booking&post_id='.$post->ID).'">On hold</a>';
                }
                if($status != 'completed'){
                    $actions['complete_tour_booking'] = '<a href="'.admin_url('admin-ajax.php?action=complete_tour_booking&post_id='.$post->ID).'">Complete</a>';
                }
            }
        }

        return $actions;
    }

    /* Add custom column to post list */
    function custom_columns_head( $columns )
    {
        $screen = get_current_screen();
        if ($screen->post_type == 'tour_booking') {
            $columns = array();
            $columns['cb'] = '<input type="checkbox" />';
            $columns['id'] = __('Booking ID', 'intravel');
            $columns['tour'] = __('Tour', 'intravel');
            $columns['tour_date'] = __('Tour Start Date', 'intravel');
            $columns['tour_service'] = __('Additional Services', 'intravel');
            $columns['price'] = __('Total Price', 'intravel');
            $columns['status'] = __('Status', 'intravel');
            $columns['payment_method_title'] = __('Payment Method', 'intravel');
            $columns['date'] = __('Created Date', 'intravel');
        }

        return $columns;
    }

    /* Add custom column to post list */
    function custom_columns_content( $column, $post_ID ) {
        $screen = get_current_screen();
        if($screen->post_type == 'tour_booking'){
            if ($column == 'id') {
                $read = get_post_meta($post_ID, 'intravel_read', true);
                echo '<a href="'.get_edit_post_link($post_ID).'" class="'.($read === '0' ? 'unread' : 'read').'">#'.$post_ID.'</a>';
            }
            elseif($column == 'tour') {
                $tour = get_post_meta($post_ID, 'intravel_tour', true);
                $link = admin_url('edit.php?post_type=tour_booking');
                if(isset($_GET['orderby'])){
                    $link = add_query_arg('orderby', $_GET['orderby'], $link);
                }
                if(isset($_GET['order'])){
                    $link = add_query_arg('order', $_GET['order'], $link);
                }
                if(isset($_GET['booking_status'])){
                    $link = add_query_arg('order', $_GET['booking_status'], $link);
                }
                $link = add_query_arg('tour_id', $tour, $link);
                echo '<a href="' . $link . '">' . get_the_title($tour) . '</a>';
            }
            elseif($column == 'tour_date'){
                $date = get_post_meta($post_ID, 'intravel_start_date', true);
                $time = get_post_meta($post_ID, 'intravel_start_time', true);
                echo  $date ? date(get_option('date_format', $date)) : '';
                echo $time ? ' '.$time : '';
            }elseif($column == 'tour_service'){
                $services = wp_get_post_terms($post_ID, 'tour_service');
                $service_name = array();
                if($services){
                    foreach ($services as $service){
                        if($service->parent){
                            $parent = get_term($service->parent, 'tour_service');
                            $service_name[] = $parent->name .' '.$service->name;
                        }
                        else{
                            $service_name[] = $service->name;
                        }
                    }
                }
                echo  implode(', ',$service_name);
            }
            elseif($column == 'price'){
                echo  it_price(get_post_meta($post_ID, 'intravel_price', true));
            }
            elseif($column == 'status'){
                echo it_get_status(get_post_meta($post_ID, 'intravel_status', true));
            }
            elseif($column == 'payment_method_title'){
                $payment_method = get_post_meta($post_ID, 'intravel_payment_method', true);
                $link = '';
                if($payment_method == 'woocommerce'){
                    $order = get_post_meta($post_ID, 'intravel_woocommerce_order', true);
                    $link = ' <a href="'.get_edit_post_link($order).'" target="_blank">#'.$order.'</a>';
                }

                echo  it_get_payment_method_title($payment_method).$link;
            }
        }
    }

    function custom_tour_booking_sortable_columns($columns){
        $columns['id'] = __('Booking ID', 'intravel');
        $columns['tour'] = __('Tour', 'intravel');
        $columns['tour_date'] = __('Tour Date', 'intravel');
        $columns['price'] = __('Total Price', 'intravel');
        $columns['status'] = __('Status', 'intravel');
        $columns['payment_method_title'] = __('Payment Method', 'intravel');
        $columns['date'] = __('Created Date', 'intravel');

        return $columns;
    }

    function custom_request($vars){
        if ( isset( $vars['orderby'] )){
            if($vars['orderby'] == 'id') {
                $vars = array_merge( $vars, array(
                    'meta_key' => 'ID', //Custom field key
                    'orderby' => 'meta_value_num') //Custom field value (number)
                );
            }
            elseif ($vars['orderby'] == 'tour'){
                $vars = array_merge( $vars, array(
                    'meta_key' => 'intravel_tour', //Custom field key
                    'orderby' => 'meta_value_num') //Custom field value (number)
                );
            }
            elseif ($vars['orderby'] == 'tour_date'){
                $vars = array_merge( $vars, array(
                    'meta_key' => 'intravel_start_date', //Custom field key
                    'orderby' => 'meta_value') //Custom field value (number)
                );
            }
            elseif ($vars['orderby'] == 'price'){
                $vars = array_merge( $vars, array(
                    'meta_key' => 'intravel_price', //Custom field key
                    'orderby' => 'meta_value') //Custom field value (number)
                );
            }
            elseif ($vars['orderby'] == 'status'){
                $vars = array_merge( $vars, array(
                    'meta_key' => 'intravel_status', //Custom field key
                    'orderby' => 'meta_value') //Custom field value (number)
                );
            }
            elseif ($vars['orderby'] == 'payment_method_title'){
                $vars = array_merge( $vars, array(
                    'meta_key' => 'intravel_payment_method', //Custom field key
                    'orderby' => 'meta_value') //Custom field value (number)
                );
            }
        }

        if(isset($_REQUEST['from_date']) || isset($_REQUEST['to_date'])){

            $vars['date_query'] = array();
            if($_REQUEST['from_date']){
                $from_date = strtotime($_REQUEST['from_date']) - 86400;
                $vars['date_query']['after'] = array(
                    'year' => date('Y', $from_date),
                    'month' => date('m', $from_date),
                    'day' => date('d', $from_date),
                );
            }
            if($_REQUEST['to_date']){
                $to_date = strtotime($_REQUEST['to_date']) + 86400;
                $vars['date_query']['before'] = array(
                    'year' => date('Y', $to_date),
                    'month' => date('m', $to_date),
                    'day' => date('d', $to_date),
                );
            }
        }

        if(isset($_REQUEST['booking_status']) && $_REQUEST['booking_status']){

            $vars['meta_query'] = array();
            $vars['meta_query'][] =  array(
                'key' => 'intravel_status',
                'value' => $_REQUEST['booking_status']
            );
        }

        if(isset($_REQUEST['tour_id']) && $_REQUEST['tour_id']){
            if(!isset($vars['meta_query']) || !is_array($vars['meta_query'])){
                $vars['meta_query'] = array();
            }

            $vars['meta_query'][] =  array(
                'key' => 'intravel_tour',
                'value' => $_REQUEST['tour_id']
            );
        }

        return $vars;
    }

    function custom_save_post($post_id){
        if(get_post_type($post_id) == 'tour_booking' && get_post_status($post_id) == 'publish'){
            $payment_method = get_post_meta($post_id, 'intravel_payment_method', true);
            if(it_use_woocommerce_payment() && $payment_method == 'woocommerce'){
                $woocommerce_order = get_post_meta($post_id, 'intravel_woocommerce_order', true);
                if(!$woocommerce_order){
                    $IT_Woocommerce = new IT_Woocommerce();
                    $IT_Woocommerce->dynamically_create_tour_woo_order($post_id);
                }
            }
        }
    }

    function custom_restrict_manage_posts($post_type){
        if($post_type == 'tour_booking') {
            ?>
            <select name="booking_status">
                <option value="">Status</option>
                <?php $status = it_get_status(); ?>
                <?php
                    foreach ($status as $key=>$value){
                        ?>
                        <option
                            value="<?php echo $key; ?>" <?php echo isset($_REQUEST['booking_status']) && $_REQUEST['booking_status'] == $key ? 'selected' : ''; ?>>
                            <?php echo $value; ?>
                        </option>
                        <?php
                    }
                ?>
            </select>
            <label for="filter-by-date" class="screen-reader-text"><?php _e('Filter by date'); ?></label>
            <input type="text" class="booking-from-date" name="from_date"
                   placeholder="<?php _e('From Date', 'intravel'); ?>"
                   value="<?php echo isset($_REQUEST['from_date']) ? $_REQUEST['from_date'] : ''; ?>"/>
            <input type="text" class="booking-to-date" name="to_date" placeholder="<?php _e('To Date', 'intravel'); ?>"
                   value="<?php echo isset($_REQUEST['to_date']) ? $_REQUEST['to_date'] : ''; ?>"/>
            <?php
        }
    }

    function custom_bulk_actions($actions){
        if(isset($actions['edit'])){
            unset($actions['edit']);
        }

        return $actions;
    }

    function cancel_tour_booking(){
        if(isset($_GET['post_id']) && $_GET['post_id']){
            $boooking = new IT_Booking($_GET['post_id']);
            $boooking->changeStatus('cancelled');
            update_option('intravel_admin_message', array('updated'=>__('Booking has been cancelled', 'intravel')));
        }
        wp_redirect($_SERVER['HTTP_REFERER']);
    }

    function complete_tour_booking(){
        if(isset($_GET['post_id']) && $_GET['post_id']){
            $boooking = new IT_Booking($_GET['post_id']);
            $boooking->changeStatus('completed');
            update_option('intravel_admin_message', array('updated'=>__('Booking has been completed', 'intravel')));
        }
        wp_redirect($_SERVER['HTTP_REFERER']);
    }

    function onhold_tour_booking(){
        if(isset($_GET['post_id']) && $_GET['post_id']){
            $boooking = new IT_Booking($_GET['post_id']);
            $boooking->changeStatus('onhold');
            update_option('intravel_admin_message', array('updated'=>__('Booking has been hold', 'intravel')));
        }
        wp_redirect($_SERVER['HTTP_REFERER']);
    }

    function change_status($updated, $action, $field){
        if($action == 'updated'){
            $status = $field->get_data();
            $boooking = new IT_Booking($field->object_id);
            $boooking->changeStatus($status);
        }
    }

    function admin_notice(){
        $messages = get_option('intravel_admin_message');
        if($messages){
            foreach ($messages as $status => $message){
                echo '<div class="'.$status.'">
               <p>'.$message.'</p>    
            </div>';
            }

            update_option('intravel_admin_message', '');
        }
    }

    function admin_scripts(){
        $screen = get_current_screen();
        if($screen->post_type == 'tour_booking') {
            wp_enqueue_style('cmb2', INTRAVEL_PLUGIN_URL . '/libs/cmb2/css/cmb2.min.css', array());
        }
    }
}

new IT_Tour_Booking_Post_Type();
?>