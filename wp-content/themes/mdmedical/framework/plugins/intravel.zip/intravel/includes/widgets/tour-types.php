<?php
/**
 * Widget API: Inwave_Intravel_Tour_Types class
 *
 * @package WordPress
 * @subpackage Widgets
 * @since 4.4.0
 */


class Inwave_Intravel_Tour_Types extends WP_Widget {

    function __construct() {
        $widget_ops = array('classname' => 'tour_types', 'description' => esc_html__('Display InTravel tour types.', 'intravel'));
        parent::__construct('types', esc_html__('InTravel Tour Types', 'intravel'), $widget_ops);

    }

    public function widget($args, $instance)
    {
        $output = '';
        $current_taxonomy = 'tour_type';
        $limit = isset($instance['limit']) ? strip_tags($instance['limit']) : 3;

        $type_cloud = wp_tag_cloud( apply_filters( 'widget_tour_types_args', array(
            'taxonomy' => $current_taxonomy,
            'number' => $limit,
            'echo' => false
        ) ) );

        if ( empty( $type_cloud ) ) {
            return;
        }

        $output .= $args['before_widget'];
        $title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : __( 'Tour Types', 'intravel' );
        $title = apply_filters( 'widget_title', $title, $instance, $this->id_base );
        if ($title) {
            $output .= $args['before_title'] . $title . $args['after_title'];
        }
        $output .= '<div class="widget-tour-types">';
            $output .= $type_cloud;
        $output .= '</div>';
        $output .= $args['after_widget'];

        echo $output;
    }

    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;
        $instance['title'] = strip_tags($new_instance['title']);
        $instance['limit'] = strip_tags($new_instance['limit']);

        return $instance;
    }

    function form( $instance ) {
        $instance = wp_parse_args( (array) $instance, array( 'title' => __( 'Tour Types', 'intravel' ), 'limit' => '3' ) );
        $title = strip_tags($instance['title']);
        $limit = esc_attr($instance['limit']);
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'inevent'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('limit')); ?>"><?php esc_html_e('Limit:', 'motohero'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('limit')); ?>" name="<?php echo esc_attr($this->get_field_name('limit')); ?>" type="text" value="<?php echo esc_attr($limit); ?>" />
        </p>
    <?php
    }
}

function tour_types_widget() {
    register_widget('Inwave_Intravel_Tour_Types');
}
add_action('widgets_init', 'tour_types_widget');