<?php

/*
 * Inwave Slider for Visual Composer
 */
if (!class_exists('Inwave_Search_Tour_Slider')) {

    class Inwave_Search_Tour_Slider extends Inwave_Shortcode{

        protected $name = 'inwave_search_tour_slider';

        function init_params(){
            return array(
                "name" => __("Info Search Tour in Slider", 'inwavethemes'),
                "base" => $this->name,
                "class" => "inwave_search_tour_slider",
                'icon' => 'iw-default',
                'category' => 'Custom',
                "description" => __("This is add-on search tour slider in Travel", "inwavethemes"),
                "show_settings_on_create" => true,
                "params" => array(
                    array(
                        "type" => "dropdown",
                        "admin_label" => true,
                        "heading" => "Style",
                        "param_name" => "style",
                        "value" => array(
                            'style1' => 'style1',
                            'style2' => 'style2'
                        )
                    ),
                    array(
                        "type" => "iwevent_preview_image",
                        "heading" => __("Preview Style", "inwavethemes"),
                        "param_name" => "preview_style1",
                        "value" => get_template_directory_uri() . '/assets/images/shortcodes/preview-search-tour-style1.png',
                        "dependency" => array('element' => 'style', 'value' => 'style1')
                    ),
                    array(
                        "type" => "iwevent_preview_image",
                        "heading" => __("Preview Style", "inwavethemes"),
                        "param_name" => "preview_style2",
                        "value" => get_template_directory_uri() . '/assets/images/shortcodes/preview-search-tour-style2.png',
                        "dependency" => array('element' => 'style', 'value' => 'style2')
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => __("Extra Class", "inwavethemes"),
                        "param_name" => "extra_class",
                        "description" => __('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', "inwavethemes")
                    ),
                )
            );
        }

        // Shortcode handler function for search tour
        function init_shortcode($atts, $content = null) {

            if(!class_exists('inTravel')){
                return __('Please active the plugin inTravel', 'inwavethemes');
            }

            $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( $this->name, $atts ) : $atts;

            $output =  $extra_class = $style = '';

            extract(shortcode_atts(array(
                'extra_class'       => '',
                'style'             => ''
            ), $atts));
            $destinations = get_terms( array(
                'taxonomy' => 'destination',
                'hide_empty' => false,
            ) );
            $tour_types = get_terms(array('taxonomy' => 'tour_type'));

            if($style == 'style1') {
                $min_price = isset($_GET['min_price']) ? esc_attr($_GET['min_price']) : '';
                $max_price = isset($_GET['max_price']) ? esc_attr($_GET['max_price']) : '';
                // Find min and max price in current result set
                $prices = it_get_filtered_price();
                $min = floor($prices->min_price);
                $max = ceil($prices->max_price);
                $content = '';
                if ($min !== $max) {
                    if (it_is_taxable() && 'incl' === it_get_option('tax_display_tours', 'excl') && it_get_option('prices_include_tax', 'no') === 'no') {
                        $tax = it_get_tax();
                        $max = $max + $tax;
                    }
                    ob_start();
                    ?>
                    <div class="form-group">
                        <div class="tour_price_slider_wrapper">
                            <div class="tour_price_slider" style="display:none;"></div>
                            <div class="tour_price_slider_amount">
                                <input type="text" class="tour_min_price" name="min_price"
                                       value="<?php echo esc_attr($min_price); ?>"
                                       data-min="<?php echo esc_attr(apply_filters('it_price_filter_widget_min_amount', $min)); ?>"
                                       placeholder="<?php echo esc_attr__('Min price', 'intravel'); ?>"/>
                                <input type="text" class="tour_max_price" name="max_price"
                                       value="<?php echo esc_attr($max_price); ?>"
                                       data-max="<?php echo esc_attr(apply_filters('it_price_filter_widget_max_amount', $max)); ?>"
                                       placeholder="<?php echo esc_attr__('Max price', 'intravel'); ?>"/>
                                <div class="price_label" style="display:none;">
                                    <?php echo __('Price:', 'intravel'); ?> <span class="from"></span> &mdash;
                                    <span class="to"></span>
                                </div>
                                <div class="clear"></div>
                            </div>
                        </div>
                    </div>
                    <?php
                    $content = ob_get_clean();
                }

                $output .= '<div class="search-tour-style-1">';
                $output .= '<form class="search-form" action="'.esc_url(it_get_search_form_url()).'" method="post">';
                $output .= '<div class="row">';
                $output .= '<div class="col-md-3 col-sm-6 col-xs-12">';
                $output .= '<div class="iw-address-tour">';
                $output .= '<select name="destination">';
                $output .= '<option value="">'.__('Tour Destination', 'intravel').'</option>';
                if($destinations){
                    $destination_value = isset($_GET['destination']) ? esc_attr($_GET['destination']) : '';
                    foreach ($destinations as $destination){
                        $output .= '<option value="'.esc_attr($destination->slug).'"  '.($destination_value == $destination->slug ? 'selected' : '').'>'.$destination->name.'</option>';
                    }
                }
                $output .= '</select>';
                $output .= '<span class="line"></span>';
                $output .= '<img alt ="image" src ="' . get_template_directory_uri() . '/assets/images/shortcodes/address_search_style_1.png">';
                $output .= '</div>';
                $output .= '</div>';
                $output .= '<div class="col-md-3 col-sm-6 col-xs-12">';
                $output .= '<div class="iw-address-tour">';
                $output .= '<select name="tour_type">';
                $output .= '<option value="">'.__('Tour type', 'intravel').'</option>';
                $tour_types = get_terms( array(
                    'taxonomy' => 'tour_type',
                    'hide_empty' => false,
                ) );
                if($tour_types){
                    $tour_type_value = isset($_GET['tour_type']) ? esc_attr($_GET['tour_type']) : '';
                    foreach ($tour_types as $tour_type){
                        $output .= '<option value="'.esc_attr($tour_type->slug).'"  '.($tour_type_value == $tour_type->slug ? 'selected' : '').'>'.$tour_type->name.'</option>';
                    }
                }
                $output .= '</select>';
                $output .= '<span class="line"></span>';
                $output .= '<img alt ="image" src ="' . get_template_directory_uri() . '/assets/images/shortcodes/address_search_style_2.png">';
                $output .= '</div>';
                $output .= '</div>';
                $output .= '<div class="col-md-3 col-sm-6 col-xs-12">';
                $output .= '<div class="iw-address-tour">';
                $output .= '<div class="iw-group-travel iw-price">';
                $output .= $content;
                $output .= '</div>';
                $output .= '<img alt ="image" src ="' . get_template_directory_uri() . '/assets/images/shortcodes/price_style1.png">';
                $output .= '</div>';
                $output .= '</div>';
                $output .= '<div class="col-md-3 col-sm-6 col-xs-12">';
                $output .= '<div class="iw-submit-tour">';
                $output .= '<input type="submit" value="' . __('Discover All Tours', 'inwavethemes') . '">';
                $output .= '<i class="fa fa-long-arrow-right"></i>';
                $output .= '<div class="line"></div>';
                $output .= '</div>';
                $output .= '</div>';
                $output .= '</div>';
                $output .= '</form>';
                $output .= '</div>';
            }else{
                $output .= '<div class="search-tour-style-2'. $extra_class .'">';
                    $output .= '<form class="search-form-style2" action="'.esc_url(it_get_page_permalink('tours')).'" method="get">';
                    $output .= '<span class="icon-click"></span>';
                        $output .= '<div class="row">';
                            $output .= '<div class="col-md-8 col-sm-8 col-xs-12">';
                                $output .= '<div class="iw-address-tour">';
                                $output .= '<i class="ion-search"></i>';
                                $output .= '<input type="text" placeholder="'.esc_html__('Enter tour name', 'inwavethemes').'" name="s" value="'.(isset($_GET['s']) ? esc_attr($_GET['s']) : '').'">';
                                $output .= '</div>';
                                $output .= '<div class="iw-group-travel">';
                                    $output .= '<i class="ion-ios-paper-outline"></i>';
                                    $output .= '<select class="form-control js-selected " name="tour_type">';
                                    $output .= '<option value="">'.esc_html__('Tour type', 'inwavethemes').'</option>';
                                    if($tour_types){
                                        $tour_type_value = isset($_GET['tour_type']) ? esc_attr($_GET['tour_type']) : '';
                                        foreach ($tour_types as $tour_type){
                                            $output .= '<option value="'.esc_attr($tour_type->slug).'" '.($tour_type_value == $tour_type->slug ? 'selected' : '').'>'.$tour_type->name.'</option>';
                                        }
                                    }
                                    $output .= '</select>';
                                $output .= '</div>';
                                $output .= '<div class = "iw-departure">';
                                $output .= '<input type = "text" placeholder = "'.esc_html__('Tour start date', 'inwavethemes').'" class="iw-search-arrival has-date-picker">';
                                $output	.= '<i class="ion-calendar"></i>';
                                $output .= '</div>';
                            $output .= '</div>';
                            $output .= '<div class="col-md-4 col-sm-4 col-xs-12">';
                                $output .= '<div class="iw-destination-tour">';
                                    $output .= '<select class="form-control js-selected " name="destination">';
                                    $output .= '<option value="">'.esc_html__('Destination', 'inwavethemes').'</option>';
                                    if($tour_types){
                                        $destination_value = isset($_GET['destination']) ? esc_attr($_GET['destination']) : '';
                                        foreach ($destinations as $destination){
                                            $output .= '<option value="'.esc_attr($destination->slug).'" '.($destination_value == $destination->slug ? 'selected' : '').'>'.$destination->name.'</option>';
                                        }
                                    }
                                    $output .= '</select>';
                                $output .= '</div>';
                                $output .= '<div class="iw-search-now">';
                                $output .= '<i class="ion-paper-airplane"></i>';
                                $output .= '<button class="theme-bg">'.esc_html__('Search', 'intravel').'</button>';
                                $output .= '</div>';
                            $output .= '</div>';
                        $output .= '</div>';
                    $output .= '</form>';
                $output .= '</div>';
            }
            return $output;
        }
    }
}

new Inwave_Search_Tour_Slider;

//if (class_exists('WPBakeryShortCodesContainer')) {
//    class WPBakeryShortCode_Inwave_Search_Tour_Slider extends WPBakeryShortCodesContainer {
//    }
//}