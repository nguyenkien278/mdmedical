<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
class IT_Location_Post_Type{
    function __construct()
    {
        add_action('init', array($this, 'register'));
        //add_action( 'admin_menu', array($this, 'add_admin_menu') );
        //add_action( 'admin_init', array($this, 'custom_menu_item_redirect'), 1 );
        add_action('cmb2_admin_init', array($this, 'custom_taxonomy_metabox'));
        add_action( 'created_term', array( $this, 'save_term' ), 10, 3 );
        //add_action( 'edited_terms', array( $this, 'save_term' ), 10, 2 );
    }

    function register(){
        $labels = array(
            'name'              => _x( 'Destinations', 'intravel' ),
            'singular_name'     => _x( 'Destination', 'intravel' ),
            'search_items'      => __( 'Search Destinations' ),
            'all_items'         => __( 'All Destinations' ),
            'parent_item'       => __( 'Parent Destination' ),
            'parent_item_colon' => __( 'Parent Destination:' ),
            'edit_item'         => __( 'Edit Destination' ),
            'update_item'       => __( 'Update Destination' ),
            'add_new_item'      => __( 'Add New Destination' ),
            'new_item_name'     => __( 'New Destination Name' ),
            'menu_name'         => __( 'Destinations' ),
        );

        $args = array(
            'hierarchical'      => true,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_in_menu'      => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array( 'slug' => it_get_option('destination_slug', 'destination' )),
        );

        register_taxonomy( 'destination', array( 'tour' ), $args );
    }

    function add_admin_menu(){
        //add_menu_page( 'Location', 'Location', 'manage_options', 'destination', 'destination', 'dashicons-tickets', 6  );
    }

    function adminFields(){

    }

    function custom_menu_item_redirect() {

        $menu_redirect = isset($_GET['page']) ? $_GET['page'] : false;

        if($menu_redirect == 'destination' ) {
            wp_safe_redirect( admin_url( 'edit-tags.php?taxonomy=destination' ));
            exit();
        }
    }

    function custom_taxonomy_metabox(){
        $prefix = 'intravel_';

        $cmb_term = new_cmb2_box( array(
            'id'               => $prefix . 'destination_metabox',
            'title'            => 'Destination Metabox',
            'object_types'     => array( 'term' ),
            'taxonomies'       => array( 'destination'),
            'new_term_section' => true,
        ) );

        $cmb_term->add_field( array(
            'name'      => __('Image','intravel'),
            'id'        => $prefix . 'image',
            'type'      => 'file',
        ) );
        /*$cmb_term->add_field( array(
            'name'      => __('Openweathermap City ID','intravel'),
            'id'        => $prefix . 'openweathermap_city_id',
            'type'      => 'text',
        ) );*/
        $cmb_term->add_field( array(
            'name'      => 'Destination info',
            'desc'      => 'each row is a title|value Ex. Area|20 km2',
            'id'        => $prefix . 'info',
            'type'      => 'text',
            'repeatable' => true,
        ) );
        $cmb_term->add_field( array(
            'name'      => 'Destination map',
            'id'        => $prefix . 'map',
            'type'      => 'iwmap',
        ) );
    }

    function save_term($term_id, $tt_id, $taxonomy = ''){
        $term = get_term($term_id);
        if($term && $term->taxonomy == 'destination'){
            update_term_meta($term_id, 'average_rating', 0);
        }
    }
}

new IT_Location_Post_Type();
?>