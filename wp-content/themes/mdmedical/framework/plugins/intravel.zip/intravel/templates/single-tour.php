<?php
get_header('tour');

$tour = it_get_tour();
$schedules = $tour->get_schedules();
$galleries = $tour->get_gallery_attachment_ids();
$total_reviews = $tour->get_review_count();
$destinations = $tour->get_destinations();

$rating = $tour->get_average_rating();
$review_count = $tour->get_review_count();
$duration = $tour->get_duration();
$tour_types = $tour->get_types();
$price = $tour->get_display_price();
$regular_price = $tour->get_regular_price();
$discount = $tour->discount;
$tour_tags = $tour->get_tour_tag();
$sidebar_position = Inwave_Helper::getPostOption('sidebar_position', 'sidebar_position');
$post_content = get_post($tour->ID)->post_content;
$adult_ticket = $tour->tickets;
$chilren_ticket = $tour->children_tickets;

?>

<div class="page-content travel-detail">
	<div class="main-content">
		<?php
			$heading_image_url = '';
            if($tour->heading_image){
                $heading_image_url = $tour->heading_image;
            }else{
                $image_post = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');
                if ($image_post){
                    $heading_image_url = $image_post[0];
                } else {
                    if(!empty($galleries)){
						reset($galleries);
                        $heading_image_url = current($galleries);
                    }
                }
            }
		?>
        <div class="post-feature<?php echo $heading_image_url ? '' : ' no-image-post' ?>">
			<?php if ($heading_image_url){ ?>
				<div class="tour-feature-img single" style="background: url('<?php echo esc_url($heading_image_url); ?>')  no-repeat scroll center center / cover"></div>
			<?php } ?>
			<div class="post-head">
				<div class="container">
					<div class="post-head-content">
						<div class="destination">
							<?php
                                if ($destinations){
                                    $destination_html = array();
                                    foreach($destinations as $destination){
                                    $destination_html[] = '<a href="'.esc_url(get_term_link($destination->slug, 'destination')).'" class="destination">'.$destination->name.'</a>';
                                    }
                                    echo implode(' / ', $destination_html);
                                }
							?>
						</div>
						<h3 class="post-title"><?php the_title(); ?></h3>
						<div class="post-meta">
							<ul>
								<?php if ($duration) : ?>
								<li class="meta-duration">
									<span class="date"><i class="fa fa-clock-o"></i> <?php echo $duration; ?></span>
								</li>
								<?php endif; ?>
								<li class="meta-comment">
									<span class="comment-count"><i class="fa fa-comments"></i> <?php echo $total_reviews; ?> <?php echo $total_reviews > 1 ? esc_html__('Reviews', 'intravel') : esc_html__('Review', 'intravel') ?></span>
								</li>
								<li class="meta-rating">
									<div class="iwt-rating">
                                        <?php echo $tour->get_rating_html(); ?>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
        </div>
		 
		<div class="container">
			<div class="row">
				<div class="<?php echo esc_attr(inwave_get_classes('container',$sidebar_position))?> blog-content single-content">
                    <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
						<div class="post-item">
							
							<div class="post-content">
								<?php if(!empty($galleries)) {
									$galleryConfig = '{';
									$galleryConfig .= '"navigation":true';
									$galleryConfig .= ',"navigationText": ["<i class=\"fa fa-arrow-left\"></i>", "<i class=\"fa fa-arrow-right\"></i>"]';
									$galleryConfig .= ',"autoPlay":false';
									$galleryConfig .= ',"slideSpeed":800';
									$galleryConfig .= ',"pagination":false';
									$galleryConfig .= ',"singleItem":true';
									$galleryConfig .= '}';
								?>
									<div class="post-gallery">
										<div class="owl-carousel" data-plugin-options='<?php echo $galleryConfig ?>'>
											<?php
												foreach($galleries as $image_id => $image_url){
													echo '<div class="tour-gallery-img" style="background: url(' .esc_url($image_url). ')  no-repeat scroll center center / cover"></div>';
												}
											?>
										</div>
									</div>
								<?php } ?>
								
                                <div class="tour-social-items">
                                    <h3 class="theme-color"><?php echo esc_html__('Tour information', 'intravel'); ?></h3>
                                    <ul class="socials">
                                        <?php if (!empty($inwave_theme_option['social_links'])) {
                                        $social_links = $inwave_theme_option['social_links'];
                                        unset($social_links[0]);
                                        ?>
                                        <?php foreach ($social_links as $social_link) : ?>
                                            <li>
                                                <a href="<?php echo esc_url($social_link['link']) ?>">
                                                    <i class="fa <?php echo esc_attr($social_link['icon']) ?>"></i>
                                                </a>
                                            </li>
                                        <?php endforeach; ?>
                                        <?php } ?>
                                    </ul>
                                    <div class="iw-clear_both"></div>
                                </div>
                                <div class="iw-tour-info">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                            <div class="info-left">
                                                <ul>
                                                    <li class="destinations">
                                                        <label><i class="fa fa-map-marker"></i> <?php echo esc_html__('Location', 'intravel') ?></label>
                                                        <span>
                                                            <?php
                                                                if ($destinations){
                                                                    $destination_html = array();
                                                                    foreach($destinations as $destination){
                                                                        $destination_html[] = '<a href="'.esc_url(get_term_link($destination->slug, 'destination')).'" class="destination">'.$destination->name.'</a>';
                                                                    }
                                                                    echo implode(' / ', $destination_html);
                                                                }
                                                            ?>
                                                        </span>
                                                    </li>
                                                    <?php if ($duration) : ?>
                                                    <li>
                                                        <label><i class="fa fa-clock-o"></i> <?php echo esc_html__('Duration', 'intravel') ?></label>
                                                        <span class="duration"><?php echo $duration ?></span>
                                                    </li>
                                                    <?php endif; ?>
                                                    <li>
                                                        <label><i class="fa fa-comments"></i> <?php echo esc_html__('Reviews', 'intravel') ?></label>
                                                        <span class="reviewed"><?php echo $total_reviews; ?> <?php echo $total_reviews > 1 ? esc_html__('Reviews', 'intravel') :esc_html__('Review', 'intravel') ?></span>
                                                    </li>
													<li>
														<label><i class="fa fa-user"></i> <?php echo esc_html__('Adults', 'intravel') ?></label>
														<span class="adult-ticket">
															<?php if ($adult_ticket || ($adult_ticket!=0)){ ?>
																<?php echo $adult_ticket; ?>
															<?php } else {
																echo esc_html__('Unlimited', 'intravel');
															}?>
														</span>
													</li>
													<li>
														<label><i class="fa fa-user"></i> <?php echo esc_html__('Children', 'intravel') ?></label>
														<span class="adult-ticket">
															<?php if ($chilren_ticket || ($chilren_ticket!=0)){ ?>
																<?php echo $chilren_ticket; ?>
															<?php } else {
																echo esc_html__('Unlimited', 'intravel');
															}?>
														</span>
													</li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                                            <div class="info-right">
												<?php $feature_lists = $tour->get_feature_list();
												if ($feature_lists){
												?>
                                                <ul>
                                                    <li class="info-right-title">
                                                        <label><?php echo esc_html__('Tour included and not included', 'intravel') ?></label>
                                                    </li>
                                                    <?php 
                                                        foreach ($feature_lists as $feature_list=>$include){
                                                            ?>
                                                            <li class="tour-included <?php echo $include ? 'included' : 'not-included'?>">
                                                                <?php echo $include ? '<i class="icon ion-ios-checkmark"></i>' : '<i class="icon ion-ios-close-outline"></i>'?><span><?php echo $feature_list; ?></span>
                                                            </li>
                                                            <?php
                                                        }
                                                    ?>
                                                </ul>
												<?php } ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="booking-tour">
										<div class="price">
											<span class="theme-color"><?php echo it_price($price); ?></span>
										</div>
                                    </div>
                                </div>
                                
								
								<?php $class_active = (!empty($schedules) || !empty($post_content)); ?>
								<div class="iw-tabs tab-travel-detail">
									<div class="iw-tab-items">
									<?php if ($class_active) { ?>
										<div class="iw-tab-item active">
											 <div class="iw-tab-title"><i class="ion-document"></i><span><?php esc_html_e('Schedule', 'inevent'); ?></span></div>
										</div>
									<?php } ?>
										<div class="iw-tab-item <?php echo $class_active ? '' : 'active' ?>" data-hasmap="true">
											 <div class="iw-tab-title"><i class="ion-map"></i><span><?php esc_html_e('Tour Map', 'inevent'); ?></span></div>
										</div>
										<div class="iw-tab-item">
											 <div class="iw-tab-title"><i class="ion-chatbubbles"></i><span><?php esc_html_e('Reviews', 'inevent'); ?></span></div>
										</div>
									
									
									</div>
									<div class="iw-tab-content">
										<?php if ($class_active) { ?>
											<div class="iw-tab-item-content">
											<h3 class="post-title"><?php the_title(); ?></h3>
											<?php if (!empty($post_content)) { ?>
												<div class="post-desc">
													<?php echo apply_filters('the_content', $post_content); ?>
												</div>
											<?php } ?>
											<?php if (!empty($schedules)) { ?>
												<div class="post-schedules">
													<?php
														$i = 1;
														foreach($schedules as $schedule) : ?>
															<div class="schedules-item">
																<span class="numerical-booking"><?php echo $i; ?></span>
																<h3 class="schedules-title theme-color"><?php echo $schedule->title; ?></h3>
																<div class="schedules-description"><?php echo apply_filters('the_content', $schedule->description); ?></div>
																<div class="address-time theme-color">
																	<ul>
																		<li>
																			<span class="address"><i class="fa fa-map-marker"></i> <?php echo $schedule->address; ?></span>
																		</li>
																		<li>
																			<span class="time"><i class="fa fa-clock-o"></i> <?php echo $schedule->date_time; ?></span>
																		</li>
																	</ul>
																</div>
															</div>
														<?php $i ++; endforeach; ?>
												</div>
											<?php } ?>
											</div>
										<?php 
										} ?>
											
										<div class="iw-tab-item-content <?php echo $class_active ? '' : 'iw-hidden' ?>">
											<div id="tour-map" class="tour-map">
											</div>
										</div>
										
										<?php
										// If comments are open or we have at least one comment, load up the comment template
										if (comments_open() || get_comments_number()){
										?>
											<div class="iw-tab-item-content iw-hidden">
												<?php comments_template(); ?>
											</div>
										<?php
										}
										?>
									
									</div>
								</div>
								
							</div>
						</div>
					</div><!-- #post-## -->
						
				</div>
                <?php if ($sidebar_position && $sidebar_position != 'none') { ?>
                    <div class="<?php echo esc_attr(inwave_get_classes('sidebar', $sidebar_position))?> iwtravel-detail-sidebar inwave-sidebar">
                        <?php
                        $sidebar_name = get_post_meta($tour->id, 'inwave_sidebar_name', true);
                        if(!$sidebar_name){
                            $sidebar_name = 'sidebar-tours-detail';
                        }
                        if (is_active_sidebar($sidebar_name) ) {  ?>
                            <div class="dynamic-tour-sidebar">
                                <?php dynamic_sidebar($sidebar_name); ?>
                            </div>
                        <?php } else { ?>

                            <div class="tour-booking-form-wrap">
                                <?php it_get_template_part('single-tour/form', 'booking'); ?>
                            </div>

                            <?php
                                $type_slug = array();
                                if($tour_types){
                                    foreach($tour_types as $tour_type){
                                        $type_slug[] = $tour_type->slug;
                                    }
                                }
                                $args = '';
                                $id = get_the_ID();
                                $number = 3;
                                $args['post_status'] = 'publish';
                                $args['post_type'] = 'tour';
                                $args['posts_per_page'] = $number;
                                $args['post__not_in'] = array($id);
                                $args['tax_query'] = array(
                                    'relation' => 'OR',
                                );
                                if(!empty($type_slug)){
                                    $args['tax_query'][] = array(
                                        'taxonomy' => 'tour_type',
                                        'field' => 'slug',
                                        'terms' => $type_slug
                                    );
                                }
                                $tour_tags = $tour->get_tags();
                                $tour_tag_slugs = array();
                                if($tour_tags){
                                    foreach($tour_tags as $tour_tag){
                                        $tour_tag_slugs[] = $tour_tag->slug;
                                    }
                                }
                                if(!empty($tour_tag_slugs)){
                                    $args['tax_query'][] = array(
                                        'taxonomy' => 'tour_tag',
                                        'field' => 'slug',
                                        'terms' => $tour_tag_slugs
                                    );
                                }
                                $query = new WP_Query($args);
                            ?>
                            <?php if ($query->have_posts()){ ?>
                                <div class="sidebar-interested iw-travel-tours">
                                    <h3 class="widget-title"><?php echo esc_html__('You may also interested', 'intravel') ?></h3>
                                    <div class="iw-interested">
                                        <?php
                                        if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post();
                                           $destinations = wp_get_post_terms(get_the_ID(), 'destination');

                                          // var_dump($destinations);
                                            ?>
                                            <div class="iw-tour-item iw-effect-img">
                                                <?php
                                                    $img = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');
                                                    $img_src = count($img) ? $img[0] : '';
                                                    $img_src = inwave_resize($img_src, 370, 255, true);
                                                ?>
                                                <?php if ($img){ ?>
                                                    <div class="image-wrap effect-1">
                                                        <img src="<?php echo esc_url($img_src); ?>" alt=""/>
                                                        <div class="icon-action">
                                                        <!--	<a class="iw-to-detail theme-bg" href="<?php echo get_permalink(); ?>">
                                                                <?php esc_html_e('Book now', 'inevent'); ?>
                                                            </a> -->
                                                            <a href="<?php echo get_permalink(); ?>" class="button-booking-tour theme-bg"><?php echo esc_html__('Book now', 'intravel') ?></a>
                                                        </div>
                                                    </div>
                                                <?php } ?>
                                                <div class="info-wrap">
                                                    <div class="info-left">
                                                        <h3 class="title"><a class="theme-color-hover" href="<?php echo get_permalink(); ?>"><?php echo get_the_title(); ?></a></h3>
                                                        <div class="post-meta">
                                                            <ul>
                                                                <?php if ($destinations) : ?>
                                                                <li class="destinations">
                                                                    <i class="fa fa-map-marker" aria-hidden="true"> </i>
                                                                    <?php
                                                                    if ($destinations){
                                                                        $destination_html = array();
                                                                        foreach($destinations as $destination){
                                                                            $destination_html[] = '<a href="'.esc_url(get_term_link($destination->slug, 'destination')).'" class="destination">'.$destination->name.'</a>';
                                                                        }
                                                                        echo implode(' / ', $destination_html);
                                                                    }
                                                                    ?>
                                                                </li>
                                                                <?php endif ?>
                                                                <?php if ($tour ->get_duration()) : ?>
                                                                    <li>
                                                                        <span class="duration"><i class="fa fa-clock-o"></i> <?php echo $tour ->get_duration(); ?></span>
                                                                    </li>
                                                                <?php endif ?>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <div class="tour-info-footer">
                                                    <?php if ($tour->get_price()) : ?>
                                                        <div class="tour-price">
                                                            <span class="theme-bg"><?php echo it_price($tour->get_price()); ?></span>
                                                        </div>
                                                        <?php endif; ?>
                                                        <?php if ($tour->get_rating_html()){
                                                            echo '<div class="tour-rate">'.$tour->get_rating_html().'</div>';
                                                        } ?>
                                                        <div style="clear: both"></div>
                                                    </div>
                                                    <div style="clear: both"></div>
                                                </div>
                                            </div>
                                        <?php
                                        endwhile;
                                        endif;
                                        ?>
                                    </div>
                                </div>
                            <?php } ?>

                            <?php if ($tour_tags) : ?>
                            <div class="sidebar-tag">
                                <h3 class="widget-title"><?php echo esc_html__('Tags', 'intravel') ?></h3>
                                <ul>
                                    <?php
                                    foreach ( $tour_tags as $tag ) {
                                        $tag_link = get_tag_link( $tag->term_id );
                                        echo '<li><a class="" href="'.esc_url($tag_link).'">'.$tag->name.'</a></li>';
                                    }
                                    ?>
                                </ul>
                            </div>
                            <?php endif; ?>

                        <?php } ?>

                    </div>
                <?php } ?>
			</div>
		</div>
	</div>
</div>

<?php get_footer(); ?>
