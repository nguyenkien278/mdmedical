<?php

if ( ! defined( 'ABSPATH' ) ) exit;

class IT_Settings {

	function __construct () {

		add_action( 'cmb2_admin_init', array($this, 'init_settings'));
		add_filter('admin_head', array($this, 'add_jquery_data'));
		add_filter('add_meta_boxes', array($this, 'add_jquery_data'));
	}

	public function add_jquery_data(){
		if ( isset( $_GET['page'] ) && $_GET['page'] == 'plg-intravel-options') {
			?>
			<style type="text/css">
				#normal-sortables, #mymetabox_revslider_0{
					display: none;
				}
			</style>
			<?php
		}
	}

	/**
	 * Conditionally displays a message if the $post_id is 2
	 *
	 * @param  array             $field_args Array of field parameters
	 * @param  CMB2_Field object $field      Field object
	 */
	static function before_row( $field_args, $field ) {
		$text = $field_args['before_row_text'];
		if($text){
			echo $text;
		}
	}


	/**
	 * Initialise settings
	 * @return void
	 */
	public function init_settings () {
		$options_key = 'plg-intravel-options';

		// configuration array
		$args = array(
			'key'     => $options_key,
			'title'   => 'Intravel Options Page',
			'topmenu' => 'edit.php',
			'postslug' => 'tour',
			'cols'    => 1,
			'boxes'	  => $this->intravel_options_add_boxes( $options_key ),
			'tabs'	  => $this->intravel_options_add_tabs(),
			'menuargs' => array(
				'menu_title' => 'Options',
			)
		);

		// create the options page
		new Cmb2_Metatabs_Options( $args );
	}

	/**
	 * Build settings fields
	 * @return array Fields to be displayed on settings page
	 */
	 function intravel_options_add_boxes ($options_key) {
		// holds all CMB2 box objects
		$boxes = array();

		// we will be adding this to all boxes
		$show_on = array(
			'key' => 'options-page',
			'value' => array( $options_key ),
		);

		$args = array(
			'posts_per_page'   => -1,
			'post_type'        => 'page',
			'post_status'      => 'publish',
		);

		$_pages = get_posts($args);
		$pages = array();
		foreach ($_pages as $page){
			$pages[$page->ID] = $page->post_title;
		}

		$fields = array(
			array(
				'id' 			=> 'checkout_page_id',
				'name'			=> __( 'Checkout Page' , 'intravel' ),
				'desc'	=> __( 'Select Checkout Page, it will be used to checkout tour.', 'intravel' ),
				'type'			=> 'select',
				'options'		=> $pages,
				'default'		=> '',
			),
			array(
				'id' 			=> 'checkorder_page_id',
				'name'			=> __( 'Checkorder Page' , 'intravel' ),
				'desc'	=> __( 'Select Checkorder Page.', 'intravel' ),
				'type'			=> 'select',
				'options'		=> $pages,
				'default'		=> '',
			),
			array(
				'id' 			=> 'tours_page_id',
				'name'			=> __( 'Tours Page' , 'intravel' ),
				'desc'	=> __( 'Select Tours Page.', 'intravel' ),
				'type'			=> 'select',
				'options'		=> $pages,
				'default'		=> '',
			),
			array(
				'id' 			=> 'default_tours_layout',
				'name'			=> __( 'Default tours layout' , 'intravel' ),
				'desc'	=> __( 'Select Default tours layout.', 'intravel' ),
				'type'			=> 'select',
				'options'		=> array(
					'grid' =>  __( 'Grid', 'intravel' ),
					'list' =>  __( 'list', 'intravel' ),
				),
				'default'		=> 'grid',
			),
			array(
				'id' 			=> 'default_tours_order',
				'name'			=> __( 'Default tours order' , 'intravel' ),
				'desc'	=> __( 'Select Default tours order.', 'intravel' ),
				'type'			=> 'select',
				'options'		=> array(
					'asc' =>  __( 'ASC', 'intravel' ),
					'desc' =>  __( 'DESC', 'intravel' ),
				),
				'default'		=> 'desc',
			),
			array(
				'id' 			=> 'default_tours_orderby',
				'name'			=> __( 'Default tours orderby' , 'intravel' ),
				'desc'	=> __( 'Select Default tours orderby.', 'intravel' ),
				'type'			=> 'select',
				'options'		=> array(
					'' =>  __( 'Ordering', 'intravel' ),
					'date' =>  __( 'Date', 'intravel' ),
					'price' =>  __( 'Price', 'intravel' ),
					'rating' =>  __( 'Rating', 'intravel' ),
					'popularity' =>  __( 'Popularity', 'intravel' ),
					'title' =>  __( 'Title', 'intravel' ),
				),
				'default'		=> '',
			),
			array(
				'id' 			=> 'thankyou_page_title',
				'name'			=> __( 'Thank you page title' , 'intravel' ),
				'desc'	=> __( 'This title will be displayed in thankyou page.', 'intravel' ),
				'type'			=> 'text',
				'default'		=> 'Congratulation! Your order has been confirmed!',
			),
			array(
				'id' 			=> 'thankyou_page_description',
				'name'			=> __( 'Thank you page description' , 'intravel' ),
				'desc'	=> __( 'This description will be displayed in thankyou page.', 'intravel' ),
				'type'			=> 'wysiwyg',
				'default'		=> 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras sollicitudin, tellus vitae condimentum egestas, libero dolor auctor tellus, eu consectetur neque elit quis nunc. Cras elementum pretium est.',
			),
		);

		$cmb = new_cmb2_box( array(
			'id'        => 'options_general',
			'title'     => __( 'General', 'intravel' ),
			'show_on'   => $show_on, // critical, see wiki for why
			'fields'   => $fields
		));
		$cmb->object_type( 'options-page' );  // critical, see wiki for why
		$boxes[] = $cmb;

		 $fields = array(
			 array(
				 'id' 			=> 'tour_slug',
				 'name'			=> __( 'Tour slug' , 'intravel' ),
				 'desc'	=> __( 'Default is tour.', 'intravel' ),
				 'type'			=> 'text',
				 'default'		=> 'tour',
			 ),
			 array(
				 'id' 			=> 'tour_type_slug',
				 'name'			=> __( 'Tour type slug' , 'intravel' ),
				 'desc'	=> __( 'Default is tour-type.', 'intravel' ),
				 'type'			=> 'text',
				 'default'		=> 'tour-type',
			 ),
			 array(
				 'id' 			=> 'tour_tag_slug',
				 'name'			=> __( 'Tour tag slug' , 'intravel' ),
				 'desc'	=> __( 'Default is tour-tag.', 'intravel' ),
				 'type'			=> 'text',
				 'default'		=> 'tour-tag',
			 ),
			 array(
				 'id' 			=> 'destination_slug',
				 'name'			=> __( 'Destination slug' , 'intravel' ),
				 'desc'	=> __( 'Default is destination.', 'intravel' ),
				 'type'			=> 'text',
				 'default'		=> 'destination',
			 ),
			 array(
				 'id' 			=> 'endpoint_booking_received',
				 'name'			=> __( 'Booking received enpoint' , 'intravel' ),
				 'desc'	=> __( 'Default is booking-received.', 'intravel' ),
				 'type'			=> 'text',
				 'default'		=> 'booking-received',
			 ),
		 );
		 $cmb = new_cmb2_box( array(
			 'id'        => 'options_slug',
			 'title'     => __( 'Slug', 'intravel' ),
			 'show_on'   => $show_on, // critical, see wiki for why
			 'fields'   => $fields
		 ));
		 $cmb->object_type( 'options-page' );  // critical, see wiki for why
		 $boxes[] = $cmb;

		 $fields = array(
			 array(
				 'id' 			=> 'google_map_api',
				 'name'			=> __( 'Google Map API' , 'intravel' ),
				 'desc'	=> __( 'The Google Map API. If empty We\'ll get value from theme options', 'intravel' ),
				 'type'			=> 'text',
				 'default'		=> '',
			 ),
			 array(
				 'id' 			=> 'map_lat',
				 'name'			=> __( 'Default Latitude' , 'intravel' ),
				 'desc'	=> __( 'Default is -33.8688', 'intravel' ),
				 'type'			=> 'text',
				 'default'		=> '-33.8688',
			 ),
			 array(
				 'id' 			=> 'map_lng',
				 'name'			=> __( 'Default Logtitude' , 'intravel' ),
				 'desc'	=> __( 'Default is 151.2195', 'intravel' ),
				 'type'			=> 'text',
				 'default'		=> '151.2195',
			 ),
			 array(
				 'id' 			=> 'map_zoom',
				 'name'			=> __( 'Default Zoom' , 'intravel' ),
				 'desc'	=> __( 'From 1 to 20', 'intravel' ),
				 'type'			=> 'text',
				 'default'		=> '15',
			 ),
			 array(
				 'id' 			=> 'map_polyline_color',
				 'name'			=> __( 'Polyline Color' , 'intravel' ),
				 'type'			=> 'colorpicker',
				 'default'		=> '#FF0000',
			 ),
			 array(
				 'id' 			=> 'map_polyline_stroke_opacity',
				 'name'			=> __( 'Polyline Stroke Opacity' , 'intravel' ),
				 'desc'	=> __( 'From 0 to 1', 'intravel' ),
				 'type'			=> 'text',
				 'default'		=> '0.5',
			 ),
			 array(
				 'id' 			=> 'map_polyline_stroke_weight',
				 'name'			=> __( 'Polyline Stroke Weight' , 'intravel' ),
				 'desc'	=> __( 'Default is 4', 'intravel' ),
				 'type'			=> 'text',
				 'default'		=> '4',
			 ),
		 );
		 $cmb = new_cmb2_box( array(
			 'id'        => 'options_map',
			 'title'     => __( 'Google Map', 'intravel' ),
			 'show_on'   => $show_on, // critical, see wiki for why
			 'fields'   => $fields
		 ));
		 $cmb->object_type( 'options-page' );  // critical, see wiki for why
		 $boxes[] = $cmb;

		$fields = array(
			array(
				'id' 			=> 'use_woocommerce_for_checkout',
				'name'			=> __( 'Use Woocommerce For Checkout', 'intravel' ),
				'desc'	=> __( 'If is checked the tax options and the email options will not working you can use it these settings in the woocommcerce', 'intravel' ),
				'before_row'   => array('IT_Settings', 'before_row'), // callback
				'before_row_text' => '<h3 class="payment-method-title">'.__('WOOCOMMERCE', 'intravel').'</h3>',
				'type'			=> 'checkbox',
				'default'		=> it_use_woocommerce_payment() ? true : false,
			),
			array(
				'id' 			=> 'completed_order_woocommerce_statuses',
				'name'			=> __( 'Completed Order Woocommerce Statuses', 'intravel' ),
				'desc'	=> __( 'Which WooCommerce statuses do you want to consider as completed so that the item is no longer treated as available?', 'intravel' ),
				'type'			=> 'multicheck',
				'options'		=> array( 'pending' => 'Pending', 'on-hold' => 'On hold', 'completed' => 'Completed', 'processing' => 'Processing', 'cancelled' => 'Cancelled', 'initiated' => 'Initiated' ),
				'default'		=> array( 'completed' )
			),
			array(
				'id' 			=> 'cancelled_order_woocommerce_statuses',
				'name'			=> __( 'Cancelled Order Woocommerce Statuses', 'intravel' ),
				'desc'	=> __( 'Which WooCommerce statuses do you want to consider as cancelled so that the item is no longer treated as available?', 'intravel' ),
				'type'			=> 'multicheck',
				'options'		=> array( 'pending' => 'Pending', 'on-hold' => 'On hold', 'completed' => 'Completed', 'processing' => 'Processing', 'cancelled' => 'Cancelled', 'initiated' => 'Initiated' ),
				'default'		=> array( 'cancelled' )
			),
			array(
				'id' 			=> 'onhold_order_woocommerce_statuses',
				'name'			=> __( 'On hold Order Woocommerce Statuses', 'intravel' ),
				'desc'	=> __( 'Which WooCommerce statuses do you want to consider as on hold so that the item is no longer treated as available?', 'intravel' ),
				'type'			=> 'multicheck',
				'options'		=> array( 'pending' => 'Pending', 'on-hold' => 'On hold', 'completed' => 'Completed', 'processing' => 'Processing', 'cancelled' => 'Cancelled', 'initiated' => 'Initiated' ),
				'default'		=> array( 'on-hold' ),
			),
			array(
				'id' 			=> 'paypal_sanbox_mode',
				'name'			=> __( 'Paypal sanbox mode' , 'intravel' ),
				'type'			=> 'checkbox',
				'options'		=> array('0' => __('No', 'intravel'), '1' => __('Yes', 'intravel')),
				'before_row'   => array('IT_Settings', 'before_row'), // callback
				'before_row_text' => '<h3 class="payment-method-title">'.__('PAYPAL', 'intravel').' - <span>'.__('Not working if Woocommerce For Checkout is checked', 'intravel').'</span></h3>',
				'default'		=> '',
			),
			array(
				'id' 			=> 'paypal_email',
				'name'			=> __( 'Paypal email' , 'intravel' ),
				'desc'	=> __( 'Enter paypal email.', 'intravel' ),
				'type'			=> 'text',
				'default'		=> '',
			),
			array(
				'id' 			=> 'paypal_hold_stock_hours',
				'name'			=> __( 'Hold order time' , 'intravel' ),
				'desc'	=> __( 'Is the time to keep one pending order if after this time it will be cancel (in hours).', 'intravel' ),
				'type'			=> 'text',
				'default'		=> '1',
			),
			array(
				'id' 			=> 'submit_form_status',
				'name'			=> __( 'Submit Form Status', 'intravel' ),
				'desc'	=> __( 'Select status of order in case using Submit Form payment method.', 'intravel' ),
				'type'			=> 'select',
				'options'		=> array( 'pending' => 'Pending', 'on-hold' => 'On hold'),
				'default'		=> array( 'pending' ),
				'before_row'   => array('IT_Settings', 'before_row'), // callback
				'before_row_text' => '<h3 class="payment-method-title">'.__('SUBMIT FORM', 'intravel').' - <span>'.__('Not working if Woocommerce For Checkout is checked', 'intravel').'</span></h3>',
			),
			array(
				'id' 			=> 'hold_stock_hours',
				'name'			=> __( 'Hold order time' , 'intravel' ),
				'desc'	=> __( 'Is the time to keep one pending order if after this time it will be cancel (in hours).', 'intravel' ),
				'type'			=> 'text',
				'default'		=> '50',
			),
		);

		$cmb = new_cmb2_box( array(
			'id'        => 'options_payment',
			'title'     => __( 'Payment', 'intravel' ),
			'show_on'   => $show_on, // critical, see wiki for why
			'fields'   => $fields
		));
		$cmb->object_type( 'options-page' );  // critical, see wiki for why
		$boxes[] = $cmb;

		$fields = array(
			array(
				'id' 			=> 'currency',
				'name'			=> __( 'Currency' , 'intravel' ),
				'desc'	=> __( 'Select curreny.', 'intravel' ),
				'type'			=> 'select',
				'options'		=> it_get_currencies(),
				'default'		=> 'USD',
			),
			array(
				'id' 			=> 'currency_pos',
				'name'			=> __( 'Currency Position' , 'intravel' ),
				'desc'	=> __( 'Select curreny position.', 'intravel' ),
				'type'			=> 'select',
				'options'		=> array('left' => __('Left', 'intravel'), 'right' => __('Right', 'intravel'), 'left_space' => __('Left With Space', 'intravel'), 'right_space' => __('Right With Space', 'intravel')),
				'default'		=> 'left',
			),
			array(
				'id' 			=> 'price_thousand_sep',
				'name'			=> __( 'Price Thousand Separator' , 'intravel' ),
				'desc'	=> __( 'Enter Price Thousand Separator.', 'intravel' ),
				'type'			=> 'text',
				'default'		=> '.',
			),
			array(
				'id' 			=> 'price_num_decimals',
				'name'			=> __( 'Price Number Decimals' , 'intravel' ),
				'desc'	=> __( 'Enter Price Number Decimals.', 'intravel' ),
				'type'			=> 'text',
				'default'		=> '2',
			),
			array(
				'id' 			=> 'taxes',
				'name'			=> __( 'Taxes' , 'intravel' ),
				'desc'	=> __( 'Taxes in percent.', 'intravel' ),
				'type'			=> 'text',
				'default'		=> '',
			),
			array(
				'id' 			=> 'prices_include_tax',
				'name'			=> __( 'Prices Entered With Tax', 'intravel' ),
				'type'			=> 'radio',
				'options'		=> array( 'no' => 'No, I will enter prices exclusive of tax', 'yes' => 'Yes, I will enter prices inclusive of tax' ),
				'default'		=> 'no'
			),
			array(
				'id' 			=> 'tax_display_tours',
				'name'			=> __( 'Display Prices in the Tours' , 'intravel' ),
				'type'			=> 'select',
				'options'		=> array('incl' => __('Including tax', 'intravel'), 'excl' => __('Excluding tax', 'intravel')),
				'default'		=> 'excl',
			),
		);

		$cmb = new_cmb2_box( array(
			'id'        => 'options_price',
			'title'     => __( 'Price', 'intravel' ),
			'show_on'   => $show_on, // critical, see wiki for why
			'fields'   => $fields
		));
		$cmb->object_type( 'options-page' );  // critical, see wiki for why
		$boxes[] = $cmb;

		$fields = array(
			array(
				'id' 			=> 'who_can_review_tour',
				'name'			=> __( 'Who can review tour' , 'intravel' ),
				'desc'	=> __( 'Default is wordpress discussion option.', 'intravel' ),
				'type'			=> 'select',
				'options'		=> array(
					'' => 'Default',
					'anyone' => 'Anyone',
					'Register' => 'Register',
					'paid' => 'Only Paid',
				),
				'default'		=> '',
			),
			array(
				'id' 			=> 'who_can_rating_destination',
				'name'			=> __( 'Who can rating destination' , 'intravel' ),
				'desc'	=> __( 'Default is anyone.', 'intravel' ),
				'type'			=> 'select',
				'options'		=> array(
					'anyone' => 'Anyone',
					'register' => 'Register',
				),
				'default'		=> '',
			),
		);

		$cmb = new_cmb2_box( array(
			'id'        => 'options_review',
			'title'     => __( 'Review', 'intravel' ),
			'show_on'   => $show_on, // critical, see wiki for why
			'fields'   => $fields
		));
		$cmb->object_type( 'options-page' );  // critical, see wiki for why
		$boxes[] = $cmb;

		 $fields = array(
			 array(
				 'id' 			=> 'email_from_name',
				 'name'			=> __( 'Email from name' , 'intravel' ),
				 'type'			=> 'text',
				 'default'		=> '',
			 ),
			 array(
				 'id' 			=> 'email_from_address',
				 'name'			=> __( 'Email From Address' , 'intravel' ),
				 'type'			=> 'text',
			 ),
		 );
		 $cmb = new_cmb2_box( array(
			 'id'        => 'options_email_sender',
			 'title'     => __( 'Email Sender Options', 'intravel' ),
			 'show_on'   => $show_on, // critical, see wiki for why,
			 'fields'   => $fields
		 ));
		 $cmb->object_type( 'options-page' );  // critical, see wiki for why
		 $boxes[] = $cmb;

		 $fields = array(
			 array(
				 'id' 			=> 'email_new_enable',
				 'name'			=> __( 'Enable/Disable' , 'intravel' ),
				 'type'			=> 'checkbox',
				 'default'		=> '1',
			 ),
			 array(
				 'id' 			=> 'email_new_recipients',
				 'name'			=> __( 'Recipient(s)' , 'intravel' ),
				 'type'			=> 'text',
			 ),
			 array(
				 'id' 			=> 'email_new_subject',
				 'name'			=> __( 'Subject' , 'intravel' ),
				 'type'			=> 'text',
				 'after_row'			=> 'Email Tags: {intravel_site_title}, {intravel_admin_email}, {intravel_custommer_name}, {intravel_custommer_firstname}, {intravel_custommer_lastname},
				 					{intravel_custommer_email}, {intravel_order_price}, {intravel_order_admin_link}, {intravel_check_order_link}, {intravel_order_code}, {intravel_order_adult_number},
				 					{intravel_order_children_number}, {intravel_order_start_date}, {intravel_tour_title}, {intravel_tour_link}, {intravel_hold_order_hours}'
			 ),
			 array(
				 'id' 			=> 'email_new_body_html',
				 'name'			=> __( 'Body HTML' , 'intravel' ),
				 'type'			=> 'wysiwyg',
			 ),
		 );

		 $cmb = new_cmb2_box( array(
			 'id'        => 'options_email_new',
			 'title'     => __( 'New Order', 'intravel' ),
			 'show_on'   => $show_on, // critical, see wiki for why,
			 'closed'     => true,
			 'fields'   => $fields
		 ));
		 $cmb->object_type( 'options-page' );  // critical, see wiki for why
		 $boxes[] = $cmb;

		$fields = array(
			 array(
				 'id' 			=> 'email_onhold_enable',
				 'name'			=> __( 'Enable/Disable' , 'intravel' ),
				 'type'			=> 'checkbox',
				 'default'		=> '1',
			 ),
			 array(
				 'id' 			=> 'email_onhold_recipients',
				 'name'			=> __( 'Recipient(s)' , 'intravel' ),
				 'type'			=> 'text',
			 ),
			 array(
				 'id' 			=> 'email_onhold_subject',
				 'name'			=> __( 'Subject' , 'intravel' ),
				 'type'			=> 'text',
				 'after_row'			=> 'Email Tags: {intravel_site_title}, {intravel_admin_email}, {intravel_custommer_name}, {intravel_custommer_firstname}, {intravel_custommer_lastname},
				 					{intravel_custommer_email}, {intravel_order_price}, {intravel_order_admin_link}, {intravel_check_order_link}, {intravel_order_code}, {intravel_order_adult_number},
				 					{intravel_order_children_number}, {intravel_order_start_date}, {intravel_tour_title}, {intravel_tour_link}, {intravel_hold_order_hours}'
			 ),
			 array(
				 'id' 			=> 'email_onhold_body_html',
				 'name'			=> __( 'Body HTML' , 'intravel' ),
				 'type'			=> 'wysiwyg',
			 ),
		 );

		 $cmb = new_cmb2_box( array(
			 'id'        => 'options_email_onhold',
			 'title'     => __( 'Order on-hold', 'intravel' ),
			 'show_on'   => $show_on, // critical, see wiki for why
			 'closed'     => true,
			 'fields'   => $fields
		 ));
		 $cmb->object_type( 'options-page' );  // critical, see wiki for why
		 $boxes[] = $cmb;


		$fields = array(
			 array(
				 'id' 			=> 'email_cancelled_enable',
				 'name'			=> __( 'Enable/Disable' , 'intravel' ),
				 'type'			=> 'checkbox',
				 'default'		=> '1',
			 ),
			 array(
				 'id' 			=> 'email_cancelled_recipients',
				 'name'			=> __( 'Recipient(s)' , 'intravel' ),
				 'type'			=> 'text',
			 ),
			 array(
				 'id' 			=> 'email_cancelled_subject',
				 'name'			=> __( 'Subject' , 'intravel' ),
				 'type'			=> 'text',
				 'after_row'			=> 'Email Tags: {intravel_site_title}, {intravel_admin_email}, {intravel_custommer_name}, {intravel_custommer_firstname}, {intravel_custommer_lastname},
				 					{intravel_custommer_email}, {intravel_order_price}, {intravel_order_admin_link}, {intravel_check_order_link}, {intravel_order_code}, {intravel_order_adult_number},
				 					{intravel_order_children_number}, {intravel_order_start_date}, {intravel_tour_title}, {intravel_tour_link}, {intravel_hold_order_hours}'
			 ),
			 array(
				 'id' 			=> 'email_cancelled_body_html',
				 'name'			=> __( 'Body HTML' , 'intravel' ),
				 'type'			=> 'wysiwyg',
			 ),
		 );

		 $cmb = new_cmb2_box( array(
			 'id'        => 'options_email_cancelled',
			 'title'     => __( 'Cancelled Order', 'intravel' ),
			 'show_on'   => $show_on, // critical, see wiki for why,
			 'closed'     => true,
			 'fields'   => $fields
		 ));
		 $cmb->object_type( 'options-page' );  // critical, see wiki for why
		 $boxes[] = $cmb;

		$fields = array(
			 array(
				 'id' 			=> 'email_completed_enable',
				 'name'			=> __( 'Enable/Disable' , 'intravel' ),
				 'type'			=> 'checkbox',
				 'default'		=> '1',
			 ),
			 array(
				 'id' 			=> 'email_completed_recipients',
				 'name'			=> __( 'Recipient(s)' , 'intravel' ),
				 'type'			=> 'text',
			 ),
			 array(
				 'id' 			=> 'email_completed_subject',
				 'name'			=> __( 'Subject' , 'intravel' ),
				 'type'			=> 'text',
				 'after_row'			=> 'Email Tags: {intravel_site_title}, {intravel_admin_email}, {intravel_custommer_name}, {intravel_custommer_firstname}, {intravel_custommer_lastname},
				 					{intravel_custommer_email}, {intravel_order_price}, {intravel_order_admin_link}, {intravel_check_order_link}, {intravel_order_code}, {intravel_order_adult_number},
				 					{intravel_order_children_number}, {intravel_order_start_date}, {intravel_tour_title}, {intravel_tour_link}, {intravel_hold_order_hours}'
			 ),
			 array(
				 'id' 			=> 'email_completed_body_html',
				 'name'			=> __( 'Body HTML' , 'intravel' ),
				 'type'			=> 'wysiwyg',
			 ),
		 );

		 $cmb = new_cmb2_box( array(
			 'id'        => 'options_email_completed',
			 'title'     => __( 'Completed Order', 'intravel' ),
			 'show_on'   => $show_on, // critical, see wiki for why
			 'closed'     => true,
			 'fields'   => $fields
		 ));
		 $cmb->object_type( 'options-page' );  // critical, see wiki for why
		 $boxes[] = $cmb;

		return $boxes;
	}

	/**
	 * Add some tabs (in this case, two).
	 *
	 * Tabs are completely optional and removing them would result in the option metaboxes displaying sequentially.
	 *
	 * If you do configure tabs, all boxes whose context is "normal" or "advanced" must be in a tab to display.
	 *
	 * @return array
	 */
	function intravel_options_add_tabs() {

		$tabs = array();

		$tabs[] = array(
			'id'    => 'options_general_tab',
			'title' => 'General',
			'desc'  => '',
			'boxes' => array(
				'options_general',
			),
		);
		$tabs[] = array(
			'id'    => 'options_slug_tab',
			'title' => 'Slug',
			'desc'  => '',
			'boxes' => array(
				'options_slug',
			),
		);
		$tabs[] = array(
			'id'    => 'options_map_tab',
			'title' => 'Google Map',
			'desc'  => '',
			'boxes' => array(
				'options_map',
			),
		);
		$tabs[] = array(
			'id'    => 'options_payment_tab',
			'title' => 'Payment',
			'desc'  => '',
			'boxes' => array(
				'options_payment',
			),
		);
		$tabs[] = array(
			'id'    => 'options_price_tab',
			'title' => 'Price',
			'desc'  => '',
			'boxes' => array(
				'options_price',
			),
		);
		$tabs[] = array(
			'id'    => 'options_review_tab',
			'title' => 'Review',
			'desc'  => '',
			'boxes' => array(
				'options_review',
			),
		);

		$tabs[] = array(
			'id'    => 'options_email_tab',
			'title' => 'Emails',
			'desc'  => '',
			'boxes' => array(
				'options_email_sender',
				'options_email_new',
				'options_email_onhold',
				'options_email_cancelled',
				'options_email_completed',
			),
		);

		return $tabs;
	}
}


new IT_Settings;
