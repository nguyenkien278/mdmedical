<?php
/** Widget Tour Destinations */
class Inwave_Destination extends WP_Widget
{
    /**
     * Construct
     */
    function __construct() {
        $widget_ops = array('classname' => 'tour_destinations', 'description' => esc_html__('Display InTravel tour destinations.', 'intravel'));
        parent::__construct('destinations', esc_html__('InTravel Destinations', 'intravel'), $widget_ops);
    }

    function get_ancestors($destination){
        $html = array();
        $parents = get_ancestors($destination->term_id, 'destination');
        if($parents){
            foreach ($parents as $destination_id){
                $destination = get_term( $destination_id, 'destination' );
                $html[] = '<a href="'.get_term_link($destination, 'destination').'">'.$destination->name.'</a>';
            }
        }

        if($html){
            return $html[0];
        }

        return '';
    }

    /**
     * Show widget
     */
    function widget($args, $instance)
    {
        /** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
        $hide_empty = isset($instance['hide_empty']) ? strip_tags($instance['hide_empty']) : false;
        $number = isset($instance['number']) ? absint( $instance['number'] ) : 3;
        $order_by = isset($instance['order_by']) ? strip_tags($instance['order_by']) : 'name';
        $order_dir = isset($instance['order_dir']) ? strip_tags($instance['order_dir']) : 'ASC';

        echo $args['before_widget'];
        $title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : __( 'Destinations', 'intravel' );
        $title = apply_filters( 'widget_title', $title, $instance, $this->id_base );
        if ( !empty( $title ) ) { echo $args['before_title'] . $title . $args['after_title']; }

        $default_args = array(
            'taxonomy' => 'destination',
            'orderby' => $order_by,
            'order' => $order_dir,
            'hide_empty' => $hide_empty,
            'number' => $number,
            'parent' => '',
        );

        $destinations = get_terms($default_args);

        if ($destinations) {
            echo '<div class="destination-widget">';
            foreach ($destinations as $destination) {
                $image = get_term_meta($destination->term_id, 'intravel_image', true);
                $image_url = '';
                if(!empty($image)){
                    $image_url = inwave_resize($image, 270, 300, true);
                }
                if(!$image_url){
                    $image_url = it_get_placeholder_image();
                }
                $destination_class = it_get_detination($destination);
                $average_rating_destination = $destination_class->get_average_rating();
                $link = get_term_link($destination->term_id, 'destination');

                if($hide_empty == true ){
                    if($destination->count > 0) {
                        echo '<div class="destination-item iw-effect-1">';
							echo '<img src="' . esc_url($image_url) . '" alt="Image">';
							echo '<div class="destination-info">';
							    echo '<div class="info-active">';
                                    echo '<h4>' . $destination->name . '</h4>';
                                    if ($destination && $destination->parent) {
                                        echo '<div class="destination-parent">' .' / ' .$this->get_ancestors($destination). ''. '</div>';
                                    }
                                    if ($average_rating_destination) {
                                        $rating_star = (($average_rating_destination) / 5) * 100;
                                        $rating_star = number_format( $rating_star, 0, '.', '' );
                                        echo '<div class="destination-widget-rating">
                                                            <div class="iw-star-rating">
                                                                <span class="rating" style="width: '. esc_attr($rating_star).'%' .'"></span>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        </div>';
                                    }
                                echo '</div>';
								echo '<div class="destination-to-detail"><a href="' . esc_url($link) . '">' . __('Discover ', 'intravel') .'<i class="icon ion-arrow-right-c"></i></a></div>';
							echo '</div>';
                        echo '</div>';
                    }
                }else{
                    echo '<div class="destination-item iw-effect-1">';
                        echo '<img src="' . esc_url($image_url) . '" alt="">';
                        echo '<div class="destination-info">';
                            echo '<div class="info-active">';
                                echo '<h4>' . $destination->name . '</h4>';
                                if ($destination && $destination->parent) {
                                    echo '<div class="destination-parent">' .$this->get_ancestors($destination). '</div>';
                                }
                                if ($average_rating_destination) {
                                    $rating_star = (($average_rating_destination) / 5) * 100;
                                    $rating_star = number_format( $rating_star, 0, '.', '' );
                                    echo '<div class="destination-widget-rating">
                                                                        <div class="iw-star-rating">
                                                                            <span class="rating" style="width: '. esc_attr($rating_star).'%' .'"></span>
                                                                        </div>
                                                                        <div class="clearfix"></div>
                                                                    </div>';
                                }
                            echo '</div>';
                            echo '<div class="destination-to-detail"><a href="' . esc_url($link) . '">' . __('Discover ', 'intravel') .'<i class="icon ion-arrow-right-c"></i></a></div>';
                        echo '</div>';
                    echo '</div>';
                }
            }
            echo '<div class="clearfix"></div>';
            echo '</div>';
        }

        echo $args['after_widget'];
    }

    /**
     * save widget form
     */

    function update($new_instance, $old_instance)
    {
        $instance = $old_instance;
        $instance['title'] = strip_tags($new_instance['title']);
        $instance['number'] = (int) $new_instance['number'];
        $instance['hide_empty'] = isset( $new_instance['hide_empty'] ) ? (bool) $new_instance['hide_empty'] : false;
        $instance['order_by'] = strip_tags($new_instance['order_by']);
        $instance['order_dir'] = strip_tags($new_instance['order_dir']);
        return $instance;
    }

    /**
     * create form option cho widget
     */
    function form($instance)
    {
        $instance = wp_parse_args( (array) $instance, array( 'title' => __( 'Destinations', 'intravel' ), 'number' => '3', 'hide_empty' => '0', 'order_by' => 'name', 'order_dir' => 'ASC') );
        $title = strip_tags($instance['title']);
        $number   = strip_tags( $instance['number'] );
        $hide_empty = strip_tags( $instance['hide_empty'] );
        $order_by = strip_tags($instance['order_by']);
        $order_dir = strip_tags($instance['order_dir']);
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'inevent'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p><label for="<?php echo $this->get_field_id('number'); ?>"><?php _e('Number of destination to show:'); ?></label>
            <input class="tiny-text" id="<?php echo $this->get_field_id('number'); ?>"
                   name="<?php echo $this->get_field_name('number'); ?>" type="number" step="1" min="1"
                   value="<?php echo $number; ?>" size="3"/>
        </p>
        <p><input class="checkbox" type="checkbox"<?php checked( $hide_empty ); ?> id="<?php echo $this->get_field_id( 'hide_empty' ); ?>" name="<?php echo $this->get_field_name( 'hide_empty' ); ?>" />
            <label for="<?php echo $this->get_field_id( 'hide_empty' ); ?>"><?php _e( 'Hide empty tour?' ); ?></label>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('order_by')); ?>"><?php esc_html_e('Order by:', 'intravel'); ?></label>
            <select class="widefat" id="<?php echo esc_attr($this->get_field_id('order_by')); ?>" name="<?php echo esc_attr($this->get_field_name('order_by')); ?>">
                <option value="id" <?php echo ($order_by == 'id' ? 'selected' : '')?>><?php echo esc_html(__('ID', 'intravel')); ?></option>
                <option value="name" <?php echo ($order_by == 'name' ? 'selected' : '')?>><?php echo esc_html(__('Name', 'intravel')); ?></option>
                <option value="count" <?php echo ($order_by == 'count' ? 'selected' : '')?>><?php echo esc_html(__('Total Tours', 'intravel')); ?></option>
            </select>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('order_dir')); ?>"><?php esc_html_e('Order direction:', 'intravel'); ?></label>
            <select class="widefat" id="<?php echo esc_attr($this->get_field_id('order_dir')); ?>" name="<?php echo esc_attr($this->get_field_name('order_dir')); ?>">
                <option value="DESC" <?php echo ($order_dir == 'DESC' ? 'selected' : '')?>><?php echo esc_html(__('Desc', 'intravel')); ?></option>
                <option value="ASC" <?php echo ($order_dir == 'ASC' ? 'selected' : '')?>><?php echo esc_html(__('Asc', 'intravel')); ?></option>
            </select>
        </p>
        <?php
    }
}

function inwave_destination_widget() {
    register_widget('Inwave_Destination');
}
add_action('widgets_init', 'inwave_destination_widget');