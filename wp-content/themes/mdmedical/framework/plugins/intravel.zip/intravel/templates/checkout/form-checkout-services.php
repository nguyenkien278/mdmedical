<?php
$cart = IT()->get_cart();
$tour_services = '';
if($cart){
    $tour = it_get_tour($cart['tour']);
    $tour_services = wp_get_post_terms( $tour->id, 'tour_service' );
    global $tour_selected_services;
    $tour_selected_services = isset($cart['intravel_service']) ? (array)$cart['intravel_service'] : array();
}
if($tour_services){
    $hasServices = false;
    ob_start();
    echo '<h3 class="service-title">'.__('Additional services', 'intravel').'</h3>';
    global $tour_service;
    foreach ($tour_services as $service){
        $show_detail = get_term_meta($service->term_id, 'intravel_show_in_detail', true);
        $position = get_term_meta($service->term_id, 'intravel_position', true);
        $hasServices = true;
        ?>
        <div class="field-group field-group-service input-form field-left">
            <div class="field-group-inner">
                <?php
                $tour_service = $service;
                it_get_template_part('global/service-output');
                ?>
            </div>
        </div>
        <?php
    }

    if($hasServices ){
        echo ob_get_clean();
    }
    else{
        ob_clean();
    }
}