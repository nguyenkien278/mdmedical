<?php
/**
 * Widget API: Inwave_Intravel_Tour_Tags class
 *
 * @package WordPress
 * @subpackage Widgets
 * @since 4.4.0
 */


class Inwave_Intravel_Tour_Tags extends WP_Widget {

	public function __construct() {
		$widget_ops = array(
			'description' => esc_html__( 'Display InTravel tour tags.' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct( 'tour_tags', esc_html__( 'InTravel Tour Tags' ), $widget_ops );
	}

	public function widget( $args, $instance ) {
		$current_taxonomy = 'tour_tag';
		
		$tag_cloud = wp_tag_cloud( apply_filters( 'widget_tour_tags_args', array(
			'taxonomy' => $current_taxonomy,
			'echo' => false
		) ) );

		if ( empty( $tag_cloud ) ) {
			return;
		}

		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : __( 'Tour Tags', 'intravel' );
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );
		
		echo $args['before_widget'];
		if ( $title ) {
			echo $args['before_title'] . $title . $args['after_title'];
		}
		echo '<div class="tagcloud tour-tags">';
		echo $tag_cloud;
		echo "</div>\n";
		echo $args['after_widget'];
	}
	
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = sanitize_text_field( $new_instance['title'] );
		return $instance;
	}
	
	public function form( $instance ) {
        $instance = wp_parse_args( (array) $instance, array( 'title' => __('Tour Tags', 'intravel') ) );
		$title_id = $this->get_field_id( 'title' );
        $title = strip_tags($instance['title']);
		echo '<p><label for="' . $title_id .'">' . __( 'Title:' ) . '</label>
			<input type="text" class="widefat" id="' . $title_id .'" name="' . $this->get_field_name( 'title' ) .'" value="' . $title .'" />
		</p>';
	}

}

function tour_tags_widget() {
    register_widget('Inwave_Intravel_Tour_Tags');
}
add_action('widgets_init', 'tour_tags_widget');