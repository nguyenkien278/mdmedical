<?php
/*
Plugin Name: CMB2 Metatabs Options
Plugin URI:  https://github.com/rogerlos/cmb2-metatabs-options
Description: Add admin option pages with multiple metaboxes--and place those metaboxes into optional tabs. Requires CMB2.
Version:     1.0.1
Author:      Roger Los
Author URI:  https://github.com/rogerlos
Text Domain: cmb2
License:     GPLv2 or later
 */

if ( ! defined( 'WPINC' ) ) die;

if(!function_exists('cmb2_render_iwperiod')){
    function cmb2_render_iwperiod($field, $escaped_value, $object_id, $object_type, $field_type_object ){
        wp_enqueue_style( 'iwperiod' , INTRAVEL_PLUGIN_URL .'/libs/cmb2-iwperiod/css/iwperiod.css');
        wp_enqueue_script( 'iwperiod' , INTRAVEL_PLUGIN_URL .'/libs/cmb2-iwperiod/js/iwperiod.js');

        $meta_value = $field->value;
        $meta_value = json_decode($meta_value, true);
        $name = $name = $field->args['id'];
        echo '<div id="'.$field->args['id'].'" class="cmb_period_list">';
        echo '<div class="period-list">';
        if ( $meta_value) {
            $i = 1 ;
            foreach ( $meta_value as $value ) {
                echo '<div class="period-item">';
				
				//begin period-select
                echo '<div class="period-select">';
					echo '<div class="item-wrap">';
						echo '<label>Booking Mode</label>';
						echo '<select name="'.$name.'['.$i.'][type]">';
						echo '<option value="week" '.($value['type'] == 'week' ? 'selected' : '').'>Week days</option>';
						echo '<option value="exact_date" '.($value['type'] == 'exact_date' ? 'selected' : '').'>Exact dates</option>';
						echo '</select>';
					echo '</div>';
					
					echo '<div class="item-wrap">';
						echo '<label>Adult price</label>';
						echo '<input type="text" class="cmb2-text-small" name="'.$name.'['.$i.'][price]" value="'.$value['price'].'" placeholder="Inherited"> ('.it_get_currency_symbol().')';
					echo '</div>';

					echo '<div class="item-wrap">';
						echo '<label>Children price</label>';
						echo '<input type="text" class="cmb2-text-small" name="'.$name.'['.$i.'][children_price]" value="'.$value['children_price'].'" placeholder="Inherited"> ('.it_get_currency_symbol().')';
					echo '</div>';
				
					echo '<div class="item-wrap">';
						echo '<label>Adult tickets</label>';
						echo '<input type="text" class="cmb2-text-small" name="'.$name.'['.$i.'][tickets]" value="'.$value['tickets'].'" placeholder="Inherited">';
					echo '</div>';

					echo '<div class="item-wrap">';
						echo '<label>Children tickets</label>';
						echo '<input type="text" class="cmb2-text-small" name="'.$name.'['.$i.'][children_tickets]" value="'.$value['children_tickets'].'" placeholder="Inherited">';
					echo '</div>';
					
					echo '<div class="item-wrap">';
						echo '<label>Active</label>';
						echo '<select name="'.$name.'['.$i.'][active]" class="period-active">';
						echo '<option value="1" '.($value['active'] == '1' ? 'selected' : '').'>Yes</option>';
						echo '<option value="0" '.($value['active'] == '0' ? 'selected' : '').'>No</option>';
						echo '</select>';
					echo '</div>';
                echo '</div>';
				//end period-select
				
				//begin period-week
                echo '<div class="period-week" '.($value['type'] == 'week' ? 'style="display: block"' : '').'>';
				
					echo '<div class="period-week-1">';
						echo '<div class="item-wrap">';
							echo '<label>Start Date</label>';
							echo '<input type="text" class="cmb2-text-small cmb2-datepicker" name="'.$name.'['.$i.'][start_date]" value="'.$value['start_date'].'" placeholder=""> m/d/Y';
						echo '</div>';
						echo '<div class="item-wrap">';
							echo '<label>End date</label>';
							echo '<input type="text" class="cmb2-text-small cmb2-datepicker" name="'.$name.'['.$i.'][end_date]" value="'.$value['end_date'].'" placeholder="Unlimited"> m/d/Y';
						echo '</div>';
					echo '</div>';
				
				
					echo '<div class="period-week-2">';
					$value['week'] = isset($value['week']) ? $value['week'] : array();
						echo '<div class="item-wrap">';
							echo '<input type="checkbox" id="'.$name.'-'.$i.'-week" name="'.$name.'['.$i.'][week][]" value="Monday" '.(in_array('Monday', $value['week']) ? 'checked' : '').'>';
							echo '<label for="'.$name.'-'.$i.'-week">Monday</label>';
						echo '</div>';
						echo '<div class="item-wrap">';
							echo '<input type="checkbox" id="'.$name.'-'.$i.'-tuesday" name="'.$name.'['.$i.'][week][]" value="Tuesday" '.(in_array('Tuesday', $value['week']) ? 'checked' : '').'>';
							echo '<label for="'.$name.'-'.$i.'-tuesday">Tuesday</label>';
						echo '</div>';
						echo '<div class="item-wrap">';
							echo '<input type="checkbox" id="'.$name.'-'.$i.'-wednesday" name="'.$name.'['.$i.'][week][]" value="Wednesday" '.(in_array('Wednesday', $value['week']) ? 'checked' : '').'>';
							echo '<label for="'.$name.'-'.$i.'-wednesday">Wednesday</label>';
						echo '</div>';	
						echo '<div class="item-wrap">';
							echo '<input type="checkbox" id="'.$name.'-'.$i.'-thursday" name="'.$name.'['.$i.'][week][]" value="Thursday" '.(in_array('Thursday', $value['week']) ? 'checked' : '').'>';
							echo '<label for="'.$name.'-'.$i.'-thursday">Thursday</label>';
						echo '</div>';	
						echo '<div class="item-wrap">';	
							echo '<input type="checkbox" id="'.$name.'-'.$i.'-friday" name="'.$name.'['.$i.'][week][]" value="Friday" '.(in_array('Friday', $value['week']) ? 'checked' : '').'>';
							echo '<label for="'.$name.'-'.$i.'-friday">Friday</label>';
						echo '</div>';	
						echo '<div class="item-wrap">';	
							echo '<input type="checkbox" id="'.$name.'-'.$i.'-saturday" name="'.$name.'['.$i.'][week][]" value="Saturday" '.(in_array('Saturday', $value['week']) ? 'checked' : '').'>';
							echo '<label for="'.$name.'-'.$i.'-saturday">Saturday</label>';
						echo '</div>';
						echo '<div class="item-wrap">';	
							echo '<input type="checkbox" id="'.$name.'-'.$i.'-sunday" name="'.$name.'['.$i.'][week][]" value="Sunday" '.(in_array('Sunday', $value['week']) ? 'checked' : '').'>';
							echo '<label for="'.$name.'-'.$i.'-sunday">Sunday</label>';
						echo '</div>';
					echo '</div>';
                echo '</div>';
				//end period-week
				
				//begin exact-date
                echo '<div class="period-exact-date" '.($value['type'] == 'exact_date' ? 'style="display: block"' : '').'>';
					echo '<div class="period-exact-date-list">';
					if($value['exact_date']){
						foreach ($value['exact_date'] as $exact_date){
							echo '<div class="period-exact-date-item">';
							echo '<input type="text" class="cmb2-text-small cmb2-datepicker" name="'.$name.'['.$i.'][exact_date][]" value="'.$exact_date.'" placeholder="m/d/Y">';
							echo '<a href="#" class="button remove-exact-date">remove</a>';
							echo '</div>';
						}
					}
					echo '</div>';
                echo '<a href="#" class="button button-primary add_time_btn" data-period_name="'.$name.'['.$i.']" >Add Time</a>';
                echo '</div>';
				//end exact-date
				
                echo '<a href="#" class="remove-period">X</a>';
                echo '</div>';

                $i++;
            }
        }
        echo '</div>';

        echo '<a class="button button-primary cmb_add_period" href="#" data-name="'.$name.'" data-count="'.count($meta_value).'">'.__( 'Add Period', 'intravel' ).'</a>';
		
        echo '</div>';
    }

    add_action( 'cmb2_render_iwperiod', 'cmb2_render_iwperiod', 10, 5 );

    function cmb2_sanitize_iwperiod( $override_value, $value ) {
		$value = (array)$value;
		foreach ($value as $key=>$period){
			if($period['type'] == 'week'){
				if(empty($period['start_date'])){
					$value[$key]['start_date'] = date('m/d/Y');
				}
				if(empty($period['week'])){
					unset($value[$key]);
				}
			}
			else{
				$value[$key]['exact_date'] = array_unique(array_filter($period['exact_date']));
				if(empty($value[$key]['exact_date'])){
					unset($value[$key]);
				}
			}
		}

		$value = array_values($value);
        return json_encode($value);
    }

    add_filter( 'cmb2_sanitize_iwperiod', 'cmb2_sanitize_iwperiod', 10, 2 );
}
