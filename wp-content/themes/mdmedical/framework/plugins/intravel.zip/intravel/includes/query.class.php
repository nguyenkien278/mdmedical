<?php
/**
 * Contains the query functions for inTravel which alter the front-end post queries and loops
 *
 * @class 		intravel_query
 * @package		inTravel/Classes
 * @category	Class
 * @author 		inwaveThemes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * intravel_query Class.
 */
class intravel_query
{

	/** @public array Query vars to add to wp */
	public $query_vars = array();

	/**
	 * Constructor for the query class. Hooks in methods.
	 *
	 * @access public
	 */
	public function __construct()
	{
		add_action('init', array($this, 'add_endpoints'));
		if (!is_admin()) {
			//add_action( 'wp_loaded', array( $this, 'get_errors' ), 20 );
			add_filter( 'query_vars', array( $this, 'add_query_vars'), 0 );
			add_action( 'parse_request', array( $this, 'parse_request'), 0 );
			add_action( 'pre_get_posts', array( $this, 'pre_get_posts' ) );
			add_action('wp', array($this, 'remove_tour_query'));
			add_action( 'wp', array( $this, 'remove_ordering_args' ) );
		}

		$this->init_query_vars();
	}

	/**
	 * Init query vars by loading options.
	 */
	public function init_query_vars()
	{
		// Query vars to add to WP
		$this->query_vars = array(
			// Checkout actions
			'booking-received' => it_get_option('endpoint_booking_received', 'booking-received'),
		);
	}

	/**
	 * Get page title for an endpoint.
	 * @param  string
	 * @return string
	 */
	public function get_endpoint_title($endpoint)
	{
		global $wp;

		switch ($endpoint) {
			case 'booking-received' :
				$title = __('Booking Received', 'intravel');
				break;
			default :
				$title = '';
				break;
		}
		return $title;
	}

	/**
	 * Add endpoints for query vars.
	 */
	public function add_endpoints()
	{
		foreach ($this->query_vars as $key => $var) {
			add_rewrite_endpoint($var, EP_ROOT | EP_PAGES);
		}
	}

	/**
	 * Add query vars.
	 *
	 * @access public
	 * @param array $vars
	 * @return array
	 */
	public function add_query_vars($vars)
	{
		foreach ($this->query_vars as $key => $var) {
			$vars[] = $key;
		}

		return $vars;
	}

	/**
	 * Get query vars.
	 *
	 * @return array
	 */
	public function get_query_vars()
	{
		return $this->query_vars;
	}

	/**
	 * Get query current active query var.
	 *
	 * @return string
	 */
	public function get_current_endpoint()
	{
		global $wp;
		foreach ($this->get_query_vars() as $key => $value) {
			if (isset($wp->query_vars[$key])) {
				return $key;
			}
		}
		return '';
	}

	/**
	 * Parse the request and look for query vars - endpoints may not be supported.
	 */
	public function parse_request()
	{
		global $wp;

		// Map query vars to their keys, or get them if endpoints are not supported
		foreach ($this->query_vars as $key => $var) {
			if (isset($_GET[$var])) {
				$wp->query_vars[$key] = $_GET[$var];
			} elseif (isset($wp->query_vars[$var])) {
				$wp->query_vars[$key] = $wp->query_vars[$var];
			}
		}
	}

	/**
	 * Hook into pre_get_posts to do the main product query.
	 *
	 * @param mixed $q query object
	 */
	public function pre_get_posts($q)
	{
		// We only want to affect the main query
		if (!$q->is_main_query()) {
			return;
		}

		// Fix for verbose page rules
		if ($GLOBALS['wp_rewrite']->use_verbose_page_rules && isset($q->queried_object->ID) && $q->queried_object->ID === it_get_page_id('tours')) {
			$q->set('post_type', 'tour');
			$q->set('page', '');
			$q->set('pagename', '');

			// Fix conditional Functions
			$q->is_archive = true;
			$q->is_post_type_archive = true;
			$q->is_singular = false;
			$q->is_page = false;
		}

		// Fix for endpoints on the homepage
		if ($q->is_home() && 'page' === get_option('show_on_front') && absint(get_option('page_on_front')) !== absint($q->get('page_id'))) {
			$_query = wp_parse_args($q->query);
			if (!empty($_query) && array_intersect(array_keys($_query), array_keys($this->query_vars))) {
				$q->is_page = true;
				$q->is_home = false;
				$q->is_singular = true;
				$q->set('page_id', (int)get_option('page_on_front'));
				add_filter('redirect_canonical', '__return_false');
			}
		}

		// When orderby is set, WordPress shows posts. Get around that here.
		if ($q->is_home() && 'page' === get_option('show_on_front') && absint(get_option('page_on_front')) === it_get_page_id('tours')) {
			$_query = wp_parse_args($q->query);
			if (empty($_query) || !array_diff(array_keys($_query), array('preview', 'page', 'paged', 'cpage', 'orderby'))) {
				$q->is_page = true;
				$q->is_home = false;
				$q->set('page_id', (int)get_option('page_on_front'));
				$q->set('post_type', 'tour');
			}
		}
		// Special check for shops with the product archive on front
		if ($q->is_page() && 'page' === get_option('show_on_front') && absint($q->get('page_id')) === it_get_page_id('tours')) {
			// This is a front-page shop
			$q->set('post_type', 'tour');
			$q->set('page_id', '');

			if (isset($q->query['paged'])) {
				$q->set('paged', $q->query['paged']);
			}

			// Define a variable so we know this is the front page shop later on
			define('TOURS_IS_ON_FRONT', true);

			// Get the actual WP page to avoid errors and let us use is_front_page()
			// This is hacky but works. Awaiting http://core.trac.wordpress.org/ticket/21096
			global $wp_post_types;

			$tours_page = get_post(it_get_page_id('tours'));

			$wp_post_types['tour']->ID = $tours_page->ID;
			$wp_post_types['tour']->post_title = $tours_page->post_title;
			$wp_post_types['tour']->post_name = $tours_page->post_name;
			$wp_post_types['tour']->post_type = $tours_page->post_type;
			$wp_post_types['tour']->ancestors = get_ancestors($tours_page->ID, $tours_page->post_type);

			// Fix conditional Functions like is_front_page
			$q->is_singular = false;
			$q->is_post_type_archive = true;
			$q->is_archive = true;
			$q->is_page = true;

			// Remove post type archive name from front page title tag
			add_filter('post_type_archive_title', '__return_empty_string', 5);

			// Fix WP SEO
			if (class_exists('WPSEO_Meta')) {
				add_filter('wpseo_metadesc', array($this, 'wpseo_metadesc'));
				add_filter('wpseo_metakey', array($this, 'wpseo_metakey'));
			}

			// Only apply to product categories, the product post archive, the shop page, product tags, and product attribute taxonomies
		} elseif (!$q->is_post_type_archive('tour') && !$q->is_tax(get_object_taxonomies('tour'))) {
			return;
		}
		$this->tour_start_date();
		$this->tour_query($q);

		if (is_search()) {
			add_filter('posts_where', array($this, 'search_post_excerpt'));
			add_filter('wp', array($this, 'remove_posts_where'));
		}

		// And remove the pre_get_posts hook

		$this->remove_tour_query();
	}

	/**
	 * Search post excerpt.
	 *
	 * @access public
	 * @param string $where (default: '')
	 * @return string (modified where clause)
	 */
	public function search_post_excerpt($where = '')
	{
		global $wp_the_query;

		// If this is not a WC Query, do not modify the query
		if (empty($wp_the_query->query_vars['intravel_query']) || empty($wp_the_query->query_vars['s']))
			return $where;

		$where = preg_replace(
			"/post_title\s+LIKE\s*(\'\%[^\%]+\%\')/",
			"post_title LIKE $1) OR (post_excerpt LIKE $1", $where);

		return $where;
	}

	/**
	 * WP SEO meta description.
	 *
	 * Hooked into wpseo_ hook already, so no need for function_exist.
	 *
	 * @access public
	 * @return string
	 */
	public function wpseo_metadesc()
	{
		return WPSEO_Meta::get_value('metadesc', it_get_page_id('tours'));
	}

	/**
	 * WP SEO meta key.
	 *
	 * Hooked into wpseo_ hook already, so no need for function_exist.
	 *
	 * @access public
	 * @return string
	 */
	public function wpseo_metakey()
	{
		return WPSEO_Meta::get_value('metakey', it_get_page_id('tours'));
	}

	public function tour_start_date(){

	}
	/**
	 * Query the products, applying sorting/ordering etc. This applies to the main wordpress loop.
	 *
	 * @param mixed $q
	 */
	public function tour_query($q)
	{
		// Ordering query vars
		$ordering = $this->get_tours_ordering_args();
		$q->set('orderby', $ordering['orderby']);
		$q->set('order', $ordering['order']);
		if (isset($ordering['meta_key'])) {
			$q->set('meta_key', $ordering['meta_key']);
		}

		// Query vars that affect posts shown
		$q->set('meta_query', $this->get_meta_query($q->get('meta_query')));
		//$q->set( 'tax_query', $this->get_tax_query( $q->get( 'tax_query' ) ) );
		$q->set('posts_per_page', $q->get('posts_per_page') ? $q->get('posts_per_page') : apply_filters('loop_shop_per_page', get_option('posts_per_page')));
		$q->set('intravel_query', 'tour_query');

		$tour_ids = array();
		if(isset($_GET['start_date']) && $_GET['start_date']){
			global $wpdb;
			$start_date = date('m/d/Y', strtotime($_GET['start_date'])) ;
			$tour_ids = $wpdb->get_col( $wpdb->prepare("
			SELECT DISTINCT $wpdb->posts.ID FROM $wpdb->posts
			LEFT JOIN $wpdb->postmeta AS start_date ON ($wpdb->posts.ID = start_date.post_id AND start_date.meta_key = 'intravel_start_date')
			LEFT JOIN $wpdb->postmeta AS end_date ON ($wpdb->posts.ID = end_date.post_id AND end_date.meta_key = 'intravel_end_date')
			WHERE $wpdb->posts.post_status = 'publish'
			AND $wpdb->posts.post_type = 'tour'
			AND ((start_date.meta_value <= %s AND end_date.meta_value >= %s) OR (start_date.meta_value <= %s AND end_date.meta_value = ''))
			", $start_date, $start_date, $start_date));
		}

		$q->set('post__in', array_unique(apply_filters('loop_intravel_tour_in', $tour_ids)));

		do_action('intravel_tour_query', $q, $this);
	}


	/**
	 * Remove the query.
	 */
	public function remove_tour_query()
	{
		remove_action('pre_get_posts', array($this, 'pre_get_posts'));
	}

	/**
	 * Remove ordering queries.
	 */
	public function remove_ordering_args()
	{
		remove_filter('posts_clauses', array($this, 'order_by_popularity_post_clauses'));
		remove_filter('posts_clauses', array($this, 'order_by_rating_post_clauses'));
	}

	/**
	 * Remove the posts_where filter.
	 */
	public function remove_posts_where()
	{
		remove_filter('posts_where', array($this, 'search_post_excerpt'));
	}

	/**
	 * Returns an array of arguments for ordering products based on the selected values.
	 *
	 * @access public
	 * @return array
	 */
	public function get_tours_ordering_args($orderby = '', $order = '')
	{
		global $wpdb;

		// Get ordering from query string unless defined
		if (!$orderby) {
			$orderby = isset($_GET['orderby']) ? sanitize_text_field($_GET['orderby']) : apply_filters('intravel_default_tours_orderby', it_get_option('default_tours_orderby', ''));
			$order = isset($_GET['order']) ? sanitize_text_field($_GET['order']) : apply_filters('intravel_default_tours_order', it_get_option('default_tours_order', 'desc'));
		}

		$orderby = strtolower($orderby);
		$order = strtoupper($order);
		$args = array();

		// default - menu_order
		$args['orderby'] = 'menu_order title';
		$args['order'] = $order == 'DESC' ? 'DESC' : 'ASC';
		$args['meta_key'] = '';

		switch ($orderby) {
			case 'rand' :
				$args['orderby'] = 'rand';
				break;
			case 'date' :
				$args['orderby'] = 'date ID';
				$args['order'] = $order == 'ASC' ? 'ASC' : 'DESC';
				break;
			case 'price' :
				$args['orderby'] = "meta_value_num ID";
				$args['order'] = $order == 'DESC' ? 'DESC' : 'ASC';
				$args['meta_key'] = 'intravel_price';
				break;
			case 'popularity' :
				$args['meta_key'] = 'intravel_total_sales';

				// Sorting handled later though a hook
				add_filter('posts_clauses', array($this, 'order_by_popularity_post_clauses'));
				break;
			case 'rating' :
				// Sorting handled later though a hook
				add_filter('posts_clauses', array($this, 'order_by_rating_post_clauses'));
				break;
			case 'title' :
				$args['orderby'] = 'title';
				$args['order'] = $order == 'DESC' ? 'DESC' : 'ASC';
				break;
		}

		return apply_filters('intravel_get_tours_ordering_args', $args);
	}

	/**
	 * WP Core doens't let us change the sort direction for invidual orderby params - http://core.trac.wordpress.org/ticket/17065.
	 *
	 * This lets us sort by meta value desc, and have a second orderby param.
	 *
	 * @access public
	 * @param array $args
	 * @return array
	 */
	public function order_by_popularity_post_clauses($args)
	{
		global $wpdb;

		$order = isset($_GET['order']) ? sanitize_text_field($_GET['order']) : apply_filters('intravel_default_tours_order', it_get_option('default_tours_order', 'desc'));
		$order = strtoupper($order);

		$args['orderby'] = "$wpdb->postmeta.meta_value+0 $order, $wpdb->posts.post_date $order";

		return $args;
	}

	/**
	 * Order by rating post clauses.
	 *
	 * @access public
	 * @param array $args
	 * @return array
	 */
	public function order_by_rating_post_clauses($args)
	{
		global $wpdb;
		$order = isset($_GET['order']) ? sanitize_text_field($_GET['order']) : apply_filters('intravel_default_tours_order', it_get_option('default_tours_order', 'desc'));
		$order = strtoupper($order);
		$args['fields'] .= ", AVG( $wpdb->commentmeta.meta_value ) as average_rating ";
		$args['where'] .= " AND ( $wpdb->commentmeta.meta_key = 'rating' OR $wpdb->commentmeta.meta_key IS null ) ";
		$args['join'] .= "
			LEFT OUTER JOIN $wpdb->comments ON($wpdb->posts.ID = $wpdb->comments.comment_post_ID)
			LEFT JOIN $wpdb->commentmeta ON($wpdb->comments.comment_ID = $wpdb->commentmeta.comment_id)
		";
		$args['orderby'] = "average_rating $order, $wpdb->posts.post_date $order";
		$args['groupby'] = "$wpdb->posts.ID";

		return $args;
	}

	/**
	 * Appends meta queries to an array.
	 * @access public
	 * @param array $meta_query
	 * @return array
	 */
	public function get_meta_query($meta_query = array())
	{
		if (!is_array($meta_query)) {
			$meta_query = array();
		}

		//$meta_query[] = $this->visibility_meta_query();
		$meta_query[] = $this->price_filter_meta_query();
		$meta_query[] = $this->rating_filter_meta_query();

		return array_filter($meta_query);
	}

	/**
	 * Price Filter post filter.
	 *
	 * @param array $filtered_posts
	 * @return array
	 */
	public function price_filter_meta_query($filtered_posts = array())
	{
		global $wpdb;

		if (isset($_GET['max_price']) || isset($_GET['min_price'])) {
			$min = isset($_GET['min_price']) ? floatval($_GET['min_price']) : 0;
			$max = isset($_GET['max_price']) ? floatval($_GET['max_price']) : 9999999999;

			if (it_is_taxable() && 'incl' === it_get_option('tax_display_tours', 'excl') && it_get_option('prices_include_tax', 'no') === 'no') {
				$tax = it_get_tax();
				$min = $min - $tax;
			}

			return array(
				'key' => 'intravel_price',
				'value' => array($min, $max),
				'compare' => 'BETWEEN',
				'type' => 'DECIMAL',
				'price_filter' => true,
			);
		}

		return array();
	}

	/**
	 * Return a meta query for filtering by rating.
	 * @return array
	 */
	public function rating_filter_meta_query()
	{
		return isset($_GET['min_rating']) ? array(
			'key' => '_it_average_rating',
			'value' => isset($_GET['min_rating']) ? floatval($_GET['min_rating']) : 0,
			'compare' => '>=',
			'type' => 'DECIMAL',
			'rating_filter' => true,
		) : array();
	}

	/**
	 * Returns a meta query to handle product visibility.
	 * @param string $compare (default: 'IN')
	 * @return array
	 */
	public function visibility_meta_query( $compare = 'IN' ) {
		return array(
			'key'     => '_visibility',
			'value'   => is_search() ? array( 'visible', 'search' ) : array( 'visible', 'catalog' ),
			'compare' => $compare,
		);
	}

	/**
	 * Get the tax query which was used by the main query.
	 * @return array
	 */
	public static function get_main_tax_query() {
		global $wp_the_query;

		$args      = $wp_the_query->query_vars;
		$tax_query = isset( $args['tax_query'] ) ? $args['tax_query'] : array();

		if ( ! empty( $args['taxonomy'] ) && ! empty( $args['term'] ) ) {
			$tax_query[ $args['taxonomy'] ] = array(
				'taxonomy' => $args['taxonomy'],
				'terms'    => array( $args['term'] ),
				'field'    => 'slug',
			);
		}

		if ( ! empty( $args['tour_cat'] ) ) {
			$tax_query[ 'tour_cat' ] = array(
				'taxonomy' => 'tour_cat',
				'terms'    => array( $args['tour_cat'] ),
				'field'    => 'slug',
			);
		}

		if ( ! empty( $args['tour_tag'] ) ) {
			$tax_query[ 'tour_tag' ] = array(
				'taxonomy' => 'tour_tag',
				'terms'    => array( $args['tour_tag'] ),
				'field'    => 'slug',
			);
		}

		return $tax_query;
	}

	/**
	 * Get the meta query which was used by the main query.
	 * @return array
	 */
	public static function get_main_meta_query() {
		global $wp_the_query;

		$args       = $wp_the_query->query_vars;
		$meta_query = isset( $args['meta_query'] ) ? $args['meta_query'] : array();

		return $meta_query;
	}
}
return new intravel_query();
